'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Phone, Clock, Calendar } from 'lucide-react'
import { useLanguage } from '@/lib/LanguageContext'
import { LanguageCode } from '@/lib/i18n'

const LANGUAGES: { code: LanguageCode; label: string; native: string }[] = [
  { code: 'en', label: 'English', native: 'English' },
  { code: 'hi', label: 'Hindi', native: 'हिंदी' },
  { code: 'as', label: 'Assamese', native: 'অসমীয়া' },
  { code: 'bn', label: 'Bengali', native: 'বাংলা' },
  { code: 'mn', label: 'Manipuri', native: 'মৈতৈলোন্' },
]

export default function GovHeader() {
  const { language, setLanguage } = useLanguage()
  const [timeStr, setTimeStr] = useState('14:57 IST')
  const [dateStr, setDateStr] = useState('29 Aug 2026')
  const [isOnline, setIsOnline] = useState(true)

  useEffect(() => {
    const handleOnline = () => setIsOnline(true)
    const handleOffline = () => setIsOnline(false)
    window.addEventListener('online', handleOnline)
    window.addEventListener('offline', handleOffline)

    const updateTime = () => {
      const now = new Date()
      setTimeStr(now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }) + ' IST')
      setDateStr(now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }))
    }
    updateTime()
    const timer = setInterval(updateTime, 1000)
    return () => {
      clearInterval(timer)
      window.removeEventListener('online', handleOnline)
      window.removeEventListener('offline', handleOffline)
    }
  }, [])

  return (
    <header className="w-full bg-white border-b border-slate-200 select-none">
      {/* 1. National Government Utility Bar */}
      <div className="bg-[#f8fafc] text-slate-700 px-4 sm:px-6 lg:px-8 py-1.5 text-xs border-b border-slate-200">
        <div className="max-w-[1440px] mx-auto flex flex-wrap items-center justify-between gap-2.5">
          {/* Left: Identification & Regional Scope */}
          <div className="flex items-center gap-2 text-slate-700 font-medium">
            <span className="font-bold text-slate-900">Government of India</span>
            <span className="text-slate-300">|</span>
            <span className="text-slate-600">North Eastern Region Emergency Logistics</span>
          </div>

          {/* Right: Date/Time + Languages + Helpline + Status */}
          <div className="flex items-center gap-4 flex-wrap">
            <div className="hidden md:flex items-center gap-1.5 text-slate-600 font-mono text-xs">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span>{dateStr}</span>
            </div>

            <div className="hidden sm:flex items-center gap-1.5 text-slate-600 font-mono text-xs">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>{timeStr}</span>
            </div>

            {/* Language Text Links */}
            <div className="hidden lg:flex items-center gap-2 text-xs text-slate-600 border-l border-slate-300 pl-3">
              {LANGUAGES.map((l, idx) => (
                <span key={l.code} className="flex items-center gap-2">
                  <button
                    onClick={() => setLanguage(l.code)}
                    className={`hover:text-[#213d77] cursor-pointer transition-colors ${
                      language === l.code ? 'font-bold text-[#213d77] underline underline-offset-2' : ''
                    }`}
                  >
                    {l.native}
                  </button>
                  {idx < LANGUAGES.length - 1 && <span className="text-slate-300">|</span>}
                </span>
              ))}
            </div>

            {/* Emergency Helpline */}
            <div className="flex items-center gap-1.5 text-rose-700 font-bold text-xs bg-rose-50 px-2.5 py-0.5 rounded border border-rose-200">
              <Phone className="w-3 h-3 text-rose-600" />
              <span>Emergency Helpline: <strong className="font-mono">1078</strong></span>
            </div>

            {/* Live System Indicator */}
            <div className="flex items-center gap-1.5 text-emerald-800 font-bold text-xs bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200 font-mono">
              <span className={`w-2 h-2 rounded-full ${isOnline ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'}`} />
              <span>{isOnline ? 'SYSTEM ONLINE' : 'OFFLINE MODE'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. NERA Brand Header */}
      <div className="px-4 sm:px-6 lg:px-8 py-3 bg-white">
        <div className="max-w-[1440px] mx-auto flex items-center justify-between gap-4">
          {/* Logo & Platform Name */}
          <Link href="/" className="flex items-center gap-3.5 group cursor-pointer">
            <span className="text-3xl sm:text-4xl font-black text-[#213d77] tracking-tight group-hover:text-[#1b3162] transition-colors">
              NERA
            </span>
            <div className="border-l-2 border-slate-300 pl-3">
              <h1 className="text-base sm:text-lg font-black text-slate-900 tracking-tight leading-tight">
                North Eastern Resilience and Accessibility
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                Emergency Logistics & Disaster Accessibility Platform
              </p>
            </div>
          </Link>

          {/* Center/Right Status & SIH Prototype Badge */}
          <div className="flex items-center gap-5">
            {/* Live Data Badge */}
            <div className="hidden md:flex items-center gap-3 bg-slate-50 border border-slate-200 px-3.5 py-1.5 rounded-lg">
              <div className="bg-[#213d77] text-white text-xs font-black font-mono px-2 py-0.5 rounded flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-ping" />
                <span>LIVE DATA</span>
              </div>
              <div className="text-xs text-slate-600 font-mono">
                <span>Data Status: <strong className="text-slate-900 font-bold">LIVE</strong></span>
                <span className="text-slate-400 block text-[11px]">Last Updated: {timeStr}</span>
              </div>
            </div>

            {/* SIH Stamp */}
            <div className="flex items-center gap-3 text-right">
              <div>
                <p className="text-xs sm:text-sm font-black text-[#213d77] tracking-tight">
                  SMART INDIA HACKATHON 2026
                </p>
                <p className="text-[11px] font-mono text-slate-500 uppercase tracking-wider font-bold">
                  DEMONSTRATION PROTOTYPE
                </p>
              </div>
              <div className="w-11 h-11 rounded-full bg-[#213d77] border-2 border-[#fb792b] flex items-center justify-center text-white shadow-xs shrink-0 font-mono text-xs font-black">
                🇮🇳
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* 3. Saffron/Tricolor Accent Line */}
      <div className="h-1 bg-[#fb792b] w-full" />
    </header>
  )
}
