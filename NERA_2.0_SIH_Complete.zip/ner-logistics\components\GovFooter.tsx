'use client'

import Link from 'next/link'
import { Shield, Phone } from 'lucide-react'
import { useLanguage } from '@/lib/LanguageContext'

export default function GovFooter() {
  const { t } = useLanguage()

  return (
    <footer className="w-full bg-[#1b3162] text-slate-300 border-t border-[#213d77] text-xs sm:text-[13px] select-none mt-auto">
      {/* Tri-color Accent Bar */}
      <div className="gov-tricolor" />

      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 pb-8 border-b border-slate-700/80">
          {/* Col 1: Brand & Scope */}
          <div className="space-y-3 md:col-span-2">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-[#213d77] rounded flex items-center justify-center text-white border border-amber-500/60 shrink-0">
                <Shield className="w-5 h-5 text-[#fb792b]" />
              </div>
              <div>
                <strong className="text-white text-base sm:text-lg block leading-tight">{t('brand_title')}</strong>
                <span className="text-xs sm:text-sm text-slate-300">{t('brand_subtitle')}</span>
              </div>
            </div>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed max-w-xl">
              AI-assisted emergency logistics response planning, vehicle physical safety gates, dynamic road corridor rerouting, and last-mile accessibility platform designed for the North Eastern Region of India.
            </p>
            <div className="inline-block bg-[#13254d] text-amber-300 text-xs font-mono px-3 py-1.5 rounded border border-amber-700/60 font-bold">
              SMART INDIA HACKATHON 2026 • DEMONSTRATION PROTOTYPE
            </div>
          </div>

          {/* Col 2: Operational Modules */}
          <div className="space-y-3">
            <strong className="text-white text-xs sm:text-sm font-bold uppercase tracking-wider block border-b border-slate-700 pb-1 text-[#fb792b]">OPERATIONS</strong>
            <ul className="space-y-2 text-xs sm:text-[13.5px] text-slate-200">
              <li><Link href="/dashboard" className="hover:text-white hover:underline transition-colors">{t('nav_dashboard')}</Link></li>
              <li><Link href="/map" className="hover:text-white hover:underline transition-colors">{t('nav_map')}</Link></li>
              <li><Link href="/incidents" className="hover:text-white hover:underline transition-colors">{t('nav_incidents')}</Link></li>
              <li><Link href="/missions" className="hover:text-white hover:underline transition-colors">{t('nav_missions')}</Link></li>
              <li><Link href="/vehicles" className="hover:text-white hover:underline transition-colors">{t('nav_vehicles')}</Link></li>
            </ul>
          </div>

          {/* Col 3: Governance & Help */}
          <div className="space-y-3">
            <strong className="text-white text-xs sm:text-sm font-bold uppercase tracking-wider block border-b border-slate-700 pb-1 text-[#fb792b]">GOVERNANCE & SUPPORT</strong>
            <ul className="space-y-2 text-xs sm:text-[13.5px] text-slate-200">
              <li><Link href="/report" className="hover:text-white hover:underline transition-colors">{t('nav_report')}</Link></li>
              <li><Link href="/audit" className="hover:text-white hover:underline transition-colors">{t('nav_audit')}</Link></li>
              <li><Link href="/notifications" className="hover:text-white hover:underline transition-colors">{t('nav_alerts')}</Link></li>
              <li><Link href="/system" className="hover:text-white hover:underline transition-colors">{t('nav_system')}</Link></li>
              <li><Link href="/demo" className="hover:text-amber-300 font-bold transition-colors">{t('nav_demo')}</Link></li>
            </ul>

            <div className="pt-2">
              <div className="flex items-center gap-2 text-amber-300 text-xs sm:text-sm font-bold bg-[#13254d] px-3 py-1.5 rounded border border-amber-700/60 w-fit">
                <Phone className="w-4 h-4 text-[#fb792b]" />
                <span>{t('gov_helpline')}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Disclaimer */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <p>
            © 2026 NERA Logistics Prototype. Official Government Information Architecture.
          </p>
          <p className="font-mono text-xs text-slate-400">
            Designed for SIH 2026 • 8 NER States Coverage
          </p>
        </div>
      </div>
    </footer>
  )
}

