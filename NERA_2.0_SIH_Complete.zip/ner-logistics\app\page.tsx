'use client'

import Link from 'next/link'
import {
  Shield,
  MapPin,
  Compass,
  Truck,
  AlertTriangle,
  FileText,
  Activity,
  ArrowRight,
  Sparkles,
  Search,
} from 'lucide-react'
import { useLanguage } from '@/lib/LanguageContext'

export default function LandingPage() {
  const { t, language } = useLanguage()

  const portalModules = [
    {
      title: t('nav_dashboard'),
      desc: language === 'hi' ? 'एकीकृत निर्णय सहायता केंद्र, क्षेत्रीय प्राथमिकता बोर्ड और संकट नियंत्रण कक्ष।' :
            language === 'as' ? 'একত্ৰিত সিদ্ধান্ত সহায় কেন্দ্ৰ, আঞ্চলিক অগ্ৰাধিকাৰ বোৰ্ড আৰু সংকট নিয়ন্ত্ৰণ কোঠা।' :
            language === 'bn' ? 'সমন্বিত সিদ্ধান্ত সহায়তা কেন্দ্র, আঞ্চলিক অগ্রাধিকার বোর্ড ও সংকট নিয়ন্ত্রণ।' :
            language === 'mn' ? 'ꯑꯄꯨꯅꯕꯥ ꯋꯥꯔꯦꯞ ꯃꯇꯦꯡ ꯁꯦꯟꯇꯔ ꯑꯃꯁꯨꯡ ꯈꯨꯗꯣꯡꯊꯤꯕꯥ ꯀꯟꯇ꯭ꯔꯣꯜ꯫' :
            'Unified decision support center, regional priority attention board, and crisis decision panel.',
      href: '/dashboard',
      icon: Activity,
      badge: 'OPERATIONS',
    },
    {
      title: t('nav_map'),
      desc: language === 'hi' ? 'वास्तविक सड़क ओएसआरएम गतिशील रूटिंग, पुष्टि की गई सड़क रुकावटें और वीएपी पहुंच।' :
            language === 'as' ? 'প্ৰকৃত পথ OSRM গতিশীল ৰুটিং, নিশ্চিত পথ বন্ধ আৰু VAP প্ৰৱেশাধিকাৰ।' :
            language === 'bn' ? 'বাস্তব সড়ক OSRM গতিশীল রাউটিং, নিশ্চিত পথ অবরুদ্ধ ও VAP অ্যাক্সেস।' :
            language === 'mn' ? 'ꯑꯁꯦꯡꯕꯥ ꯂꯝꯕꯤ OSRM ꯂꯝꯕꯤ ꯊꯤꯕꯥ ꯑꯃꯁꯨꯡ VAP ꯌꯧꯕꯥ꯫' :
            'Real-road OSRM dynamic Dijkstra routing, active confirmed closures, and last-mile VAP access.',
      href: '/map',
      icon: MapPin,
      badge: 'GIS ROUTING',
    },
    {
      title: t('nav_missions'),
      desc: language === 'hi' ? 'आपातकालीन राहत मिशन जीवनचक्र, आधिकारिक अनुमोदन, पुनः रूटिंग और कार्गो हैंडओवर।' :
            language === 'as' ? 'জৰুৰীকালীন সাহায্য অভিযান জীৱনচক্ৰ, চৰকাৰী অনুমোদন, পুনৰ পথ নিৰ্ধাৰণ।' :
            language === 'bn' ? 'জরুরী ত্রাণ মিশন লাইফসাইকেল, সরকারী অনুমোদন, পথ পুনর্গঠন ও কার্গো হস্তান্তর।' :
            language === 'mn' ? 'ꯏꯃꯔꯖꯦꯟꯁꯤ ꯃꯤꯁꯟ, ꯁꯔꯀꯥꯔꯤ ꯑꯌꯥꯕꯥ ꯑꯃꯁꯨꯡ ꯄꯣꯠ-ꯆꯩ ꯄꯤꯁꯤꯟꯕꯥ꯫' :
            'Emergency relief mission lifecycle, official approvals, in-transit rerouting, and cargo handover.',
      href: '/missions',
      icon: Compass,
      badge: 'DISPATCH',
    },
    {
      title: t('nav_vehicles'),
      desc: language === 'hi' ? '8-बिंदु भौतिक वाहन सुरक्षा गेट और एआई भविष्यसूचक रखरखाव जोखिम मूल्यांकन।' :
            language === 'as' ? '৮-পইণ্ট ভৌতিক বাহন সুৰক্ষা গেট আৰু AI পূৰ্বানুমানভিত্তিক পৰীক্ষণ।' :
            language === 'bn' ? '৮-পয়েন্ট শারীরিক যান নিরাপত্তা গেট এবং AI পূর্বাভাস রক্ষণাবেক্ষণ।' :
            language === 'mn' ? '꯸-ꯄꯣꯏꯟꯇ ꯒꯥꯔꯤ ꯁꯦꯐꯇꯤ ꯒꯦꯠ ꯑꯃꯁꯨꯡ AI ꯌꯦꯡꯁꯤꯟꯕꯥ꯫' :
            '8-Point physical vehicle safety gate separated from AI predictive maintenance risk assessment.',
      href: '/vehicles',
      icon: Truck,
      badge: 'FLEET',
    },
    {
      title: t('nav_incidents'),
      desc: language === 'hi' ? 'सटीक आपदा जीवनचक्र: पूर्वानुमानित जोखिम -> फील्ड रिपोर्ट -> आधिकारिक पुष्टि।' :
            language === 'as' ? 'নিৰ্ধাৰিত দুৰ্যোগ জীৱনচক্ৰ: পূৰ্বানুমান -> ফিল্ড ৰিপৰ্ট -> চৰকাৰী নিশ্চিতকৰণ।' :
            language === 'bn' ? 'দুর্যোগ লাইফসাইকেল: পূর্বাভাসের ঝুঁকি -> ফিল্ড রিপোর্ট -> সরকারী নিশ্চিতকরণ।' :
            language === 'mn' ? 'ꯈꯨꯗꯣꯡꯊꯤꯕꯥ ꯊꯧꯗꯣꯛ: ꯄꯥꯎꯗꯝ -> ꯔꯤꯄꯣꯔꯠ -> ꯁꯔꯀꯥꯔꯤ ꯈꯪꯗꯣꯛꯄꯥ꯫' :
            'Deterministic hazard lifecycle: Predicted Risk -> Field Report -> Official Confirmation -> Route Impact.',
      href: '/incidents',
      icon: AlertTriangle,
      badge: 'INCIDENTS',
    },
    {
      title: t('nav_report'),
      desc: language === 'hi' ? 'दूरस्थ पहाड़ी क्षेत्रों के लिए ऑफ़लाइन IndexedDB बफरिंग के साथ भू-टैग की गई रिपोर्टिंग।' :
            language === 'as' ? 'দূৰৱৰ্তী পাহাৰীয়া এলেকাৰ বাবে অফলাইন IndexedDB বাফাৰিঙৰ সৈতে জিঅ’-টেগ ৰিপৰ্ট।' :
            language === 'bn' ? 'দূরবর্তী পার্বত্য এলাকার জন্য অফলাইন IndexedDB সহ জিও-ট্যাগ করা রিপোর্টিং।' :
            language === 'mn' ? 'ꯆꯤꯡꯒꯤ ꯃꯐꯝꯁꯤꯡꯒꯤꯗꯃꯛ ꯑꯣꯐꯂꯥꯏꯟ IndexedDB ꯄꯥꯎ ꯄꯤꯕꯥ꯫' :
            'Geotagged hazard reporting with offline IndexedDB buffering for remote mountainous areas.',
      href: '/report',
      icon: FileText,
      badge: 'FIELD SYNC',
    },
  ]

  return (
    <div className="space-y-6">
      {/* ── 1. IRCTC-Style Government Hero & Emergency Dispatch Box ── */}
      <div className="gov-card p-5 sm:p-6 bg-gradient-to-r from-white via-slate-50 to-blue-50/40 border border-slate-200">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Left Column: Official Welcome & Title */}
          <div className="lg:col-span-7 space-y-3">
            <div className="inline-flex items-center gap-1.5 bg-[#213d77]/10 text-[#213d77] border border-[#213d77]/20 px-2.5 py-0.5 rounded text-xs font-bold">
              <Shield className="w-3.5 h-3.5 text-[#fb792b]" />
              <span>{t('portal_title')}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black text-[#213d77] tracking-tight leading-tight">
              {t('brand_subtitle')}
            </h1>

            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              {language === 'hi' ? 'पूर्वोत्तर के 8 राज्यों के लिए राष्ट्रीय एआई-सहायता प्राप्त आपातकालीन आपूर्ति श्रृंखला समन्वय, वास्तविक सड़क गतिशील पुनः रूटिंग और अंतिम-मील पहुंच मंच।' :
               language === 'as' ? 'উত্তৰ-পূবৰ ৮ খন ৰাজ্যৰ বাবে ৰাষ্ট্ৰীয় AI-সহায়তাপ্ৰাপ্ত জৰুৰীকালীন যোগান শৃংখল সমন্বয়, প্ৰকৃত পথ পুনৰ নিৰ্ধাৰণ আৰু অন্তিম-মাইল প্ৰৱেশাধিকাৰ মঞ্চ।' :
               language === 'bn' ? 'উত্তর-পূর্বের ৮টি রাজ্যের জন্য জাতীয় AI-সহায়তাপ্রাপ্ত জরুরি সরবরাহ শৃঙ্খল সমন্বয়, রিয়েল-রোড গতিশীল পথ পুনর্গঠন প্ল্যাটফর্ম।' :
               language === 'mn' ? 'ꯑꯋꯥꯡ-ꯅꯣꯡꯄꯣꯛ ꯔꯥꯖ꯭ꯌ ꯸ ꯒꯤꯗꯃꯛ ꯂꯩꯉꯥꯛꯀꯤ AI ꯃꯇꯦꯡ ꯂꯣꯖꯤꯁ꯭ꯇꯤꯛꯁ ꯄ꯭ꯂꯦꯠꯐꯣꯔꯝ꯫' :
               'National AI-assisted emergency supply chain coordination, real-road dynamic rerouting, physical vehicle readiness safety gates, and last-mile accessibility platform for the 8 North Eastern States.'}
            </p>

            <div className="flex flex-wrap items-center gap-2.5 pt-1">
              <Link
                href="/dashboard"
                className="btn-irctc-primary text-xs px-4 py-2.5 flex items-center gap-1.5 cursor-pointer"
              >
                <Activity className="w-4 h-4" />
                <span>{t('command_center_hero')}</span>
                <ArrowRight className="w-4 h-4 ml-1" />
              </Link>
              <Link
                href="/map"
                className="btn-irctc-navy text-xs px-4 py-2.5 flex items-center gap-1.5 cursor-pointer"
              >
                <MapPin className="w-4 h-4 text-[#fb792b]" />
                <span>{t('live_gis_map_btn')}</span>
              </Link>
              <Link
                href="/demo"
                className="bg-white hover:bg-slate-50 text-[#213d77] border border-slate-300 font-bold text-xs px-3.5 py-2.5 rounded flex items-center gap-1.5 shadow-xs cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#fb792b]" />
                <span>{t('sih_walkthrough_btn')}</span>
              </Link>
            </div>
          </div>

          {/* Right Column: IRCTC-Style Quick Route / Mission Verification Card */}
          <div className="lg:col-span-5">
            <div className="bg-white border-2 border-[#213d77]/30 rounded-lg p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                <span className="text-xs font-black text-[#213d77] uppercase tracking-wide flex items-center gap-1.5">
                  <Search className="w-4 h-4 text-[#fb792b]" />
                  {t('quick_search')}
                </span>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  REAL-TIME AIS-140
                </span>
              </div>

              <div className="space-y-2 text-xs">
                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">{t('origin_depot')}</label>
                  <select className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-slate-800 font-semibold focus:outline-none focus:border-[#fb792b]">
                    <option>Guwahati Apex Logistics Hub (Assam)</option>
                    <option>Siliguri Corridor Rail Gateway (WB/NER)</option>
                    <option>Silchar Barak Valley Center (Assam)</option>
                    <option>Tezpur Central Supply Depot (Assam)</option>
                    <option>Dimapur Freight Terminal (Nagaland)</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-bold text-slate-500 uppercase block mb-0.5">{t('dest_sector')}</label>
                  <select className="w-full bg-slate-50 border border-slate-300 rounded p-1.5 text-slate-800 font-semibold focus:outline-none focus:border-[#fb792b]">
                    <option>Majuli Flood Relief Camp (Assam)</option>
                    <option>Haflong DEOC Emergency Center (Dima Hasao)</option>
                    <option>Tawang Strategic Forward Sector (Arunachal)</option>
                    <option>Aizawl Emergency Supply Center (Mizoram)</option>
                    <option>Imphal Regional Medical Complex (Manipur)</option>
                  </select>
                </div>

                <Link
                  href="/missions"
                  className="w-full btn-irctc-primary text-xs py-2 flex items-center justify-center gap-1.5 mt-2 cursor-pointer font-bold"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{t('verify_mission_route')}</span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── 2. Regional KPI Strip (IRCTC Government Style) ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
        {[
          { label: 'NER States Monitored', value: '8 States', sub: 'Assam, Meghalaya, AP, MN, MZ, NL, SK, TR' },
          { label: 'Strategic Corridors', value: '27 Highways', sub: 'NH-27, NH-715, NH-102, NH-37...' },
          { label: 'Deployment Safety', value: '8-Point Gate', sub: 'Mechanical, Comms & Brakes' },
          { label: 'Disaster Emergency', value: 'Toll-Free 1078', sub: '24x7 State Emergency Centers' },
        ].map(({ label, value, sub }) => (
          <div key={label} className="gov-card p-3">
            <span className="text-base sm:text-xl font-black text-[#213d77] font-mono block">{value}</span>
            <strong className="text-xs font-bold text-slate-700 block mt-0.5">{label}</strong>
            <span className="text-[10px] text-slate-400 block mt-0.5">{sub}</span>
          </div>
        ))}
      </div>

      {/* ── 3. Operational Portals Grid ── */}
      <div className="space-y-3">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <h2 className="text-sm sm:text-base font-black text-[#213d77] uppercase tracking-wide">
            OPERATIONAL LOGISTICS MODULES
          </h2>
          <span className="text-xs text-slate-500 font-semibold">Government of India Standard Architecture</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {portalModules.map(({ title, desc, href, icon: Icon, badge }) => (
            <Link
              key={title}
              href={href}
              className="gov-card p-4 hover:border-[#fb792b] hover:shadow-md transition-all group flex flex-col justify-between"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="w-8 h-8 rounded bg-slate-100 text-[#213d77] flex items-center justify-center group-hover:bg-[#213d77] group-hover:text-white transition-colors">
                    <Icon className="w-4 h-4" />
                  </div>
                  <span className="text-[9px] font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                    {badge}
                  </span>
                </div>
                <h3 className="font-bold text-sm text-[#213d77] group-hover:text-[#fb792b] transition-colors">
                  {title}
                </h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {desc}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center text-xs font-bold text-[#213d77] group-hover:text-[#fb792b] transition-colors mt-3">
                <span>Access Module</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1 group-hover:translate-x-1 transition-transform" />
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  )
}
