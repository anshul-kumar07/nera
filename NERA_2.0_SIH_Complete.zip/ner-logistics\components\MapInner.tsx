'use client'

import { useEffect, useState } from 'react'
import { MapContainer, TileLayer, Polyline, Marker, Popup, Polygon, useMap, useMapEvents } from 'react-leaflet'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import { INITIAL_NER_ROUTES, NER_STRATEGIC_PASSES, NER_STRATEGIC_BRIDGES } from '@/lib/data'
import { calculateHaversineKm, ActiveRoute, MultiModalVehicleTelemetry } from '@/lib/routing-algorithm'
import { useLanguage } from '@/lib/LanguageContext'
import { Incident } from '@/lib/supabase'
import { LastMileAccessibility } from '@/lib/last-mile'
import { evaluateVehicleReadiness } from '@/lib/vehicle-readiness'
import { ConnectionStatus } from '@/hooks/useRealtimeIncidents'
import {
  Layers,
  Crosshair,
  Plus,
  Minus,
  Search,
  X,
  Target,
  Truck,
  Play,
  Pause,
  RotateCcw,
  Navigation,
} from 'lucide-react'

// Fix default Leaflet icon paths
delete (L.Icon.Default.prototype as L.Icon.Default & { _getIconUrl?: () => string })._getIconUrl
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
})

// ── SVG Marker & Translucent Badge Creators ──

// High-visibility Google Maps style National Highway shield badge
const createHighwayLabelIcon = (highwayNum: string, status: string) => {
  const isBlocked = status === 'blocked'
  const isAtRisk = status === 'at_risk'

  const bg = isBlocked
    ? '#dc2626'
    : isAtRisk
    ? '#d97706'
    : '#ffffff'

  const textColor = isBlocked || isAtRisk ? '#ffffff' : '#0f172a'
  const border = isBlocked
    ? '1.5px solid #ffffff'
    : isAtRisk
    ? '1.5px solid #ffffff'
    : '1.5px solid #16a34a'

  const html = `
    <div style="transform: translate(-50%, -50%); pointer-events: none; user-select: none;">
      <div style="background: ${bg}; color: ${textColor}; font-family: system-ui, -apple-system, sans-serif; font-size: 11px; font-weight: 800; padding: 2px 7px; border-radius: 6px; border: ${border}; box-shadow: 0 2px 8px rgba(0,0,0,0.28); white-space: nowrap; letter-spacing: 0.2px; display: flex; align-items: center; gap: 3px;">
        ${highwayNum}
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'highway-visible-badge', iconSize: [0, 0] })
}

const createOriginHubIcon = () => {
  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer;">
      <div style="width: 32px; height: 32px; background: #213d77; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 10px rgba(33,61,119,0.5); font-size: 15px; color: white;">
        🏛️
      </div>
      <div style="background: #ffffff; color: #213d77; font-size: 9.5px; font-weight: 800; padding: 2px 7px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1.5px solid #213d77; box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
        SUPPLY ORIGIN HUB
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-origin-marker', iconSize: [0, 0] })
}

const createTargetCrisisIcon = () => {
  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer;">
      <div style="width: 34px; height: 34px; background: #dc2626; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 12px rgba(220,38,38,0.5); font-size: 16px; color: white; animation: pulse 2s infinite;">
        🎯
      </div>
      <div style="background: #ffffff; color: #dc2626; font-size: 9.5px; font-weight: 800; padding: 2px 7px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1.5px solid #dc2626; box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
        CRISIS DESTINATION
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-target-marker', iconSize: [0, 0] })
}

const createVehicleAccessPointIcon = () => {
  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 950;">
      <div style="width: 32px; height: 32px; background: #213d77; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 10px rgba(33,61,119,0.5); font-size: 15px; color: white;">
        🚛
      </div>
      <div style="background: #ffffff; color: #213d77; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1.5px solid #213d77; box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
        VEHICLE ACCESS POINT
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-vap-marker', iconSize: [0, 0] })
}

const createLastMileCrisisIcon = () => {
  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 950;">
      <div style="width: 34px; height: 34px; background: #ea580c; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 12px rgba(234,88,12,0.5); font-size: 15px; color: white; animation: pulse 2s infinite;">
        🚨
      </div>
      <div style="background: #ffffff; color: #ea580c; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1.5px solid #ea580c; box-shadow: 0 2px 6px rgba(0,0,0,0.15);">
        CRISIS LOCATION (LAST-MILE)
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-lastmile-target-marker', iconSize: [0, 0] })
}

const createBlockedHazardIcon = () => {
  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 1000;">
      <div style="position: absolute; width: 38px; height: 38px; border-radius: 50%; background: #dc2626; opacity: 0.35; animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="width: 28px; height: 28px; background: #dc2626; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 10px rgba(220,38,38,0.6); font-size: 13px; color: white; z-index: 2;">
        ⛔
      </div>
      <div style="background: #ffffff; color: #dc2626; font-family: system-ui, sans-serif; font-size: 9px; font-weight: 800; padding: 1.5px 6px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1.5px solid #dc2626; box-shadow: 0 2px 6px rgba(0,0,0,0.15); display: flex; align-items: center; gap: 2px; z-index: 3;">
        <span>BLOCKED CORRIDOR</span>
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-hazard-marker', iconSize: [0, 0] })
}

// Strategic Mountain Pass Marker Icon
const createStrategicPassIcon = (name: string, status: string, elevationFt: number) => {
  const isClosed = status === 'closed' || status === 'blocked'
  const isAtRisk = status === 'at_risk' || status === 'restricted'
  const badgeBg = isClosed ? '#dc2626' : isAtRisk ? '#d97706' : '#2563eb'

  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 800;">
      <div style="width: 28px; height: 28px; background: ${badgeBg}; border: 2px solid #ffffff; border-radius: 6px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.4); font-size: 14px; color: white;">
        🏔️
      </div>
      <div style="background: rgba(15,23,42,0.92); color: #e2e8f0; font-size: 9px; font-weight: 700; padding: 1px 5px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1px solid ${badgeBg}; box-shadow: 0 2px 6px rgba(0,0,0,0.4);">
        ${elevationFt} ft
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-pass-marker', iconSize: [0, 0] })
}

// Strategic Bridge Marker Icon
const createStrategicBridgeIcon = (name: string, status: string, maxWeightTons: number) => {
  const isDamaged = status === 'damaged' || status === 'blocked'
  const isAtRisk = status === 'at_risk' || status === 'restricted'
  const badgeBg = isDamaged ? '#dc2626' : isAtRisk ? '#d97706' : '#0891b2'

  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 800;">
      <div style="width: 28px; height: 28px; background: ${badgeBg}; border: 2px solid #ffffff; border-radius: 6px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(0,0,0,0.4); font-size: 14px; color: white;">
        🌉
      </div>
      <div style="background: rgba(15,23,42,0.92); color: #38bdf8; font-size: 9px; font-weight: 700; padding: 1px 5px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1px solid ${badgeBg}; box-shadow: 0 2px 6px rgba(0,0,0,0.4);">
        ${maxWeightTons}T Max
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-bridge-marker', iconSize: [0, 0] })
}

// Live Supabase Incident Marker (Differentiates PREDICTED, REPORTED, CONFIRMED)
const createLiveIncidentIcon = (type: string = 'landslide', severity: string = 'high', status: string = 'reported') => {
  const isPredicted = status === 'predicted'
  const isConfirmed = status === 'confirmed'
  const isCritical = severity === 'critical'

  const emoji =
    type === 'landslide' ? '🏔️' :
    type === 'flood' ? '🌊' :
    type === 'bridge_failure' ? '🌉' :
    type === 'road_damage' ? '🛣️' : '⚠️'

  const bgColor = isConfirmed ? '#dc2626' : isPredicted ? '#d97706' : '#ea580c'
  const badgeText = isConfirmed ? 'CONFIRMED' : isPredicted ? 'PREDICTED' : 'REPORTED'

  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 1100;">
      <div style="position: absolute; width: ${isCritical ? '40px' : '34px'}; height: ${isCritical ? '40px' : '34px'}; border-radius: 50%; background: ${bgColor}; opacity: 0.35; animation: ping ${isCritical ? '1.2s' : '2s'} cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      <div style="width: 26px; height: 26px; background: ${bgColor}; border: 2px solid ${isCritical ? '#fef08a' : '#ffffff'}; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 3px 12px rgba(0,0,0,0.5); font-size: 13px; color: white; z-index: 2;">
        ${emoji}
      </div>
      <div style="background: rgba(15,23,42,0.95); color: #ffffff; font-family: system-ui, sans-serif; font-size: 8.5px; font-weight: 800; padding: 1px 4px; border-radius: 4px; margin-top: 2px; white-space: nowrap; border: 1px solid ${bgColor}; box-shadow: 0 2px 6px rgba(0,0,0,0.4); display: flex; align-items: center; gap: 2px; z-index: 3;">
        ${badgeText}
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'live-incident-marker', iconSize: [0, 0] })
}

// Dynamic Animated Traveling Vehicle Marker with Directional Bearing Pointer
const createMovingVehicleIcon = (
  transportMode: string,
  vehicleNumber: string,
  etaFormatted: string,
  headingDeg: number = 0,
  isRerouting: boolean = false
) => {
  const isAir = transportMode === 'air_helicopter'
  const isHeavy = transportMode === 'heavy_road_convoy'
  const isHill = transportMode === 'hill_4x4_freight'

  const iconEmoji = isAir ? '🚁' : isHeavy ? '🚛' : isHill ? '🚚' : '🚐'
  const bgColor = isRerouting ? '#dc2626' : isAir ? '#0284c7' : isHeavy ? '#16a34a' : isHill ? '#d97706' : '#2563eb'
  const badgeColor = isRerouting ? '#fca5a5' : isAir ? '#38bdf8' : isHeavy ? '#4ade80' : isHill ? '#fbbf24' : '#60a5fa'
  const statusLabel = isRerouting ? 'REROUTING' : isAir ? 'IAF AIRLIFT' : 'IN TRANSIT'

  const html = `
    <div style="position: relative; display: flex; flex-direction: column; align-items: center; transform: translate(-50%, -50%); cursor: pointer; z-index: 1200;">
      <!-- Glowing Beacon Pulse Ring -->
      <div style="position: absolute; width: 44px; height: 44px; border-radius: 50%; background: ${bgColor}; opacity: 0.3; animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      
      <!-- Directional Pointer Arrow Ring (Oriented to road bearing) -->
      <div style="position: absolute; width: 42px; height: 42px; display: flex; align-items: flex-start; justify-content: center; transform: rotate(${headingDeg}deg); transition: transform 0.2s linear; pointer-events: none; z-index: 1;">
        <div style="width: 0; height: 0; border-left: 5px solid transparent; border-right: 5px solid transparent; border-bottom: 9px solid ${bgColor}; filter: drop-shadow(0 1px 2px rgba(0,0,0,0.6)); transform: translateY(-5px);"></div>
      </div>

      <!-- Vehicle Circular Icon -->
      <div style="width: 36px; height: 36px; background: ${bgColor}; border: 2.5px solid #ffffff; border-radius: 50%; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 16px rgba(0,0,0,0.6); font-size: 18px; z-index: 2;">
        ${iconEmoji}
      </div>

      <!-- Live Transit Tag -->
      <div style="background: rgba(15,23,42,0.95); color: ${badgeColor}; font-family: system-ui, sans-serif; font-size: 9px; font-weight: 800; padding: 2px 6px; border-radius: 5px; margin-top: 3px; white-space: nowrap; border: 1.5px solid ${bgColor}; box-shadow: 0 3px 12px rgba(0,0,0,0.5); display: flex; align-items: center; gap: 3px; z-index: 3;">
        <span>${statusLabel}</span> • <span>${etaFormatted || 'EN ROUTE'}</span>
      </div>
    </div>
  `
  return L.divIcon({ html, className: 'custom-moving-vehicle-marker', iconSize: [0, 0] })
}

// Map Tile Layers
const TILE_LAYERS = {
  voyager: {
    name: '🚗 Navigation (OSM)',
    url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> & CARTO',
  },
  osm: {
    name: '🗺️ OpenStreetMap Standard',
    url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
  },
  satellite: {
    name: '🛰️ Satellite Imagery',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
    attribution: '&copy; Esri World Imagery, NASA, USGS',
  },
  topo: {
    name: '🏔️ 3D Mountain Terrain',
    url: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png',
    attribution: '&copy; OpenTopoMap & OpenStreetMap',
  },
  dark: {
    name: '🌌 Dark Tactical',
    url: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
    attribution: '&copy; CartoDB & OpenStreetMap',
  },
}

// State Focus Centers
const STATE_HUBS: Record<string, [number, number, number]> = {
  All: [25.7, 92.8, 7],
  Assam: [26.1445, 91.7362, 8],
  Meghalaya: [25.5788, 91.8933, 8],
  Manipur: [24.8170, 93.9368, 8],
  Mizoram: [23.7271, 92.7176, 8],
  Nagaland: [25.9043, 93.7440, 8],
  Tripura: [23.8315, 91.2868, 8],
  Arunachal: [27.0844, 93.6053, 7],
  Sikkim: [27.3389, 88.6065, 9],
}

// NER 8-State Geographic Boundary
const NER_ZONE_POLYGON: [number, number][] = [
  [27.9, 88.1], [27.7, 88.9], [27.1, 88.9], [27.0, 88.5],
  [26.7, 89.2], [26.0, 89.7],
  [25.1, 90.1], [25.1, 91.2], [25.1, 92.2],
  [24.3, 92.1], [23.8, 91.2], [23.1, 91.4], [23.0, 91.8], [23.5, 92.2],
  [22.8, 92.6], [21.9, 92.9], [22.2, 93.3], [23.4, 93.4],
  [24.2, 94.3], [24.8, 94.4], [25.5, 94.6],
  [25.8, 94.9], [26.5, 95.2], [26.9, 95.3],
  [27.4, 96.2], [27.9, 97.2], [28.2, 97.4], [28.8, 96.8],
  [29.3, 95.5], [29.0, 94.0], [28.5, 93.2], [28.0, 92.0], [27.6, 91.6],
  [26.9, 91.5], [26.8, 90.0]
]

// Interpolate exact continuous lat/lng and heading along polyline path given progress 0..1
function interpolatePositionAndHeading(
  coords: [number, number][],
  progress: number
): { position: [number, number]; headingDeg: number } {
  if (!coords || coords.length === 0) return { position: [26.1445, 91.7362], headingDeg: 0 }
  if (coords.length === 1) return { position: coords[0], headingDeg: 0 }
  if (progress <= 0) {
    const bearing = ((Math.atan2(coords[1][1] - coords[0][1], coords[1][0] - coords[0][0]) * 180) / Math.PI + 360) % 360
    return { position: coords[0], headingDeg: Math.round(bearing) }
  }
  if (progress >= 1) {
    const last = coords.length - 1
    const bearing = ((Math.atan2(coords[last][1] - coords[last - 1][1], coords[last][0] - coords[last - 1][0]) * 180) / Math.PI + 360) % 360
    return { position: coords[last], headingDeg: Math.round(bearing) }
  }

  const distances: number[] = [0]
  let totalDist = 0
  for (let i = 0; i < coords.length - 1; i++) {
    const d = calculateHaversineKm(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1])
    totalDist += d
    distances.push(totalDist)
  }

  if (totalDist === 0) return { position: coords[0], headingDeg: 0 }
  const targetDist = progress * totalDist

  for (let i = 0; i < distances.length - 1; i++) {
    if (targetDist >= distances[i] && targetDist <= distances[i + 1]) {
      const segStart = distances[i]
      const segEnd = distances[i + 1]
      const segLen = segEnd - segStart
      const segT = segLen === 0 ? 0 : (targetDist - segStart) / segLen

      const p1 = coords[i]
      const p2 = coords[i + 1]
      const lat = p1[0] + (p2[0] - p1[0]) * segT
      const lng = p1[1] + (p2[1] - p1[1]) * segT
      const heading = ((Math.atan2(p2[1] - p1[1], p2[0] - p1[0]) * 180) / Math.PI + 360) % 360
      return { position: [lat, lng], headingDeg: Math.round(heading) }
    }
  }

  return { position: coords[coords.length - 1], headingDeg: 0 }
}

interface MapInnerProps {
  routes?: ActiveRoute[]
  highlightedRouteName?: string
  blockedRouteName?: string
  missionPathCoordinates?: [number, number][] | null
  originCoords?: { lat: number; lng: number; name: string } | null
  targetCoords?: { lat: number; lng: number; name: string } | null
  isCrisisActive?: boolean
  animationEnabled?: boolean
  vehicleTelemetry?: MultiModalVehicleTelemetry | null
  activeIncidents?: Incident[]
  lastMileAccessibility?: LastMileAccessibility | null
  connectionStatus?: ConnectionStatus
  lastSync?: Date | null
  baseLayer?: string
  showRoadNetwork?: boolean
  showIncidents?: boolean
  showRiskPredictions?: boolean
  showVehicles?: boolean
  showVehicleAccessPoint?: boolean
  showAlternateRoute?: boolean
  showInfrastructure?: boolean
  onSelectRoute?: (routeName: string) => void
  onSelectTargetCoords?: (coords: { lat: number; lng: number }) => void
  onReportRouteStatus?: (routeName: string, status: 'blocked' | 'at_risk' | 'open') => void
  onConfirmIncident?: (id: string) => void
  onResolveIncident?: (id: string) => void
}

function MapControllerComponent({
  targetView,
  missionPathCoordinates,
  targetCoords,
  zoomAction,
  fitRouteTrigger,
}: {
  targetView: [number, number, number] | null
  missionPathCoordinates?: [number, number][] | null
  targetCoords?: { lat: number; lng: number; name: string } | null
  zoomAction: number | null
  fitRouteTrigger?: number
}) {
  const map = useMap()

  // Handle smooth programmatic state center flyTo
  useEffect(() => {
    if (targetView) {
      map.flyTo([targetView[0], targetView[1]], targetView[2], { duration: 1.4 })
    }
  }, [targetView, map])

  // Handle zooming actions (+ / -)
  useEffect(() => {
    if (zoomAction === 1) map.zoomIn()
    if (zoomAction === -1) map.zoomOut()
  }, [zoomAction, map])

  // Handle Auto-Fit Active Calculated Route to Screen Bounds
  useEffect(() => {
    if (missionPathCoordinates && missionPathCoordinates.length > 1) {
      try {
        const bounds = L.latLngBounds(missionPathCoordinates.map(c => [c[0], c[1]]))
        map.fitBounds(bounds, { padding: [70, 70], maxZoom: 11, animate: true, duration: 1.2 })
      } catch (err) {
        console.warn('Map fitBounds error:', err)
      }
    }
  }, [fitRouteTrigger, missionPathCoordinates, map])

  // Fly to new target depot when selected
  useEffect(() => {
    if (targetCoords) {
      map.flyTo([targetCoords.lat, targetCoords.lng], 9, { duration: 1.2 })
    }
  }, [targetCoords, map])

  return null
}

function MapClickEventsComponent({
  isPinModeActive,
  onSelectTargetCoords,
  onPinPlaced,
}: {
  isPinModeActive: boolean
  onSelectTargetCoords?: (coords: { lat: number; lng: number }) => void
  onPinPlaced: () => void
}) {
  useMapEvents({
    click(e) {
      if (isPinModeActive && onSelectTargetCoords) {
        onSelectTargetCoords({ lat: e.latlng.lat, lng: e.latlng.lng })
        onPinPlaced()
      }
    },
  })
  return null
}

export default function MapInner({
  routes = INITIAL_NER_ROUTES as ActiveRoute[],
  highlightedRouteName,
  blockedRouteName,
  missionPathCoordinates,
  originCoords,
  targetCoords,
  animationEnabled = true,
  vehicleTelemetry,
  activeIncidents = [],
  lastMileAccessibility,
  connectionStatus = 'OFFLINE',
  lastSync,
  baseLayer = 'voyager',
  showRoadNetwork = true,
  showIncidents: propShowIncidents,
  showRiskPredictions: propShowRiskPredictions,
  showVehicles: propShowVehicles = true,
  showVehicleAccessPoint: propShowVAP = true,
  showAlternateRoute: propShowAlt = true,
  showInfrastructure: propShowInfra,
  onSelectRoute,
  onSelectTargetCoords,
  onReportRouteStatus,
  onConfirmIncident,
  onResolveIncident,
}: MapInnerProps) {
  const { t } = useLanguage()
  const [currentLayer, setCurrentLayer] = useState<keyof typeof TILE_LAYERS>((baseLayer as keyof typeof TILE_LAYERS) || 'voyager')
  const [targetView, setTargetView] = useState<[number, number, number] | null>(null)
  const [zoomAction, setZoomAction] = useState<number | null>(null)
  const [fitRouteTrigger, setFitRouteTrigger] = useState<number>(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [layerDrawerOpen, setLayerDrawerOpen] = useState(false)
  const [isPinModeActive, setIsPinModeActive] = useState(false)

  // Sync external baseLayer prop if changed
  useEffect(() => {
    if (baseLayer && TILE_LAYERS[baseLayer as keyof typeof TILE_LAYERS]) {
      setCurrentLayer(baseLayer as keyof typeof TILE_LAYERS)
    }
  }, [baseLayer])

  // Layer Visibility Controls
  const [showInfrastructure, setShowInfrastructure] = useState(propShowInfra !== undefined ? propShowInfra : false)
  const [showActiveIncidents, setShowActiveIncidents] = useState(propShowIncidents !== undefined ? propShowIncidents : true)
  const [showRiskPredictions, setShowRiskPredictions] = useState(propShowRiskPredictions !== undefined ? propShowRiskPredictions : true)

  useEffect(() => {
    if (propShowInfra !== undefined) setShowInfrastructure(propShowInfra)
  }, [propShowInfra])

  useEffect(() => {
    if (propShowIncidents !== undefined) setShowActiveIncidents(propShowIncidents)
  }, [propShowIncidents])

  useEffect(() => {
    if (propShowRiskPredictions !== undefined) setShowRiskPredictions(propShowRiskPredictions)
  }, [propShowRiskPredictions])

  // ── Traveling Convoy Animation State ──
  const [simProgress, setSimProgress] = useState(0.0)
  const [isPlaying, setIsPlaying] = useState(true)
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1) // 1x, 3x, 8x

  // Animation Loop: smoothly moves the vehicle along missionPathCoordinates
  useEffect(() => {
    if (!animationEnabled || !missionPathCoordinates || missionPathCoordinates.length < 2 || !isPlaying) {
      return
    }

    const interval = setInterval(() => {
      setSimProgress(prev => {
        const step = 0.0008 * playbackSpeed // Smooth and realistic pace
        const next = prev + step
        return next >= 1.0 ? 0.0 : next // Loops back seamlessly
      })
    }, 40)

    return () => clearInterval(interval)
  }, [animationEnabled, missionPathCoordinates, isPlaying, playbackSpeed])

  // Current continuous coordinates & geodesic heading of the traveling vehicle
  const vehicleMotion = (missionPathCoordinates && missionPathCoordinates.length > 1)
    ? interpolatePositionAndHeading(missionPathCoordinates, simProgress)
    : null

  const currentVehiclePos = vehicleMotion ? vehicleMotion.position : null
  const currentVehicleHeading = vehicleMotion ? vehicleMotion.headingDeg : 0

  // Calculate live remaining distance & estimated time dynamically based on progress
  const totalMissionDistance = vehicleTelemetry?.totalDistanceKm || 350
  const remainingDistanceKm = Math.round(totalMissionDistance * (1 - simProgress))
  const completedPercentage = Math.round(simProgress * 100)

  // Filter routes by search if any
  const filteredRoutes = searchQuery.trim()
    ? routes.filter(
        r =>
          r.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.highway_number?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.district?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.state?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : routes

  return (
    <div className="relative w-full h-full font-sans select-none overflow-hidden">
      {/* ── UNIFIED NON-OVERLAPPING TOP BAR OVERLAY ── */}
      <div className="absolute top-3 left-3 right-3 z-[1000] pointer-events-none flex flex-wrap items-center justify-between gap-2.5">
        {/* Left: Search & Drop Pin */}
        <div className="pointer-events-auto flex items-center gap-2 flex-wrap">
          {/* Search Highway Input */}
          <div className="bg-white/95 backdrop-blur-md text-gray-900 rounded-lg shadow-md border border-slate-300 px-3 py-1.5 flex items-center gap-2 w-48 sm:w-60">
            <Search className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder={t('search_highways_placeholder')}
              className="flex-1 text-xs text-slate-800 placeholder-slate-400 bg-transparent focus:outline-none"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="p-0.5 hover:bg-slate-100 rounded-full text-slate-400 cursor-pointer">
                <X className="w-3 h-3" />
              </button>
            )}
          </div>

          {/* Dedicated "Mark Crisis Target" Button */}
          <button
            onClick={() => setIsPinModeActive(!isPinModeActive)}
            className={`px-3 py-1.5 rounded-lg shadow-md flex items-center gap-1.5 text-xs font-bold transition-all border cursor-pointer ${
              isPinModeActive
                ? 'bg-rose-600 text-white border-rose-600 animate-pulse'
                : 'bg-white/95 backdrop-blur-md text-slate-700 hover:text-rose-600 border-slate-300 hover:bg-white'
            }`}
            title="Click to activate pin-dropping mode, then tap anywhere on the map"
          >
            <Target className={`w-3.5 h-3.5 ${isPinModeActive ? 'text-white' : 'text-rose-600'}`} />
            <span className="hidden sm:inline">{isPinModeActive ? '📍 Tap Map to Drop Pin' : `🎯 ${t('mark_crisis_target')}`}</span>
            <span className="sm:hidden">{isPinModeActive ? '📍 Tap Map' : '🎯 Pin'}</span>
          </button>
        </div>

        {/* Right: Status Badges */}
        <div className="pointer-events-auto flex items-center gap-2 flex-wrap">
          {/* Realtime Supabase Connection Badge */}
          <div className="bg-slate-900/90 backdrop-blur-md text-white border border-slate-700 px-2.5 py-1.5 rounded-lg shadow-md flex items-center gap-1.5 text-xs">
            <div
              className={`w-2 h-2 rounded-full ${
                connectionStatus === 'LIVE'
                  ? 'bg-emerald-400 animate-pulse'
                  : connectionStatus === 'RECONNECTING'
                  ? 'bg-amber-400 animate-pulse'
                  : 'bg-slate-500'
              }`}
            />
            <span className="font-semibold text-slate-200 text-xs">
              {connectionStatus === 'LIVE' ? '● LIVE' : connectionStatus === 'RECONNECTING' ? '↻ RECONNECTING' : '● OFFLINE'}
            </span>
          </div>

          {/* Live Active Incident Counter Badge */}
          {activeIncidents && activeIncidents.length > 0 && (
            <div className="bg-red-950/90 backdrop-blur-md text-red-200 border border-red-700 px-2.5 py-1.5 rounded-lg shadow-md flex items-center gap-1.5 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              <span>{activeIncidents.length} Incident{activeIncidents.length > 1 ? 's' : ''}</span>
            </div>
          )}

          {/* OSRM Road Network Status Badge */}
          <div className="bg-slate-900/90 backdrop-blur-md text-white border border-slate-700 px-2.5 py-1.5 rounded-lg shadow-md flex items-center gap-2 text-xs">
            <div
              className={`w-2 h-2 rounded-full ${
                missionPathCoordinates && missionPathCoordinates.length > 20
                  ? 'bg-blue-400 animate-pulse'
                  : 'bg-slate-400'
              }`}
            />
            <span className="font-semibold text-slate-200 hidden sm:inline">
              {missionPathCoordinates && missionPathCoordinates.length > 20
                ? 'OSRM Road Network'
                : 'GIS Navigation'}
            </span>
            {missionPathCoordinates && missionPathCoordinates.length > 20 && (
              <span className="text-[10px] bg-blue-950 text-blue-300 border border-blue-700/60 px-1.5 py-0.5 rounded font-mono font-bold">
                {missionPathCoordinates.length} nodes
              </span>
            )}
          </div>
        </div>
      </div>

      {/* ── 🎬 CONVOY SIMULATION & TELEMETRY CONTROLLER BAR (BOTTOM-CENTER DOCK) ── */}
      {missionPathCoordinates && missionPathCoordinates.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-[1000] pointer-events-auto bg-white/95 backdrop-blur-md border border-slate-300 text-slate-800 px-3.5 py-2 rounded-xl shadow-xl flex items-center gap-3 max-w-lg w-[92%] sm:w-auto">
          {/* Play / Pause Toggle */}
          <button
            onClick={() => setIsPlaying(!isPlaying)}
            className="btn-irctc-primary p-2 rounded flex items-center justify-center transition-all cursor-pointer shadow-xs shrink-0"
            title={isPlaying ? 'Pause Convoy Movement' : 'Resume Convoy Movement'}
          >
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-white" />}
          </button>

          {/* Restart Button */}
          <button
            onClick={() => setSimProgress(0.0)}
            className="p-2 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors cursor-pointer border border-slate-300 shrink-0"
            title="Restart Convoy from Origin"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>

          {/* Convoy Telemetry Info & Scrub Track */}
          <div className="flex flex-col flex-1 min-w-[120px] sm:min-w-[170px] text-xs">
            <div className="flex items-center justify-between text-[11px] font-bold">
              <span className="text-[#213d77] flex items-center gap-1 truncate max-w-[120px] sm:max-w-none">
                <Truck className="w-3.5 h-3.5 text-[#fb792b] shrink-0" />
                <span className="truncate">{vehicleTelemetry?.vehicleNumber || 'NER-TRUCK-18'}</span>
              </span>
              <span className="text-emerald-700 font-mono text-[10.5px] ml-1">{completedPercentage}%</span>
            </div>

            {/* Interactive Progress Track */}
            <div
              className="w-full bg-slate-200 h-2 rounded-full overflow-hidden mt-1 cursor-pointer border border-slate-300"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect()
                const clickX = e.clientX - rect.left
                const newProgress = Math.max(0, Math.min(1, clickX / rect.width))
                setSimProgress(newProgress)
              }}
              title="Click track to scrub convoy position"
            >
              <div
                className="bg-[#213d77] h-full rounded-full transition-all duration-75"
                style={{ width: `${completedPercentage}%` }}
              />
            </div>

            <div className="flex justify-between text-[9.5px] text-slate-500 mt-0.5 font-mono">
              <span>{remainingDistanceKm} km left</span>
              <span>{currentVehicleHeading}° heading</span>
            </div>
          </div>

          {/* Speed Selector (1x, 3x, 8x) */}
          <div className="flex items-center bg-slate-100 border border-slate-300 rounded p-0.5 text-[10.5px] shrink-0">
            {[1, 3, 8].map(spd => (
              <button
                key={spd}
                onClick={() => setPlaybackSpeed(spd)}
                className={`px-2 py-0.5 rounded font-bold transition-all cursor-pointer ${
                  playbackSpeed === spd
                    ? 'bg-[#213d77] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
                title={`Playback Speed ${spd}x`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── BOTTOM-RIGHT MAP CONTROLS ── */}
      <div className="absolute bottom-4 right-4 z-[1000] flex flex-col items-end gap-2">
        {/* Fit Route Button */}
        {missionPathCoordinates && missionPathCoordinates.length > 1 && (
          <button
            onClick={() => setFitRouteTrigger(Date.now())}
            className="bg-white text-slate-800 hover:text-[#213d77] border border-slate-300 px-3 py-1.5 rounded shadow-md flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer"
            title="Fit Active Road Route to Screen"
          >
            <Navigation className="w-4 h-4 text-[#fb792b]" />
            <span>Fit Route</span>
          </button>
        )}

        {/* Layer Switcher */}
        <div className="relative">
          <button
            onClick={() => setLayerDrawerOpen(!layerDrawerOpen)}
            className="bg-white text-slate-800 hover:bg-slate-50 border border-slate-300 px-3 py-1.5 rounded shadow-md flex items-center gap-1.5 text-xs font-bold transition-all cursor-pointer"
          >
            <Layers className="w-4 h-4 text-[#213d77]" />
            <span>Map Style</span>
          </button>

          {layerDrawerOpen && (
            <div className="absolute bottom-10 right-0 bg-white text-slate-900 rounded shadow-xl border border-slate-300 p-2.5 w-64 space-y-2 text-xs">
              <div>
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-2 mb-1">Base Map Theme</p>
                <div className="space-y-0.5">
                  {(Object.keys(TILE_LAYERS) as Array<keyof typeof TILE_LAYERS>).map(key => (
                    <button
                      key={key}
                      onClick={() => {
                        setCurrentLayer(key)
                        setLayerDrawerOpen(false)
                      }}
                      className={`w-full text-left px-2.5 py-1.5 text-xs font-semibold rounded flex items-center justify-between transition-colors cursor-pointer ${
                        currentLayer === key ? 'bg-[#213d77] text-white shadow-xs' : 'hover:bg-slate-100 text-slate-700'
                      }`}
                    >
                      <span>{TILE_LAYERS[key].name}</span>
                      {currentLayer === key && <span>✓</span>}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t border-slate-200 pt-2">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider px-2 mb-1">GIS Data Layers</p>
                <div className="space-y-1.5 px-1">
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 hover:text-slate-900">
                    <input
                      type="checkbox"
                      checked={showActiveIncidents}
                      onChange={e => setShowActiveIncidents(e.target.checked)}
                      className="rounded border-slate-300 text-[#fb792b] focus:ring-[#fb792b] cursor-pointer"
                    />
                    <span>🚨 Active Incidents</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 hover:text-slate-900">
                    <input
                      type="checkbox"
                      checked={showRiskPredictions}
                      onChange={e => setShowRiskPredictions(e.target.checked)}
                      className="rounded border-slate-300 text-[#fb792b] focus:ring-[#fb792b] cursor-pointer"
                    />
                    <span>⚠️ AI Risk Predictions</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700 hover:text-slate-900">
                    <input
                      type="checkbox"
                      checked={showInfrastructure}
                      onChange={e => setShowInfrastructure(e.target.checked)}
                      className="rounded border-slate-300 text-[#fb792b] focus:ring-[#fb792b] cursor-pointer"
                    />
                    <span>🌉 Infrastructure (Bridges & Passes)</span>
                  </label>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* GPS Recenter Button */}
        <button
          onClick={() => setTargetView(STATE_HUBS.All)}
          className="bg-white text-slate-800 hover:text-[#213d77] p-2 rounded shadow-md border border-slate-300 transition-transform hover:scale-105 cursor-pointer"
          title="Recenter Map"
        >
          <Crosshair className="w-4 h-4" />
        </button>

        {/* Zoom In/Out */}
        <div className="bg-white rounded shadow-md border border-slate-300 flex flex-col overflow-hidden">
          <button
            onClick={() => {
              setZoomAction(1)
              setTimeout(() => setZoomAction(null), 100)
            }}
            className="p-2 text-slate-700 hover:bg-slate-100 border-b border-slate-200 flex items-center justify-center cursor-pointer"
            title="Zoom In"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setZoomAction(-1)
              setTimeout(() => setZoomAction(null), 100)
            }}
            className="p-2 text-slate-700 hover:bg-slate-100 flex items-center justify-center cursor-pointer"
            title="Zoom Out"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* ── LEAFLET MAP CANVAS ── */}
      <MapContainer
        center={[25.7, 92.8]}
        zoom={7}
        zoomControl={false}
        style={{ height: '100%', width: '100%', borderRadius: '0.75rem', background: '#f1f5f9' }}
      >
        <TileLayer
          attribution={TILE_LAYERS[currentLayer].attribution}
          url={TILE_LAYERS[currentLayer].url}
          maxZoom={18}
        />

        <MapControllerComponent
          targetView={targetView}
          missionPathCoordinates={missionPathCoordinates}
          targetCoords={targetCoords}
          zoomAction={zoomAction}
          fitRouteTrigger={fitRouteTrigger}
        />

        {/* ── Map Click Event: Only drops pin when isPinModeActive is TRUE ── */}
        <MapClickEventsComponent
          isPinModeActive={isPinModeActive}
          onSelectTargetCoords={onSelectTargetCoords}
          onPinPlaced={() => setIsPinModeActive(false)}
        />

        {/* ── Origin Hub Pin (Always rendered at Origin) ── */}
        {originCoords && (
          <Marker
            position={[originCoords.lat, originCoords.lng]}
            icon={createOriginHubIcon()}
          >
            <Popup>
              <div className="text-xs p-1">
                <span className="font-extrabold text-blue-600 block text-sm">🏛️ Supply Origin Hub</span>
                <p className="text-gray-900 font-bold text-xs mt-0.5">{originCoords.name}</p>
                <p className="text-gray-600 text-[11px] mt-0.5">
                  Convoys dispatched from this strategic logistics reserve.
                </p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* ── Direct Target Crisis Destination Pin (When NO last-mile gap) ── */}
        {targetCoords && (!lastMileAccessibility || lastMileAccessibility.lastMileDistanceKm === 0) && (
          <Marker
            position={[targetCoords.lat, targetCoords.lng]}
            icon={createTargetCrisisIcon()}
          >
            <Popup>
              <div className="text-xs p-1">
                <span className="font-extrabold text-red-600 block text-sm">🎯 Target Crisis Depot</span>
                <p className="text-gray-900 font-bold text-xs mt-0.5">{targetCoords.name}</p>
                <p className="text-emerald-700 font-semibold text-[10.5px] mt-0.5">
                  ✅ Direct Vehicle Access Passable
                </p>
              </div>
            </Popup>
          </Marker>
        )}

        {/* ── Phase 10: Vehicle Access Point & Last-Mile Crisis Pins (When last-mile exists) ── */}
        {lastMileAccessibility && lastMileAccessibility.lastMileDistanceKm > 0 && (
          <>
            {/* 🚛 Vehicle Access Point Pin */}
            <Marker
              position={[lastMileAccessibility.vehicleAccessPoint.lat, lastMileAccessibility.vehicleAccessPoint.lng]}
              icon={createVehicleAccessPointIcon()}
            >
              <Popup>
                <div className="text-xs p-1.5 max-w-xs space-y-1 font-sans">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                    <span className="font-extrabold text-blue-700 text-xs">🚛 Vehicle Access Point</span>
                    <span className="text-[9px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded uppercase">
                      ROAD HEAD
                    </span>
                  </div>
                  <p className="text-gray-800 font-semibold text-[11px]">
                    Vehicle road access ends at this safe coordinate.
                  </p>
                  <div className="bg-blue-50 border border-blue-200 rounded p-1.5 text-[10.5px] text-blue-900 space-y-0.5">
                    <div className="flex justify-between">
                      <span>Vehicle Accessible:</span>
                      <strong>{lastMileAccessibility.vehicleAccessibleDistanceKm} km</strong>
                    </div>
                    <div className="flex justify-between text-amber-700 font-bold">
                      <span>Remaining Last-Mile:</span>
                      <strong>{lastMileAccessibility.lastMileDistanceKm} km</strong>
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-500">
                    Suggested Mode: <strong>{lastMileAccessibility.recommendedMode}</strong> (Field verification required before dispatch).
                  </p>
                </div>
              </Popup>
            </Marker>

            {/* 🚨 Actual Crisis Location Pin */}
            <Marker
              position={[lastMileAccessibility.crisisLocation.lat, lastMileAccessibility.crisisLocation.lng]}
              icon={createLastMileCrisisIcon()}
            >
              <Popup>
                <div className="text-xs p-1.5 max-w-xs space-y-1 font-sans">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                    <span className="font-extrabold text-orange-700 text-xs">🚨 Crisis Location</span>
                    <span className="text-[9px] bg-orange-100 text-orange-800 font-bold px-1.5 py-0.2 rounded uppercase">
                      {lastMileAccessibility.crisisType}
                    </span>
                  </div>
                  <p className="text-gray-800 font-semibold text-[11px]">
                    Target Disaster Relief & Supply Destination
                  </p>
                  <div className="bg-orange-50 border border-orange-200 rounded p-1.5 text-[10.5px] text-orange-900 space-y-0.5">
                    <p><strong>Last-Mile Distance:</strong> {lastMileAccessibility.lastMileDistanceKm} km (Estimated Non-Road Distance)</p>
                    <p><strong>Suggested Transfer Mode:</strong> {lastMileAccessibility.recommendedMode}</p>
                    <p className="text-amber-800 font-bold text-[9.5px]">⚠️ FIELD VERIFICATION REQUIRED (Resource not yet assigned)</p>
                  </div>
                </div>
              </Popup>
            </Marker>

            {/* ── Dashed Last-Mile Segment Polyline ── */}
            <Polyline
              positions={lastMileAccessibility.lastMileCoordinates}
              color="#ea580c"
              weight={4}
              dashArray="6, 8"
              opacity={0.9}
            >
              <Popup>
                <div className="text-xs p-1">
                  <span className="font-bold text-orange-700">🚶 Last-Mile Non-Road Segment</span>
                  <p className="text-gray-700 text-[11px] mt-0.5">
                    Distance: <strong>{lastMileAccessibility.lastMileDistanceKm} km</strong> (Estimated Non-Road Distance)
                  </p>
                  <p className="text-gray-600 text-[10px]">
                    Mode: {lastMileAccessibility.recommendedMode} • Verification: Required
                  </p>
                </div>
              </Popup>
            </Polyline>
          </>
        )}

        {/* ── NER 8-State Geographic Operational Territory Boundary ── */}
        <Polygon
          positions={NER_ZONE_POLYGON}
          pathOptions={{
            color: '#0284c7',
            weight: 2,
            dashArray: '5, 8',
            fillColor: '#0ea5e9',
            fillOpacity: 0.03,
          }}
        />

        {/* ── Clean Base Road Network Polylines (Real OSRM Coordinates) ── */}
        {filteredRoutes.map((route) => {
          const isBlocked = route.status === 'blocked'
          const isAtRisk = route.status === 'at_risk'
          const isHighlighted = highlightedRouteName && (
            route.name.toLowerCase() === highlightedRouteName.toLowerCase() ||
            route.name.toLowerCase().includes(highlightedRouteName.toLowerCase())
          )

          const color = isBlocked
            ? '#dc2626'
            : isAtRisk
            ? '#d97706'
            : isHighlighted
            ? '#0284c7'
            : '#64748b'

          const weight = isHighlighted ? 6 : isBlocked ? 4.5 : 3.5
          const opacity = isHighlighted ? 1.0 : isBlocked ? 0.9 : 0.65

          const coords = (route.coordinates || []) as [number, number][]
          if (coords.length === 0) return null

          const midIndex = Math.floor(coords.length / 2)
          const midPoint: [number, number] = coords[midIndex] || coords[0]

          return (
            <div key={route.id}>
              <Polyline
                positions={coords}
                color={color}
                weight={weight}
                opacity={opacity}
                dashArray={isBlocked ? '8, 8' : undefined}
                eventHandlers={{
                  click: () => onSelectRoute && onSelectRoute(route.name),
                }}
              >
                <Popup>
                  <div className="text-xs p-1.5 max-w-xs space-y-1">
                    <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                      <span className="font-extrabold text-gray-900 text-xs">{route.highway_number || 'NH Corridor'}</span>
                      <span
                        className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                          isBlocked ? 'bg-red-100 text-red-800' : isAtRisk ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {route.status}
                      </span>
                    </div>
                    <p className="text-gray-800 font-bold text-xs">{route.name}</p>
                    <p className="text-gray-600 text-[10.5px]">
                      📍 {route.district || 'Regional Sector'}, {route.state || 'NER'}
                    </p>
                    <div className="pt-1 border-t border-gray-200 flex gap-1">
                      <button
                        onClick={() => onReportRouteStatus && onReportRouteStatus(route.name, 'blocked')}
                        className="flex-1 bg-red-600 text-white font-bold text-[9px] py-1 rounded cursor-pointer"
                      >
                        Block 🚫
                      </button>
                      <button
                        onClick={() => onReportRouteStatus && onReportRouteStatus(route.name, 'at_risk')}
                        className="flex-1 bg-amber-500 text-white font-bold text-[9px] py-1 rounded cursor-pointer"
                      >
                        At Risk ⚠️
                      </button>
                      <button
                        onClick={() => onReportRouteStatus && onReportRouteStatus(route.name, 'open')}
                        className="flex-1 bg-green-600 text-white font-bold text-[9px] py-1 rounded cursor-pointer"
                      >
                        Open ✅
                      </button>
                    </div>
                  </div>
                </Popup>
              </Polyline>

              {/* Highway Label Shield (Cleaned up: only on key routes) */}
              {route.highway_number && midPoint && (
                <Marker
                  position={midPoint}
                  icon={createHighwayLabelIcon(route.highway_number, route.status)}
                />
              )}

              {/* Blocked Red Hazard Marker at Obstruction Center */}
              {isBlocked && midPoint && (
                <Marker
                  position={midPoint}
                  icon={createBlockedHazardIcon()}
                >
                  <Popup>
                    <div className="text-xs p-1">
                      <span className="font-extrabold text-red-600 block text-xs">⛔ Corridor Blockage</span>
                      <p className="text-gray-900 font-bold text-xs">{route.name}</p>
                      <p className="text-gray-600 text-[10.5px] mt-0.5">
                        Carriageway blocked by structural hazard or landslide debris.
                      </p>
                    </div>
                  </Popup>
                </Marker>
              )}
            </div>
          )
        })}

        {/* ── 🏔️ Strategic Mountain Passes (Optional Layer) ── */}
        {showInfrastructure && NER_STRATEGIC_PASSES.map((pass) => (
          <Marker
            key={pass.id}
            position={[pass.coordinates[0], pass.coordinates[1]]}
            icon={createStrategicPassIcon(pass.name, pass.status, pass.elevation_ft)}
          >
            <Popup>
              <div className="text-xs p-1.5 max-w-xs space-y-1 font-sans">
                <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                  <span className="font-extrabold text-gray-900">🏔️ {pass.name}</span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                    pass.status === 'open' ? 'bg-green-100 text-green-800' :
                    pass.status === 'at_risk' ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {pass.status}
                  </span>
                </div>
                <p className="text-gray-700 text-[11px]"><strong>Elevation:</strong> {pass.elevation_ft} ft • <strong>Highway:</strong> {pass.highway}</p>
                <p className="text-gray-600 text-[11px]">{pass.snow_risk}</p>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* ── 🌉 Strategic Bridges with Weight Limits (Optional Layer) ── */}
        {showInfrastructure && NER_STRATEGIC_BRIDGES.map((br) => (
          <Marker
            key={br.id}
            position={[br.coordinates[0], br.coordinates[1]]}
            icon={createStrategicBridgeIcon(br.name, br.status, br.max_weight_tons)}
          >
            <Popup>
              <div className="text-xs p-1.5 max-w-xs space-y-1 font-sans">
                <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                  <span className="font-extrabold text-cyan-900">🌉 {br.name}</span>
                  <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded uppercase ${
                    br.status === 'open' ? 'bg-green-100 text-green-800' :
                    br.status === 'at_risk' ? 'bg-amber-100 text-amber-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {br.status}
                  </span>
                </div>
                <p className="text-gray-700 text-[11px]"><strong>River:</strong> {br.river} • <strong>Length:</strong> {br.length_meters}m</p>
                <p className="text-gray-700 text-[11px]"><strong>Max Weight Rating:</strong> {br.max_weight_tons} Tons Heavy Multi-Axle</p>
                <p className="text-cyan-700 text-[10.5px]"><strong>Health:</strong> {br.structural_health}</p>
              </div>
            </Popup>
          </Marker>
        ))}

        {/* ── 🚨 Live Supabase Realtime Incident Markers (Phase 2) ── */}
        {showActiveIncidents && (activeIncidents || []).map((incident) => {
          const isConfirmed = incident.status === 'confirmed'
          const isPredicted = incident.status === 'predicted'

          return (
            <Marker
              key={incident.id}
              position={[incident.lat, incident.lng]}
              icon={createLiveIncidentIcon(
                (incident.type || incident.incident_type || 'landslide') as string,
                (incident.severity || 'high') as string,
                incident.status || 'reported'
              )}
            >
              <Popup>
                <div className="text-xs p-1.5 max-w-xs space-y-1.5 font-sans">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                    <span className="font-extrabold text-gray-900 capitalize">
                      {incident.type === 'landslide' ? '🏔️ Landslide' :
                       incident.type === 'flood' ? '🌊 Flash Flood' :
                       incident.type === 'bridge_failure' ? '🌉 Bridge Failure' :
                       incident.type === 'road_damage' ? '🛣️ Road Damage' : '⚠️ Hazard Incident'}
                    </span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                        isConfirmed ? 'bg-red-100 text-red-800' :
                        isPredicted ? 'bg-amber-100 text-amber-900 border border-amber-300' : 'bg-orange-100 text-orange-800'
                      }`}
                    >
                      {incident.status === 'predicted' ? '🟡 AI PREDICTED RISK' : incident.status ? incident.status.toUpperCase() : 'REPORTED'}
                    </span>
                  </div>

                  {incident.route_name && (
                    <p className="text-gray-800 font-bold text-[11px]">
                      🛣️ Corridor: {incident.route_name}
                    </p>
                  )}

                  {isPredicted && (
                    <div className="bg-amber-50 border border-amber-200 rounded p-1.5 text-[10.5px] text-amber-900 space-y-0.5">
                      <p className="font-bold uppercase text-[9px] text-amber-800">⚠️ AI Risk Forecast (Early Warning)</p>
                      <p className="leading-tight">Elevated disruption probability based on meteorological & terrain indices. <strong>Road is NOT marked blocked.</strong></p>
                      <div className="pt-1 text-[9px] text-amber-700 flex justify-between border-t border-amber-200">
                        <span>Soil Moisture: DATA UNAVAILABLE</span>
                        <span>Confidence: HIGH</span>
                      </div>
                    </div>
                  )}

                  <p className="text-gray-600 text-[11px] leading-relaxed">
                    {incident.description || 'Hazard reported by field patrol observation.'}
                  </p>

                  {incident.photo_url && (
                    <div className="rounded-lg overflow-hidden border border-gray-200 mt-1 max-h-32">
                      <img
                        src={incident.photo_url}
                        alt="Incident Evidence"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  )}

                  <div className="text-[10px] text-gray-500 pt-1 border-t border-gray-100 flex items-center justify-between">
                    <span>👤 {incident.reported_by || 'Field Observer'}</span>
                    <span>📍 {incident.lat.toFixed(3)}, {incident.lng.toFixed(3)}</span>
                  </div>

                  {/* Incident Audit Timeline */}
                  <div className="bg-gray-50 rounded-lg p-1.5 border border-gray-200 text-[10px] space-y-1 text-gray-700">
                    <p className="font-bold text-gray-800 uppercase tracking-wider text-[9px]">🕒 Audit Timeline</p>
                    <div className="space-y-0.5">
                      <div className="flex items-center justify-between text-gray-600">
                        <span>• {isPredicted ? 'Forecasted:' : 'Reported:'}</span>
                        <span className="font-mono">{incident.reported_at || incident.created_at ? new Date(incident.reported_at || incident.created_at!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recent'}</span>
                      </div>
                      {incident.confirmed_at && (
                        <div className="flex items-center justify-between text-red-700 font-semibold">
                          <span>• Confirmed:</span>
                          <span className="font-mono">{new Date(incident.confirmed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({incident.confirmed_by || 'Officer'})</span>
                        </div>
                      )}
                      {incident.resolved_at && (
                        <div className="flex items-center justify-between text-green-700 font-semibold">
                          <span>• Resolved:</span>
                          <span className="font-mono">{new Date(incident.resolved_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} ({incident.resolved_by || 'Authority'})</span>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-1 border-t border-gray-200 flex gap-1">
                    {incident.status === 'reported' && (
                      <button
                        onClick={() => onConfirmIncident && onConfirmIncident(incident.id)}
                        className="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold text-[9px] py-1 px-1.5 rounded transition-colors cursor-pointer"
                        title="Authorize and confirm ground blockage"
                      >
                        Confirm 🛑
                      </button>
                    )}
                    {incident.status === 'confirmed' && (
                      <button
                        onClick={() => onResolveIncident && onResolveIncident(incident.id)}
                        className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold text-[9px] py-1 px-1.5 rounded transition-colors cursor-pointer"
                        title="Mark hazard cleared and re-open corridor"
                      >
                        Resolve ✅
                      </button>
                    )}
                  </div>
                </div>
              </Popup>
            </Marker>
          )
        })}

        {/* ── Active Calculated Emergency Supply Mission Polyline (OSRM Precision Road Ribbon) ── */}
        {missionPathCoordinates && missionPathCoordinates.length > 1 && (
          <div>
            {/* Outer Glow Ribbon */}
            <Polyline
              positions={missionPathCoordinates}
              color="#0284c7"
              weight={14}
              opacity={0.35}
              lineCap="round"
              lineJoin="round"
            />
            {/* High-Contrast Casing Outline */}
            <Polyline
              positions={missionPathCoordinates}
              color="#0f172a"
              weight={7}
              opacity={0.85}
              lineCap="round"
              lineJoin="round"
            />
            {/* Core Precision Navigation Line */}
            <Polyline
              positions={missionPathCoordinates}
              color="#38bdf8"
              weight={4.5}
              opacity={1.0}
              lineCap="round"
              lineJoin="round"
            >
              <Popup>
                <div className="text-xs p-1.5 max-w-xs space-y-1">
                  <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                    <span className="font-extrabold text-blue-600 text-xs">⚡ Active Road Mission</span>
                    <span className="text-[9px] bg-blue-100 text-blue-800 font-bold px-1.5 py-0.2 rounded uppercase">
                      {vehicleTelemetry?.modeBadge || 'ACTIVE'}
                    </span>
                  </div>
                  <p className="text-gray-800 font-bold text-xs">{highlightedRouteName || 'Direct Mission Corridor'}</p>
                  <p className="text-gray-600 text-[10.5px]">
                    🛣️ Total Distance: <strong>{totalMissionDistance} km</strong> • {missionPathCoordinates.length} road curve nodes
                  </p>
                  <div className="pt-1 border-t border-gray-200 flex gap-1">
                    <button
                      onClick={() => onReportRouteStatus && onReportRouteStatus(highlightedRouteName || 'Active Mission Route', 'blocked')}
                      className="flex-1 bg-red-600 text-white font-bold text-[9px] py-1 rounded cursor-pointer"
                    >
                      Report Block 🚫
                    </button>
                    <button
                      onClick={() => onReportRouteStatus && onReportRouteStatus(highlightedRouteName || 'Active Mission Route', 'at_risk')}
                      className="flex-1 bg-amber-500 text-white font-bold text-[9px] py-1 rounded cursor-pointer"
                    >
                      Report Risk ⚠️
                    </button>
                  </div>
                </div>
              </Popup>
            </Polyline>

            {/* ── 🚁 / 🚛 ANIMATED TRAVELING VEHICLE MARKER ── */}
            {currentVehiclePos && (
              <Marker
                position={currentVehiclePos}
                icon={createMovingVehicleIcon(
                  vehicleTelemetry?.transportMode || 'heavy_road_convoy',
                  vehicleTelemetry?.vehicleNumber || 'NER-TRUCK-18',
                  vehicleTelemetry?.etaHoursFormatted || '~4.5h',
                  currentVehicleHeading,
                  Boolean(blockedRouteName)
                )}
              >
                <Popup>
                  <div className="text-xs p-1.5 max-w-xs space-y-1.5 font-sans">
                    <div className="flex items-center justify-between border-b border-gray-200 pb-1">
                      <span className="font-extrabold text-blue-600 text-[11px] flex items-center gap-1">
                        <Navigation className="w-3.5 h-3.5 text-blue-500" />
                        {vehicleTelemetry?.vehicleNumber || 'NER-TRUCK-18'}
                      </span>
                      <span className="text-[8.5px] bg-amber-100 text-amber-900 border border-amber-300 font-bold px-1.5 py-0.5 rounded uppercase tracking-wider font-mono">
                        SIMULATED TELEMETRY
                      </span>
                    </div>

                    {/* Phase 11: Vehicle Readiness Safety Gate */}
                    {(() => {
                      const vReadiness = evaluateVehicleReadiness({
                        vehicleId: vehicleTelemetry?.vehicleNumber || 'NER-TRUCK-18',
                      })
                      return (
                        <div className="flex items-center justify-between bg-slate-900 text-white px-2 py-1 rounded text-[10px] font-mono border border-slate-700">
                          <span className="text-gray-400 font-bold">SAFETY GATE:</span>
                          <span className="font-extrabold flex items-center gap-1">
                            <span>{vReadiness.statusBadge.icon}</span>
                            <span>{vReadiness.status.replace(/_/g, ' ')}</span>
                          </span>
                        </div>
                      )
                    })()}

                    <div>
                      <p className="font-extrabold text-gray-900 text-xs">{vehicleTelemetry?.vehicleModel || 'Heavy Multi-Axle Convoy'}</p>
                      <p className="text-gray-600 text-[11px]">{vehicleTelemetry?.driverName || 'Commander R. Sharma'} ({vehicleTelemetry?.operatorRole || 'Fleet Master'})</p>
                    </div>

                    <div className="bg-gray-50 p-1.5 rounded-lg border border-gray-200 text-[10.5px] space-y-0.5">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Operational Status:</span>
                        <span className={`font-bold uppercase ${blockedRouteName ? 'text-red-600' : 'text-emerald-700'}`}>
                          {blockedRouteName ? 'REROUTING' : 'IN TRANSIT'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Speed / Heading:</span>
                        <span className="font-bold text-gray-800">{vehicleTelemetry?.averageSpeedKmh || 45} km/h • {currentVehicleHeading}°</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Remaining Dist:</span>
                        <span className="font-bold text-blue-600">{remainingDistanceKm} km ({completedPercentage}% done)</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Predicted Arrival:</span>
                        <span className="font-extrabold text-emerald-600">~{vehicleTelemetry?.arrivalClockTime || '07:02 am'} IST</span>
                      </div>
                    </div>

                    {/* Cargo Payload Manifest & Priority */}
                    {vehicleTelemetry?.cargoPayload && (
                      <div className="bg-blue-50 p-1.5 rounded-lg border border-blue-200 text-[10.5px] space-y-0.5">
                        <div className="flex justify-between font-bold text-blue-900">
                          <span>📦 Cargo: {vehicleTelemetry.cargoPayload.cargoCategory.toUpperCase()}</span>
                          <span className="text-[9px] bg-red-100 text-red-700 border border-red-300 px-1 rounded uppercase font-extrabold">
                            CRITICAL PRIORITY
                          </span>
                        </div>
                        <p className="text-[10px] text-blue-800 leading-tight">
                          {vehicleTelemetry.cargoPayload.primaryQuantity}
                        </p>
                      </div>
                    )}
                  </div>
                </Popup>
              </Marker>
            )}
          </div>
        )}
      </MapContainer>
    </div>
  )
}
