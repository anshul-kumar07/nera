'use client'

import { useState, useMemo } from 'react'
import Link from 'next/link'
import dynamic from 'next/dynamic'
import {
  Truck,
  AlertTriangle,
  CheckCircle,
  Clock,
  Shield,
  Radio,
  Wifi,
  WifiOff,
  RefreshCw,
  ArrowRight,
  Sparkles,
  MapPin,
  Flame,
  Activity,
  FileText,
  RotateCcw,
  Languages,
  AlertOctagon,
  ChevronRight,
  Anchor,
  Wrench,
  ShieldCheck,
  Check,
  Compass,
} from 'lucide-react'
import { JudgeExplanationCard } from '@/components/UIPrimitives'
import {
  generateLogisticsPlan,
  approveAndConvertLogisticsPlanToMission,
  LogisticsPlan,
} from '@/lib/logistics-planning'
import {
  ResourceConflict,
} from '@/lib/resource-coordination'
import {
  OperationalSimulationState,
  createInitialSimulationState,
  triggerAIWarning,
  submitFieldReport,
  confirmDisruption,
  calculateDynamicCrisisRoute,
  createCrisisMission,
  approveCrisisMission,
  dispatchCrisisMission,
  triggerEnRouteRoadBlockage,
  executeDynamicRerouteFromCurrentPosition,
  triggerEnRouteVehicleFailure,
  findAndAssignSafeReplacement,
  confirmOnSiteHandover,
  reachVehicleAccessPoint,
  completeLastMileFieldResponse,
  officiallyCompleteMission,
  resetSimulation,
} from '@/lib/operational-simulation'
import {
  INITIAL_NER_ROUTES,
  NER_DISTRICT_STOCK_RESERVES,
} from '@/lib/data'
import { ActiveRoute } from '@/lib/routing-algorithm'
import { useRealtimeIncidents } from '@/hooks/useRealtimeIncidents'
import { deriveOperationalRoutes } from '@/lib/incident-route-impact'
import { evaluateCorridorDisruptionRisk, CorridorRiskPrediction } from '@/lib/disruption-prediction'
import { INITIAL_FLEET, VehicleTelemetryData, transitionVehicleToNewRoute } from '@/lib/vehicle-intelligence'
import { evaluateVehicleReadiness } from '@/lib/vehicle-readiness'
import { useOfflineSync } from '@/hooks/useOfflineSync'
import { useLanguage } from '@/lib/LanguageContext'
import { LanguageCode } from '@/lib/i18n'

// Dynamically import the PredictiveDisruptionsPanel to prevent SSR hydration divergence
const PredictiveDisruptionsPanel = dynamic(
  () => import('@/components/PredictiveDisruptionsPanel'),
  {
    ssr: false,
    loading: () => (
      <div className="gov-card p-5 h-64 flex items-center justify-center">
        <div className="flex items-center gap-3 text-slate-500 text-xs">
          <div className="w-5 h-5 border-2 border-[#213d77] border-t-transparent rounded-full animate-spin" />
          <span>INITIALIZING AI DISRUPTION PREDICTOR...</span>
        </div>
      </div>
    ),
  }
)

export default function DashboardPage() {
  const { language, setLanguage, t } = useLanguage()
  const { isOnline, isSyncing, pendingCount, triggerSync } = useOfflineSync()
  const { activeIncidents, lastSync } = useRealtimeIncidents()

  // Base state
  const [baseRoutes] = useState<ActiveRoute[]>(INITIAL_NER_ROUTES)
  const [fleet, setFleet] = useState<VehicleTelemetryData[]>(INITIAL_FLEET)
  const [emergencyMode, setEmergencyMode] = useState(false)
  const [simState, setSimState] = useState<OperationalSimulationState>(createInitialSimulationState)
  const [operationalTimeline, setOperationalTimeline] = useState<Array<{
    time: string
    event: string
    category: 'predict' | 'report' | 'confirm' | 'reroute' | 'resolve'
    detail: string
  }>>([])
  const [recentRouteChanges, setRecentRouteChanges] = useState<Array<{
    timestamp: string
    vehicleId: string
    reason: string
    oldRoute: string
    newRoute: string
    delayMinutes: number
  }>>([])

  const [logisticsPlans, setLogisticsPlans] = useState<LogisticsPlan[]>(() => {
    const plan1 = generateLogisticsPlan({
      crisisId: 'CRISIS-HAFLONG-01',
      destinationName: 'Haflong Outpost Settlement',
      destinationCoordinates: [25.1843, 93.0182],
      commodity: 'MEDICINES',
      quantity: 350,
      unit: 'kits',
    })
    const plan2 = generateLogisticsPlan({
      crisisId: 'CRISIS-SHILLONG-02',
      destinationName: 'Shillong Medical Complex',
      destinationCoordinates: [25.5788, 91.8933],
      commodity: 'DRINKING_WATER',
      quantity: 5000,
      unit: 'litres',
    })
    return [plan1.plan, plan2.plan].filter(Boolean) as LogisticsPlan[]
  })
  const [selectedPlanForReview, setSelectedPlanForReview] = useState<LogisticsPlan | null>(null)

  const [resourceConflicts, setResourceConflicts] = useState<ResourceConflict[]>([
    {
      conflictId: 'CONF-DBL-NER-TRUCK-18',
      type: 'VEHICLE_DOUBLE_ASSIGNMENT',
      resourceId: 'NER-TRUCK-18',
      resourceName: 'Tata Signa Heavy (NER-TRUCK-18)',
      severity: 'HIGH',
      competingMissions: ['NERA-MSN-01 (Haflong Medical)', 'NERA-MSN-04 (Silchar Food)'],
      competingCrises: ['Haflong Crisis', 'Silchar Crisis'],
      description: 'Carrier NER-TRUCK-18 is simultaneously requested for 2 critical emergency missions.',
      recommendedResolution: 'Keep NER-TRUCK-18 assigned to P1 Medical Mission and assign NER-TRUCK-07 (12T, READY) to Silchar.',
      requiresHumanReview: true,
      status: 'OPEN',
      isSimulated: true,
    },
  ])

  // 1. Operational Routes Derived from Active Confirmed Incidents (Phase 4)
  const { operationalRoutes } = useMemo(() => {
    return deriveOperationalRoutes(baseRoutes, activeIncidents)
  }, [baseRoutes, activeIncidents])

  // 2. Multi-corridor AI Disruption Risk Predictions (Phase 6)
  const corridorPredictions = useMemo<CorridorRiskPrediction[]>(() => {
    return baseRoutes.map(route => {
      return evaluateCorridorDisruptionRisk(route, null, activeIncidents, fleet)
    })
  }, [baseRoutes, activeIncidents, fleet])

  const highRiskCorridors = useMemo(() => {
    return corridorPredictions.filter(p => p.riskLevel === 'HIGH' || p.riskLevel === 'CRITICAL')
  }, [corridorPredictions])

  // 3. Operational Counters (strictly from real application state)
  const activeIncidentsCount = activeIncidents.length
  const confirmedDisruptionsCount = activeIncidents.filter(i => i.status === 'confirmed').length
  const reportedPendingCount = activeIncidents.filter(i => i.status === 'reported').length
  const highRiskCorridorsCount = highRiskCorridors.length
  const vehiclesInTransitCount = fleet.filter(v => v.status === 'IN_TRANSIT' || v.status === 'REROUTING').length
  const criticalShipmentsCount = fleet.filter(v => v.priority === 'CRITICAL').length
  const delayedShipmentsCount = fleet.filter(v => v.delayMinutes > 0).length
  const blockedCorridorsCount = operationalRoutes.filter(r => r.status === 'blocked').length

  // 4. Critical Alerts Prioritization (Section 5 & 6)
  const criticalAlerts = useMemo(() => {
    const alerts: Array<{
      id: string
      type: 'confirmed_incident' | 'critical_shipment' | 'high_risk' | 'field_report'
      badgeColor: string
      badgeText: string
      title: string
      corridor: string
      detail: string
      timestamp: string
    }> = []

    // Priority 1: Confirmed Road Disruptions / Blockages
    activeIncidents
      .filter(i => i.status === 'confirmed')
      .forEach(i => {
        alerts.push({
          id: `alert-conf-${i.id}`,
          type: 'confirmed_incident',
          badgeColor: 'bg-red-950 border-red-700 text-red-300',
          badgeText: '🔴 CONFIRMED DISRUPTION',
          title: `${(i.type || 'Hazard').toUpperCase()} BLOCKAGE`,
          corridor: i.route_name || 'Strategic NER Highway Corridor',
          detail: i.description || 'Highway carriageway confirmed blocked. Alternate corridor active.',
          timestamp: i.confirmed_at ? new Date(i.confirmed_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Live',
        })
      })

    // Priority 2: Critical Shipments At Risk / Rerouting
    fleet
      .filter(v => v.priority === 'CRITICAL' && (v.isRerouted || v.status === 'REROUTING' || v.delayMinutes > 0))
      .forEach(v => {
        alerts.push({
          id: `alert-fleet-${v.vehicleId}`,
          type: 'critical_shipment',
          badgeColor: 'bg-amber-950 border-amber-700 text-amber-300',
          badgeText: '🚛 CRITICAL SHIPMENT AT RISK',
          title: `${v.cargoType} CONVOY (${v.vehicleId})`,
          corridor: v.currentRouteName,
          detail: v.isRerouted 
            ? `Bypassing blocked sector. New ETA: ${v.etaClockTime} (+${v.delayMinutes} min delay).`
            : `Encountering corridor slowdown. Current ETA: ${v.etaClockTime}.`,
          timestamp: 'Active Telemetry',
        })
      })

    // Priority 3: High AI Predicted Risks
    highRiskCorridors.forEach(p => {
      alerts.push({
        id: `alert-risk-${p.corridorId}`,
        type: 'high_risk',
        badgeColor: 'bg-yellow-950 border-yellow-700 text-yellow-300',
        badgeText: '🟡 AI PREDICTED EARLY WARNING',
        title: `${p.hazardCategory.replace(/_/g, ' ')} (Score: ${p.riskScore}/100)`,
        corridor: p.corridorName,
        detail: p.explanations[0] || p.recommendedAction,
        timestamp: p.evaluatedAt,
      })
    })

    // Priority 4: Pending Ground Reports Awaiting Verification
    activeIncidents
      .filter(i => i.status === 'reported')
      .forEach(i => {
        alerts.push({
          id: `alert-rep-${i.id}`,
          type: 'field_report',
          badgeColor: 'bg-orange-950 border-orange-700 text-orange-300',
          badgeText: '🟠 REPORTED HAZARD (Awaiting Verification)',
          title: `${(i.type || 'Hazard').toUpperCase()} REPORTED`,
          corridor: i.route_name || 'Regional Corridor',
          detail: i.description || 'Ground patrol log. Awaiting authority confirmation.',
          timestamp: i.reported_at ? new Date(i.reported_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Recent',
        })
      })

    return alerts
  }, [activeIncidents, fleet, highRiskCorridors])

  // Format last sync time cleanly
  const syncTimeStr = lastSync ? lastSync.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Live (Connecting)'

  return (
    <div className={`space-y-6 sm:space-y-8 text-slate-800 transition-colors duration-300 ${
      emergencyMode ? 'bg-red-50/50 p-4 sm:p-5 rounded-lg border-2 border-red-500' : ''
    }`}>
      {/* ── 1. TOP COMMAND CENTER HEADER BAR ── */}
      <div className="gov-card p-5 sm:p-6 flex flex-col xl:flex-row xl:items-center xl:justify-between gap-5">
        <div>
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 bg-[#213d77] rounded flex items-center justify-center text-white shrink-0 shadow-xs border border-[#1b3162]">
              <Shield className="w-6 h-6 text-[#fb792b]" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-[#213d77]">
                  {language === 'hi' ? 'एनईआर लॉजिस्टिक्स कमांड सेंटर' :
                   language === 'as' ? 'উত্তৰ-পূব লজিষ্টিক কমাণ্ড চেণ্টাৰ' :
                   language === 'bn' ? 'উত্তর-পূর্ব লজিস্টিকস কমান্ড সেন্টার' :
                   language === 'mn' ? 'NER ꯂꯣꯖꯤꯁ꯭ꯇꯤꯛꯁ ꯀꯃꯥꯟꯗ ꯁꯦꯟꯇꯔ' :
                   'NER LOGISTICS COMMAND CENTER'}
                </h1>
                <div className="flex items-center gap-1.5 bg-emerald-100 border border-emerald-300 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded font-mono">
                  <span className="w-2 h-2 rounded-full bg-emerald-600 animate-ping" />
                  <span>{t('system_online')}</span>
                </div>
                <span className="text-xs bg-blue-100 border border-blue-300 text-[#213d77] font-bold px-2.5 py-1 rounded font-mono">
                  NDMA / NEC DISASTER COMMAND
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-600 mt-1">
                {language === 'hi' ? 'पूर्वोत्तर क्षेत्र के लिए एआई-आधारित स्मार्ट लॉजिस्टिक्स और पहुंच खुफिया मंच' :
                 language === 'as' ? 'উত্তৰ-পূব অঞ্চলৰ বাবে AI-আধাৰিত স্মাৰ্ট লজিষ্টিক আৰু প্ৰৱেশাধিকাৰ চোৰাংচোৱা মঞ্চ' :
                 language === 'bn' ? 'উত্তর-পূর্ব অঞ্চলের জন্য AI-ভিত্তিক স্মার্ট লজিস্টিক ও অ্যাক্সেস ইন্টেলিজেন্স প্ল্যাটফর্ম' :
                 language === 'mn' ? 'NER ꯒꯤꯗꯃꯛ AI-ꯗꯥ ꯌꯨꯝꯐꯝ ꯑꯣꯏꯕꯥ ꯂꯣꯖꯤꯁ꯭ꯇꯤꯛꯁ ꯄ꯭ꯂꯦꯠꯐꯣꯔꯝ' :
                 'AI-Based Smart Logistics & Accessibility Intelligence Platform for North Eastern Region'}
              </p>
            </div>
          </div>
        </div>

        {/* Live Connectivity, Emergency Toggle & Multilingual Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Language Selector */}
          <div className="flex items-center bg-slate-100 border border-slate-300 rounded p-1 text-xs">
            <Languages className="w-4 h-4 text-slate-600 ml-1 mr-1.5" />
            {[
              { code: 'en' as LanguageCode, label: 'EN' },
              { code: 'hi' as LanguageCode, label: 'हिन्दी' },
              { code: 'as' as LanguageCode, label: 'অসমীয়া' },
              { code: 'bn' as LanguageCode, label: 'বাংলা' },
              { code: 'mn' as LanguageCode, label: 'ꯃꯤꯇꯩ' },
            ].map(lang => (
              <button
                key={lang.code}
                onClick={() => setLanguage(lang.code)}
                className={`px-2.5 py-1 rounded font-bold text-xs transition-all cursor-pointer ${
                  language === lang.code
                    ? 'bg-[#213d77] text-white shadow-xs'
                    : 'text-slate-700 hover:text-slate-950'
                }`}
              >
                {lang.label}
              </button>
            ))}
          </div>

          {/* Emergency Mode Toggle */}
          <button
            onClick={() => setEmergencyMode(!emergencyMode)}
            className={`flex items-center gap-2 px-3.5 py-2 rounded border text-xs sm:text-sm font-bold min-h-[38px] transition-all cursor-pointer ${
              emergencyMode
                ? 'bg-red-600 text-white border-red-600 shadow-xs'
                : 'bg-slate-100 hover:bg-slate-200 border-slate-300 text-slate-700'
            }`}
          >
            <Flame className={`w-4 h-4 ${emergencyMode ? 'text-white' : 'text-red-600'}`} />
            <span>{emergencyMode ? 'EMERGENCY ACTIVE' : 'EMERGENCY MODE'}</span>
          </button>

          {/* Network State Badge */}
          <div className={`flex items-center gap-2 px-3 py-2 rounded border text-xs sm:text-sm font-bold min-h-[38px] ${
            isOnline ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : 'bg-amber-50 border-amber-300 text-amber-900'
          }`}>
            {isOnline ? <Wifi className="w-4 h-4 text-emerald-600" /> : <WifiOff className="w-4 h-4 text-amber-600 animate-pulse" />}
            <span>{isOnline ? 'ONLINE' : 'OFFLINE'}</span>
          </div>

          {/* Supabase Realtime State */}
          <div className="flex items-center gap-2 bg-slate-100 border border-slate-300 px-3 py-2 rounded text-xs text-slate-700 font-bold min-h-[38px]">
            <Radio className="w-4 h-4 text-[#fb792b] animate-pulse" />
            <span className="font-mono text-xs">SYNC: {syncTimeStr}</span>
          </div>

          {/* Pending Field Reports Sync Badge */}
          {pendingCount > 0 && (
            <button
              onClick={triggerSync}
              disabled={isSyncing || !isOnline}
              className="flex items-center gap-2 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 px-3 py-2 rounded text-xs font-bold cursor-pointer min-h-[38px]"
            >
              <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>PENDING: {pendingCount}</span>
            </button>
          )}
        </div>
      </div>

      {/* ── 2. EMERGENCY OPERATIONS SUMMARY BOX (Active in Emergency Mode) ── */}
      {emergencyMode && (
        <div className="bg-red-50 border-2 border-red-400 rounded-lg p-5 sm:p-6 shadow-xs space-y-4 text-red-950 animate-in fade-in duration-300">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-red-200 pb-3.5">
            <div className="flex items-center gap-3">
              <AlertOctagon className="w-6 h-6 text-red-600" />
              <div>
                <h2 className="text-sm sm:text-base font-black tracking-wide text-red-900 uppercase">
                  EMERGENCY OPERATIONS CENTER — CRISIS PROTOCOL ACTIVATED
                </h2>
                <p className="text-xs sm:text-sm text-red-700 mt-0.5">
                  Prioritizing blocked corridors, critical medicine deliveries, and high-risk mountain sectors
                </p>
              </div>
            </div>
            <div className="text-xs font-mono text-red-800 bg-red-100 border border-red-300 px-3 py-1.5 rounded font-bold">
              LAST UPDATE: {new Date().toLocaleTimeString()}
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3.5">
            <div className="bg-white border border-red-200 rounded p-3.5 text-center">
              <span className="text-xs font-bold uppercase text-red-700 tracking-wider">CRITICAL INCIDENTS</span>
              <p className="text-2xl sm:text-3xl font-black text-red-900 mt-1">{confirmedDisruptionsCount}</p>
            </div>
            <div className="bg-white border border-red-200 rounded p-3.5 text-center">
              <span className="text-xs font-bold uppercase text-red-700 tracking-wider">BLOCKED CORRIDORS</span>
              <p className="text-2xl sm:text-3xl font-black text-red-900 mt-1">{blockedCorridorsCount}</p>
            </div>
            <div className="bg-white border border-red-200 rounded p-3.5 text-center">
              <span className="text-xs font-bold uppercase text-red-700 tracking-wider">CRITICAL SHIPMENTS</span>
              <p className="text-2xl sm:text-3xl font-black text-red-900 mt-1">{criticalShipmentsCount}</p>
            </div>
            <div className="bg-white border border-red-200 rounded p-3.5 text-center">
              <span className="text-xs font-bold uppercase text-red-700 tracking-wider">DELAYED DELIVERIES</span>
              <p className="text-2xl sm:text-3xl font-black text-red-900 mt-1">{delayedShipmentsCount}</p>
            </div>
            <div className="bg-white border border-red-200 rounded p-3.5 text-center col-span-2 sm:col-span-1">
              <span className="text-xs font-bold uppercase text-red-700 tracking-wider">HIGH-RISK CORRIDORS</span>
              <p className="text-2xl sm:text-3xl font-black text-red-900 mt-1">{highRiskCorridorsCount}</p>
            </div>
          </div>

          {/* Emergency Route Callout if Critical Shipment affected */}
          {fleet.some(v => v.priority === 'CRITICAL' && v.isRerouted) && (
            <div className="bg-white border border-red-300 rounded p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3.5">
              <div className="space-y-1">
                <div className="flex items-center gap-2.5">
                  <span className="text-xs font-bold bg-red-600 text-white px-2.5 py-1 rounded font-mono">
                    EMERGENCY ROUTE ACTIVE
                  </span>
                  <span className="text-sm font-bold text-red-900">
                    NER-TRUCK-18 (MEDICINES CONVOY)
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-red-700">
                  Guwahati → Shillong • REROUTING via NH-106 High Plateau Bypass • ETA: 07:02 am (+45 min delay)
                </p>
              </div>
              <Link
                href="/map"
                className="btn-irctc-primary text-xs sm:text-sm flex items-center justify-center gap-1.5 shrink-0 font-bold px-4 py-2.5 min-h-[40px] rounded"
              >
                Track on GIS Map <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          )}
        </div>
      )}

      {/* ── 3. PHASE 16: END-TO-END OPERATIONAL CRISIS SIMULATION & COMMAND CENTER ── */}
      <div className="gov-card p-5 sm:p-6 space-y-5">
        {/* Panel Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 border-b border-slate-200 pb-3.5">
          <div className="space-y-1">
            <div className="flex items-center gap-2.5 flex-wrap">
              <Sparkles className="w-5 h-5 text-[#fb792b] shrink-0" />
              <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                OPERATIONAL CRISIS SIMULATION & COMMAND WORKFLOW
              </h2>
              <span className="text-xs font-mono bg-blue-50 border border-blue-200 text-[#213d77] px-2.5 py-0.5 rounded font-bold">
                INTEGRATED DRILL WORKFLOW
              </span>
              <span className="text-xs font-mono bg-amber-50 border border-amber-300 text-amber-900 px-2.5 py-0.5 rounded font-bold">
                SIMULATED DATA
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-600">
              Scenario: <strong className="text-slate-900">{simState.scenarioName}</strong> • Target: <strong className="text-[#213d77]">{simState.crisisLocation.name}</strong> [{simState.crisisLocation.coordinates.join(', ')}]
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Simulation Clock */}
            <div className="bg-slate-50 border border-slate-300 px-3.5 py-2 rounded flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-[#fb792b]" />
              <div className="text-left">
                <span className="text-[10px] text-slate-500 block uppercase font-bold">SIMULATION CLOCK</span>
                <strong className="text-sm font-mono text-[#213d77] font-black">{simState.simulationClock.simulatedTime} IST</strong>
              </div>
            </div>

            {/* Current Step Badge */}
            <span className={`px-3.5 py-2 rounded text-xs sm:text-sm font-mono font-bold uppercase border ${
              simState.currentStep === 'COMPLETED'
                ? 'bg-emerald-100 border-emerald-300 text-emerald-800'
                : simState.currentStep === 'VEHICLE_FAILURE' || simState.currentStep === 'ROAD_BLOCKED'
                ? 'bg-red-100 border-red-300 text-red-800'
                : simState.currentStep === 'LAST_MILE_REQUIRED' || simState.currentStep === 'HANDOVER_PENDING'
                ? 'bg-amber-100 border-amber-300 text-amber-900'
                : 'bg-blue-50 border-blue-200 text-[#213d77]'
            }`}>
              STEP: {simState.currentStep.replace(/_/g, ' ')}
            </span>
          </div>
        </div>

        {/* Dynamic Story Highlights */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Box 1: Active Incident / Blockage */}
          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-1.5">
            <span className="text-xs uppercase font-bold text-slate-500 block">Active Corridor Event</span>
            {simState.activeIncident ? (
              <div className="space-y-1">
                <strong className="text-xs sm:text-sm text-slate-900 block truncate">{simState.activeIncident.title}</strong>
                <span className={`text-xs font-mono uppercase font-bold px-2 py-0.5 rounded border inline-block ${
                  simState.activeIncident.status === 'confirmed' ? 'bg-red-100 border-red-300 text-red-800' :
                  simState.activeIncident.status === 'reported' ? 'bg-orange-100 border-orange-300 text-orange-800' :
                  'bg-yellow-100 border-yellow-300 text-yellow-800'
                }`}>
                  {simState.activeIncident.status}
                </span>
                <p className="text-xs text-slate-600 mt-1 line-clamp-2">{simState.activeIncident.impactSummary}</p>
              </div>
            ) : (
              <p className="text-xs text-slate-500">No active disruption event</p>
            )}
          </div>

          {/* Box 2: Route & Last-Mile Reachability */}
          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-1.5">
            <span className="text-xs uppercase font-bold text-slate-500 block">Dynamic Route & VAP</span>
            {simState.currentRoutePlan ? (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs sm:text-sm font-mono">
                  <span className="text-[#213d77] font-bold">{simState.currentRoutePlan.totalDistanceKm} km</span>
                  <span className={simState.currentRoutePlan.lastMileKm > 0 ? 'text-[#fb792b] font-bold' : 'text-emerald-700'}>
                    Gap: {simState.currentRoutePlan.lastMileKm} km
                  </span>
                </div>
                <p className="text-xs text-slate-600 truncate">
                  VAP: [{simState.currentRoutePlan.vapCoordinates.join(', ')}]
                </p>
                <span className="text-xs text-[#213d77] font-mono font-bold block">
                  Transfer: {simState.currentRoutePlan.recommendedLastMileMode}
                </span>
              </div>
            ) : (
              <p className="text-xs text-slate-500">Route not yet calculated</p>
            )}
          </div>

          {/* Box 3: Carrier & Safety Gate */}
          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-1.5">
            <span className="text-xs uppercase font-bold text-slate-500 block">Assigned Carrier & Safety</span>
            {simState.assignedVehicle ? (
              <div className="space-y-1">
                <div className="flex items-center justify-between">
                  <strong className="text-xs sm:text-sm text-slate-900">{simState.assignedVehicle.vehicleId}</strong>
                  <span className="text-xs font-mono text-[#213d77] font-bold">{simState.assignedVehicle.speedKmh} km/h</span>
                </div>
                <div className="flex items-center gap-1.5 mt-1 text-xs">
                  <span className="text-emerald-800 font-mono font-bold bg-emerald-100 px-1.5 py-0.5 rounded border border-emerald-300">
                    GATE: {simState.assignedVehicle.readinessStatus}
                  </span>
                  <span className="text-blue-900 font-mono font-bold bg-blue-100 px-1.5 py-0.5 rounded border border-blue-300">
                    AI: {simState.assignedVehicle.aiRiskLevel}
                  </span>
                </div>
                {simState.vehicleFailure && (
                  <p className="text-xs text-red-700 font-bold mt-1">🚨 {simState.vehicleFailure.failureType}</p>
                )}
              </div>
            ) : (
              <p className="text-xs text-slate-500">No vehicle assigned</p>
            )}
          </div>

          {/* Box 4: Mission Lifecycle Status */}
          <div className="bg-slate-50 p-4 rounded border border-slate-200 space-y-1.5">
            <span className="text-xs uppercase font-bold text-slate-500 block">Mission Lifecycle</span>
            {simState.activeMission ? (
              <div className="space-y-1">
                <strong className="text-xs sm:text-sm text-[#213d77] block font-mono truncate">{simState.activeMission.id}</strong>
                <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded border inline-block ${
                  simState.activeMission.status === 'COMPLETED' ? 'bg-emerald-100 border-emerald-300 text-emerald-800' :
                  simState.activeMission.status === 'INTERRUPTED' ? 'bg-red-100 border-red-300 text-red-800' :
                  simState.activeMission.status === 'IN_TRANSIT' ? 'bg-blue-100 border-blue-300 text-blue-800' :
                  'bg-slate-200 text-slate-800'
                }`}>
                  {simState.activeMission.status}
                </span>
                <p className="text-xs text-slate-600 truncate">{simState.activeMission.title}</p>
              </div>
            ) : (
              <p className="text-xs text-slate-500">Mission not yet created</p>
            )}
          </div>
        </div>

        {/* Primary Interactive Stepper Button */}
        <div className="bg-slate-50 border border-slate-300 rounded p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-xs sm:text-sm text-slate-700 font-medium leading-relaxed">
            {simState.currentStep === 'IDLE' && '👉 Click below to trigger AI disruption prediction advisory.'}
            {simState.currentStep === 'AI_WARNING' && '👉 AI warning issued. Click below to simulate ground officer field report.'}
            {simState.currentStep === 'FIELD_REPORTED' && '👉 Field patrol confirmed rockfall. Click below for official DDMA verification.'}
            {simState.currentStep === 'OFFICIAL_CONFIRMED' && '👉 Corridor blocked. Click below to calculate arbitrary bypass route & VAP.'}
            {simState.currentStep === 'ROUTE_CALCULATED' && '👉 Bypass identified. Click below to create emergency medical mission.'}
            {simState.currentStep === 'MISSION_CREATED' && '👉 Mission drafted & 8-point safety verified. Click below for official signoff.'}
            {simState.currentStep === 'MISSION_APPROVED' && '👉 Mission approved. Click below to dispatch carrier convoy from Guwahati.'}
            {simState.currentStep === 'IN_TRANSIT' && !simState.currentRoutePlan?.isRerouted && '👉 Convoy in transit. Click below to simulate second blockage on Nagaon-Dabaka highway.'}
            {simState.currentStep === 'ROAD_BLOCKED' && '👉 Culvert collapse reported. Click below to reroute dynamically from current vehicle coordinates.'}
            {simState.currentStep === 'IN_TRANSIT' && simState.currentRoutePlan?.isRerouted && !simState.vehicleFailure && '👉 Rerouted convoy advancing. Click below to simulate critical vehicle engine breakdown.'}
            {simState.currentStep === 'VEHICLE_FAILURE' && '👉 Carrier disabled. Click below to rank fleet candidates and assign safe replacement.'}
            {simState.currentStep === 'HANDOVER_PENDING' && '👉 Replacement vehicle arrived at handover point. Click below to confirm cargo transfer.'}
            {simState.currentStep === 'IN_TRANSIT' && simState.handoverPlan?.isHandoverConfirmed && '👉 Replacement advancing along continuation corridor. Click below to reach road terminus (VAP).'}
            {simState.currentStep === 'LAST_MILE_REQUIRED' && '👉 Vehicle at VAP. 3.8 km non-road gap requires SDRF field team carry. Click below to deliver.'}
            {simState.currentStep === 'LAST_MILE_COMPLETED' && '👉 Relief supplies safely handed over. Click below for District Magistrate signoff.'}
            {simState.currentStep === 'COMPLETED' && '🎉 Mission 100% Accomplished! Relief delivered with complete audit trail preserved.'}
          </div>

          <div className="flex items-center gap-3 shrink-0 flex-wrap">
            {simState.currentStep === 'IDLE' && (
              <button
                onClick={() => setSimState(triggerAIWarning)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Sparkles className="w-4 h-4" /> 1. Trigger AI Warning
              </button>
            )}
            {simState.currentStep === 'AI_WARNING' && (
              <button
                onClick={() => setSimState(submitFieldReport)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Radio className="w-4 h-4" /> 2. Submit Field Report
              </button>
            )}
            {simState.currentStep === 'FIELD_REPORTED' && (
              <button
                onClick={() => setSimState(confirmDisruption)}
                className="bg-red-600 hover:bg-red-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <ShieldCheck className="w-4 h-4" /> 3. Confirm Road Blockage
              </button>
            )}
            {simState.currentStep === 'OFFICIAL_CONFIRMED' && (
              <button
                onClick={() => setSimState(calculateDynamicCrisisRoute)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Compass className="w-4 h-4" /> 4. Calculate Bypass & VAP
              </button>
            )}
            {simState.currentStep === 'ROUTE_CALCULATED' && (
              <button
                onClick={() => setSimState(createCrisisMission)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <FileText className="w-4 h-4" /> 5. Create Mission & Safety Check
              </button>
            )}
            {simState.currentStep === 'MISSION_CREATED' && (
              <button
                onClick={() => setSimState(approveCrisisMission)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <CheckCircle className="w-4 h-4" /> 6. Official Approval
              </button>
            )}
            {simState.currentStep === 'MISSION_APPROVED' && (
              <button
                onClick={() => setSimState(dispatchCrisisMission)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Truck className="w-4 h-4" /> 7. Dispatch Convoy
              </button>
            )}
            {simState.currentStep === 'IN_TRANSIT' && !simState.currentRoutePlan?.isRerouted && (
              <button
                onClick={() => setSimState(triggerEnRouteRoadBlockage)}
                className="bg-red-600 hover:bg-red-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <AlertOctagon className="w-4 h-4" /> 8. En-Route Blockage
              </button>
            )}
            {simState.currentStep === 'ROAD_BLOCKED' && (
              <button
                onClick={() => setSimState(executeDynamicRerouteFromCurrentPosition)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <RefreshCw className="w-4 h-4" /> 9. Dynamic Reroute (Keep Position)
              </button>
            )}
            {simState.currentStep === 'IN_TRANSIT' && simState.currentRoutePlan?.isRerouted && !simState.vehicleFailure && (
              <button
                onClick={() => setSimState(triggerEnRouteVehicleFailure)}
                className="bg-red-700 hover:bg-red-800 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Wrench className="w-4 h-4" /> 10. Simulate Vehicle Failure
              </button>
            )}
            {simState.currentStep === 'VEHICLE_FAILURE' && (
              <button
                onClick={() => setSimState(findAndAssignSafeReplacement)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Shield className="w-4 h-4" /> 11. Assign Replacement Vehicle
              </button>
            )}
            {simState.currentStep === 'HANDOVER_PENDING' && (
              <button
                onClick={() => setSimState(confirmOnSiteHandover)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Check className="w-4 h-4" /> 12. Confirm On-Site Handover
              </button>
            )}
            {simState.currentStep === 'IN_TRANSIT' && simState.handoverPlan?.isHandoverConfirmed && (
              <button
                onClick={() => setSimState(reachVehicleAccessPoint)}
                className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 font-bold cursor-pointer"
              >
                <Anchor className="w-4 h-4" /> 13. Reach VAP Terminus
              </button>
            )}
            {simState.currentStep === 'LAST_MILE_REQUIRED' && (
              <button
                onClick={() => setSimState(completeLastMileFieldResponse)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <Activity className="w-4 h-4" /> 14. Complete Last-Mile Delivery
              </button>
            )}
            {simState.currentStep === 'LAST_MILE_COMPLETED' && (
              <button
                onClick={() => setSimState(officiallyCompleteMission)}
                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
              >
                <CheckCircle className="w-4 h-4" /> 15. Officially Complete Mission
              </button>
            )}

            <button
              onClick={() => setSimState(resetSimulation)}
              className="min-h-[44px] px-3.5 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-slate-700 cursor-pointer flex items-center justify-center"
              title="Reset Scenario to Initial State"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* SIH Judge Explanation / "WHAT IS HAPPENING?" Story Card */}
        {(() => {
          let stepNumber: number | string = 0
          let stepTitle = 'Initial Standing By'
          let whatIsHappening = 'Operational demo scenario loaded with Guwahati Apex Logistics Hub and Haflong Remote Settlement destination coordinates [25.1843, 93.0182].'
          let whyItMatters = 'Demonstrates arbitrary coordinate emergency dispatch without predefined corridor constraints.'
          let currentStatus = 'IDLE'

          switch (simState.currentStep) {
            case 'IDLE':
              stepNumber = 0
              stepTitle = 'Initial Standing By'
              whatIsHappening = 'Operational demo scenario loaded with Guwahati Apex Logistics Hub and Haflong Remote Settlement destination coordinates [25.1843, 93.0182].'
              whyItMatters = 'Demonstrates arbitrary coordinate emergency dispatch without predefined corridor constraints.'
              currentStatus = 'IDLE'
              break
            case 'AI_WARNING':
              stepNumber = 1
              stepTitle = 'AI Disruption Prediction Advisory'
              whatIsHappening = 'AI Disruption Predictor flagged 84% probability of slope failure on Lumding Hill Sector due to continuous rainfall. Route remains passable.'
              whyItMatters = 'Demonstrates proactive predictive early warnings before mountain lifelines collapse. Road remains open (Advisory).'
              currentStatus = 'ADVISORY ONLY'
              break
            case 'FIELD_REPORTED':
              stepNumber = 2
              stepTitle = 'Ground Officer Field Patrol Report'
              whatIsHappening = 'Field officer patrol logged 120m active rockfall debris on NH-27 KM 48. Status is set to reported (Awaiting Verification).'
              whyItMatters = 'Demonstrates ground officer verification flow. Unverified reports do not prematurely close roads.'
              currentStatus = 'AWAITING VERIFICATION'
              break
            case 'OFFICIAL_CONFIRMED':
              stepNumber = 3
              stepTitle = 'Official Disaster Authority Confirmation'
              whatIsHappening = 'District Magistrate officially confirms road closure. NH-27 Lumding Sector is officially closed.'
              whyItMatters = 'Enforces official administrative gatekeeping before system invalidates road segment.'
              currentStatus = 'ROAD BLOCKED'
              break
            case 'ROUTE_CALCULATED':
              stepNumber = 4
              stepTitle = 'Dynamic Route Calculation & VAP'
              whatIsHappening = 'Dijkstra and OSRM recalculate bypass route and calculate Vehicle Access Point (VAP) with 3.8 km non-road last mile.'
              whyItMatters = 'Solves non-road reachability gap (3.8 km) to ensure relief reach remote settlements.'
              currentStatus = 'BYPASS IDENTIFIED'
              break
            case 'MISSION_CREATED':
              stepNumber = 5
              stepTitle = 'Mission Drafted & 8-Point Safety Gate'
              whatIsHappening = 'Emergency Medical Mission drafted and 8-point physical safety gate evaluated on carrier NER-TRUCK-18.'
              whyItMatters = 'Single source of truth for deployment clearance. AI advises but never certifies.'
              currentStatus = 'SAFETY VERIFIED'
              break
            case 'MISSION_APPROVED':
              stepNumber = 6
              stepTitle = 'Official Administrative Approval'
              whatIsHappening = 'ASDMA Director of Logistics signs off on mission. Mission status transitions to APPROVED.'
              whyItMatters = 'Preserves official authority accountability and audit logs.'
              currentStatus = 'APPROVED'
              break
            case 'IN_TRANSIT':
              if (!simState.currentRoutePlan?.isRerouted) {
                stepNumber = 7
                stepTitle = 'Carrier Convoy Dispatched'
                whatIsHappening = 'Carrier cleared depot gate and is advancing along primary bypass corridor at 55 km/h.'
                whyItMatters = 'Real-road OSRM telemetry tracking.'
                currentStatus = 'IN TRANSIT'
              } else if (simState.handoverPlan?.isHandoverConfirmed) {
                stepNumber = 12
                stepTitle = 'Replacement Carrier En-Route to VAP'
                whatIsHappening = 'Replacement carrier NER-TRUCK-07 advancing along continuation corridor at 52 km/h.'
                whyItMatters = 'Seamless mission continuation after on-site custody handover.'
                currentStatus = 'IN TRANSIT'
              } else {
                stepNumber = 9
                stepTitle = 'Dynamic Rerouting Active'
                whatIsHappening = 'Convoy advancing along Lanka bypass corridor after dynamic reroute.'
                whyItMatters = 'Carrier never restarts from origin; position is strictly preserved.'
                currentStatus = 'IN TRANSIT'
              }
              break
            case 'ROAD_BLOCKED':
              stepNumber = 8
              stepTitle = 'Secondary En-Route Road Blockage'
              whatIsHappening = 'Secondary culvert collapse reported at Nagaon-Dabaka KM 24 during carrier transit.'
              whyItMatters = 'Simulates real-world unpredictable compound monsoon crises.'
              currentStatus = 'REROUTE REQUIRED'
              break
            case 'VEHICLE_FAILURE':
              stepNumber = 10
              stepTitle = 'Mechanical Vehicle Failure'
              whatIsHappening = 'Carrier NER-TRUCK-18 reports critical engine overheating. Mission transitions to INTERRUPTED.'
              whyItMatters = 'Decouples mechanical vehicle breakdown from environmental road blockage.'
              currentStatus = 'MISSION INTERRUPTED'
              break
            case 'HANDOVER_PENDING':
              stepNumber = 11
              stepTitle = 'Replacement Assigned & Handover Pending'
              whatIsHappening = 'Fleet candidate NER-TRUCK-07 (READY) assigned to Lanka Depot Yard handover point.'
              whyItMatters = 'Deterministic suitability ranking disqualifies unsafe or committed vehicles.'
              currentStatus = 'HANDOVER PENDING'
              break
            case 'LAST_MILE_REQUIRED':
              stepNumber = 13
              stepTitle = 'Vehicle Access Point Reached'
              whatIsHappening = 'Carrier arrives at Haflong River VAP. 3.8 km non-road gap requires SDRF field team carry.'
              whyItMatters = 'Prevents false auto-completion when road ends before crisis site.'
              currentStatus = 'LAST-MILE REQUIRED'
              break
            case 'LAST_MILE_COMPLETED':
              stepNumber = 14
              stepTitle = 'Last-Mile Field Carry Delivered'
              whatIsHappening = 'SDRF mountain field team completes off-road supply delivery to Haflong relief camp.'
              whyItMatters = 'Field verification of cargo delivery before official completion.'
              currentStatus = 'PAYLOAD DELIVERED'
              break
            case 'COMPLETED':
              stepNumber = 15
              stepTitle = 'Official Sign-off & Mission Accomplished'
              whatIsHappening = 'District Magistrate signs official mission closure and records audit log. Digital profile and AI health updated.'
              whyItMatters = 'Preserves complete government audit trail and feeds historical predictive maintenance.'
              currentStatus = 'MISSION COMPLETED'
              break
          }

          return (
            <JudgeExplanationCard
              stepNumber={stepNumber}
              stepTitle={stepTitle}
              whatIsHappening={whatIsHappening}
              whyItMatters={whyItMatters}
              currentStatus={currentStatus}
            />
          )
        })()}

        {/* Live Operational Event Log */}
        <div className="bg-slate-50 border border-slate-200 rounded p-4 sm:p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
            <span className="text-xs uppercase font-bold text-slate-700 flex items-center gap-2">
              <Activity className="w-4 h-4 text-[#fb792b]" /> Operational Event & Audit Trail ({simState.events.length})
            </span>
            <span className="text-xs font-mono text-slate-500">SIMULATED TIMELINE</span>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2.5 pr-1 text-xs sm:text-[13px]">
            {simState.events.map(evt => (
              <div key={evt.id} className="bg-white border border-slate-200 rounded p-3 sm:p-3.5 space-y-1">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="font-mono text-[#213d77] font-bold text-xs">{evt.timestamp}</span>
                    <strong className="text-slate-900 text-xs sm:text-[13.5px]">{evt.type.replace(/_/g, ' ')}</strong>
                  </div>
                  <span className="text-xs font-mono text-slate-500 font-semibold">{evt.actor}</span>
                </div>
                <p className="text-xs sm:text-[13px] text-slate-700 leading-relaxed">{evt.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ── 4. OPERATIONAL KPI SUMMARY RIBBON ── */}
      <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-4">
        {[
          {
            label: t('active_alerts'),
            value: activeIncidentsCount,
            sub: `${reportedPendingCount} Reported / ${confirmedDisruptionsCount} Confirmed`,
            borderClass: activeIncidentsCount > 0 ? 'border-red-300 bg-red-50/50' : 'border-slate-200 bg-white',
            valColor: activeIncidentsCount > 0 ? 'text-red-700' : 'text-[#213d77]',
            dot: activeIncidentsCount > 0 ? 'bg-red-500 animate-ping' : 'bg-slate-400',
          },
          {
            label: t('blocked_corridors'),
            value: confirmedDisruptionsCount,
            sub: 'Dynamic Dijkstra Avoidance',
            borderClass: confirmedDisruptionsCount > 0 ? 'border-red-300 bg-red-50/50' : 'border-slate-200 bg-white',
            valColor: confirmedDisruptionsCount > 0 ? 'text-red-700' : 'text-[#213d77]',
            dot: confirmedDisruptionsCount > 0 ? 'bg-red-500' : 'bg-slate-400',
          },
          {
            label: language === 'hi' ? 'उच्च जोखिम गलियारे' :
                   language === 'as' ? 'উচ্চ বিপদসংকুল পথ' :
                   language === 'bn' ? 'উচ্চ ঝুঁকিপূর্ণ রুট' :
                   language === 'mn' ? 'ꯈꯨꯗꯣꯡꯊꯤꯕꯥ ꯂꯝꯕꯤ' :
                   'HIGH-RISK CORRIDORS',
            value: highRiskCorridorsCount,
            sub: 'AI Early Warning Active',
            borderClass: highRiskCorridorsCount > 0 ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200 bg-white',
            valColor: highRiskCorridorsCount > 0 ? 'text-amber-700' : 'text-[#213d77]',
            dot: highRiskCorridorsCount > 0 ? 'bg-amber-500' : 'bg-slate-400',
          },
          {
            label: t('active_fleet'),
            value: vehiclesInTransitCount,
            sub: 'Real Road OSRM Paths',
            borderClass: 'border-slate-200 bg-white',
            valColor: 'text-[#213d77]',
            dot: 'bg-blue-600',
          },
          {
            label: language === 'hi' ? 'महत्वपूर्ण आपूर्ति' :
                   language === 'as' ? 'গুৰুত্বপূৰ্ণ সাহায্য' :
                   language === 'bn' ? 'জরুরি ত্রাণ চালান' :
                   language === 'mn' ? 'ꯃꯔꯨꯑꯣꯏꯕꯥ ꯄꯣꯠ-ꯆꯩ' :
                   'CRITICAL SHIPMENTS',
            value: criticalShipmentsCount,
            sub: 'Medicines & Relief Cargo',
            borderClass: 'border-slate-200 bg-white',
            valColor: 'text-emerald-700',
            dot: 'bg-emerald-600',
          },
          {
            label: language === 'hi' ? 'फील्ड सिंक कतार' :
                   language === 'as' ? 'ফিল্ড ছিংক শাৰী' :
                   language === 'bn' ? 'ফিল্ড সিঙ্ক কিউ' :
                   language === 'mn' ? 'ꯄꯥꯎ ꯁꯤꯡ-ꯖꯤꯡ' :
                   'FIELD SYNC QUEUE',
            value: pendingCount,
            sub: isOnline ? 'All Reports Synchronized' : 'Buffered in IndexedDB',
            borderClass: pendingCount > 0 ? 'border-amber-300 bg-amber-50/50' : 'border-slate-200 bg-white',
            valColor: pendingCount > 0 ? 'text-amber-700' : 'text-emerald-700',
            dot: pendingCount > 0 ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500',
          },
        ].map(({ label, value, sub, borderClass, valColor, dot }) => (
          <div key={label} className={`gov-card p-4 sm:p-5 border shadow-xs space-y-1 ${borderClass}`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-600">{label}</span>
              <span className={`w-2.5 h-2.5 rounded-full ${dot}`} />
            </div>
            <p className={`text-3xl sm:text-4xl font-black font-mono ${valColor}`}>{value}</p>
            <p className="text-xs text-slate-500 leading-tight truncate mt-1">{sub}</p>
          </div>
        ))}
      </div>

      {/* ── 5. TWO-COLUMN COMMAND CENTER LAYOUT ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
        {/* LEFT COLUMN: Critical Alerts & Active Logistics (2 cols on lg) */}
        <div className="lg:col-span-2 space-y-6 sm:space-y-8">
          {/* Critical Operational Alerts */}
          <div className="gov-card p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-2.5">
                <AlertTriangle className="w-5 h-5 text-[#fb792b]" />
                <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                  Critical Operational Alerts ({criticalAlerts.length})
                </h2>
              </div>
              <Link href="/map" className="text-xs sm:text-sm text-[#213d77] hover:text-[#fb792b] flex items-center gap-1 font-bold">
                Open Full Map <ArrowRight className="w-4 h-4" />
              </Link>
            </div>

            {criticalAlerts.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded p-8 text-center text-xs sm:text-sm text-emerald-800 flex flex-col items-center justify-center gap-2.5">
                <CheckCircle className="w-8 h-8 text-emerald-600" />
                <span className="font-bold text-base">ALL CLEAR</span>
                <span className="text-slate-600 text-xs sm:text-sm">All monitored NER corridors open. No critical disruptions or delayed convoys.</span>
              </div>
            ) : (
              <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                {criticalAlerts.map(a => (
                  <div key={a.id} className="bg-slate-50 border border-slate-200 rounded p-4 space-y-2 hover:border-slate-300 transition-colors">
                    <div className="flex items-center justify-between">
                      <span className={`text-xs font-bold px-2.5 py-1 rounded border uppercase font-mono ${a.badgeColor}`}>
                        {a.badgeText}
                      </span>
                      <span className="text-xs text-slate-500 font-mono flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-slate-400" /> {a.timestamp}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="font-bold text-slate-900 text-xs sm:text-sm">{a.title}</p>
                      <span className="text-xs sm:text-[13px] text-[#213d77] font-bold">{a.corridor}</span>
                    </div>
                    <p className="text-xs sm:text-[13px] text-slate-700 leading-relaxed">{a.detail}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* ── PHASE 18: REGIONAL LOGISTICS INTELLIGENCE & RESOURCE ALLOCATION BOARD ── */}
          <div className="gov-card p-5 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-3">
                <Compass className="w-6 h-6 text-[#fb792b]" />
                <div>
                  <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                    Regional Logistics Priority & Resource Allocation ({logisticsPlans.length})
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                    Multi-criteria crisis matching, verified depot source ranking, vehicle safety gate & last-mile calculation
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs bg-blue-50 border border-blue-200 text-[#213d77] px-3 py-1 rounded font-mono font-bold uppercase">
                  HUMAN APPROVAL MANDATED
                </span>
              </div>
            </div>

            {/* Recommended Logistics Plans */}
            <div className="space-y-4">
              {logisticsPlans.map(plan => (
                <div
                  key={plan.planId}
                  className="bg-slate-50 border border-slate-200 hover:border-[#fb792b] rounded p-4 sm:p-5 space-y-3.5 transition-all"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                    <div className="flex items-center gap-2.5 flex-wrap">
                      <span
                        className={`text-xs font-mono font-bold px-2.5 py-1 rounded border uppercase ${
                          plan.priority === 'P1_CRITICAL'
                            ? 'bg-red-100 border-red-300 text-red-800'
                            : 'bg-amber-100 border-amber-300 text-amber-800'
                        }`}
                      >
                        {plan.priority.replace('_', ' ')}
                      </span>
                      <strong className="text-slate-900 text-xs sm:text-sm font-bold">
                        Emergency {plan.commodity} Replenishment — {plan.destination}
                      </strong>
                    </div>
                    <span className="text-xs font-mono text-[#213d77] font-bold bg-blue-100 border border-blue-200 px-2.5 py-1 rounded">
                      {plan.status.replace(/_/g, ' ')}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs sm:text-sm bg-white rounded p-3 sm:p-3.5 border border-slate-200">
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-500 block">Verified Source</span>
                      <span className="text-slate-900 font-semibold truncate block mt-0.5">{plan.sourceName}</span>
                    </div>
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-500 block">Carrier & Safety</span>
                      <span className="text-emerald-700 font-bold flex items-center gap-1 mt-0.5">
                        <Check className="w-3.5 h-3.5" /> {plan.vehicleId} ({plan.vehicleReadinessStatus})
                      </span>
                    </div>
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-500 block">Route & ETA</span>
                      <span className="text-slate-900 font-mono mt-0.5 block">
                        {plan.route.totalDistanceKm} km ({Math.round(plan.route.estimatedTravelTimeMinutes / 60)}h {plan.route.estimatedTravelTimeMinutes % 60}m)
                      </span>
                    </div>
                    <div>
                      <span className="text-xs uppercase font-bold text-slate-500 block">Last-Mile Access</span>
                      <span className="text-amber-800 font-semibold font-mono mt-0.5 block">
                        {plan.accessStatus === 'LAST_MILE_REQUIRED' ? `VAP (${plan.lastMileDistanceKm} km 4x4)` : 'Direct Road'}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-200">
                    <p className="text-xs sm:text-[13px] text-slate-700 leading-relaxed">
                      Reasoning: {plan.reasoning[0]}
                    </p>
                    <div className="flex items-center gap-2.5 shrink-0">
                      <button
                        onClick={() => setSelectedPlanForReview(plan)}
                        className="bg-white hover:bg-slate-100 text-slate-800 text-xs sm:text-sm font-bold px-3.5 py-2 min-h-[38px] rounded border border-slate-300 cursor-pointer transition-colors"
                      >
                        Review Plan
                      </button>
                      {plan.status === 'PROPOSED' && (
                        <button
                          onClick={() => {
                            const result = approveAndConvertLogisticsPlanToMission(
                              plan,
                              'Director of Logistics, ASDMA'
                            )
                            setLogisticsPlans(prev =>
                              prev.map(p => (p.planId === plan.planId ? result.plan : p))
                            )
                            setSelectedPlanForReview(null)
                          }}
                          className="btn-irctc-primary text-xs sm:text-sm font-bold px-4 py-2 min-h-[38px] rounded cursor-pointer transition-all"
                        >
                          Approve & Create Mission →
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Plan Review Modal */}
          {selectedPlanForReview && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-xs z-50 flex items-center justify-center p-4">
              <div className="bg-white border border-slate-300 rounded-lg max-w-2xl w-full p-6 sm:p-7 space-y-5 shadow-2xl text-left text-slate-800">
                <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
                  <div>
                    <span className="text-xs font-mono font-bold text-[#213d77] uppercase">
                      OFFICIAL LOGISTICS PLAN REVIEW
                    </span>
                    <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-0.5">
                      Plan {selectedPlanForReview.planId}
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedPlanForReview(null)}
                    className="text-slate-400 hover:text-slate-700 text-lg p-1.5 cursor-pointer rounded"
                  >
                    ✕
                  </button>
                </div>

                <div className="space-y-3.5 text-xs sm:text-sm">
                  <div className="bg-slate-50 rounded p-4 space-y-2.5 border border-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold uppercase text-xs">Commodity Payload</span>
                      <span className="text-slate-900 font-mono font-bold text-sm">
                        {selectedPlanForReview.quantity} {selectedPlanForReview.unit} of {selectedPlanForReview.commodity}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold uppercase text-xs">Source Depot</span>
                      <span className="text-[#213d77] font-bold text-sm">{selectedPlanForReview.sourceName}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold uppercase text-xs">Assigned Carrier</span>
                      <span className="text-emerald-700 font-bold text-sm">
                        {selectedPlanForReview.vehicleId} (Safety Gate: {selectedPlanForReview.vehicleReadinessStatus})
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500 font-bold uppercase text-xs">Total Distance / Time</span>
                      <span className="text-slate-900 font-mono font-semibold">
                        {selectedPlanForReview.route.totalDistanceKm} km / ~{Math.round(selectedPlanForReview.route.estimatedTravelTimeMinutes / 60)}h {selectedPlanForReview.route.estimatedTravelTimeMinutes % 60}m
                      </span>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <span className="text-xs uppercase font-bold text-[#213d77] block">
                      Deterministic Explainable Rationale:
                    </span>
                    <ul className="list-disc pl-5 space-y-1 text-slate-700 text-xs sm:text-[13px] leading-relaxed">
                      {selectedPlanForReview.reasoning.map((r, i) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-3 pt-3.5 border-t border-slate-200">
                  <button
                    onClick={() => setSelectedPlanForReview(null)}
                    className="min-h-[44px] px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded text-xs sm:text-sm font-bold cursor-pointer border border-slate-300 transition-colors"
                  >
                    Close
                  </button>
                  {selectedPlanForReview.status === 'PROPOSED' && (
                    <button
                      onClick={() => {
                        const result = approveAndConvertLogisticsPlanToMission(
                          selectedPlanForReview,
                          'Director of Logistics, ASDMA'
                        )
                        setLogisticsPlans(prev =>
                          prev.map(p => (p.planId === selectedPlanForReview.planId ? result.plan : p))
                        )
                        setSelectedPlanForReview(null)
                      }}
                      className="btn-irctc-primary min-h-[44px] px-5 py-2.5 rounded text-xs sm:text-sm font-bold cursor-pointer transition-all"
                    >
                      Authorize & Create Mission
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ── PHASE 19: REGIONAL RESOURCE COORDINATION & CONFLICT RESOLUTION BOARD ── */}
          <div className="gov-card p-5 sm:p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-3">
                <ShieldCheck className="w-6 h-6 text-[#fb792b]" />
                <div>
                  <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                    Regional Resource Coordination & Conflict Resolution ({resourceConflicts.length})
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
                    Multi-mission constraint solver, double-assignment detector & resource pre-emption engine
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <span className="text-xs bg-blue-50 border border-blue-200 text-[#213d77] px-3 py-1 rounded font-mono font-bold uppercase">
                  ZERO UNVERIFIED FABRICATION
                </span>
              </div>
            </div>

            {/* Resource Coordination Summary KPIs */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs sm:text-sm text-center">
              <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
                <span className="text-xs uppercase font-bold text-slate-500 block">Available Vehicles</span>
                <strong className="text-emerald-700 font-mono text-lg block mt-1">3 / 5 Ready</strong>
              </div>
              <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
                <span className="text-xs uppercase font-bold text-slate-500 block">Assigned / In-Transit</span>
                <strong className="text-[#213d77] font-mono text-lg block mt-1">2 Active</strong>
              </div>
              <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
                <span className="text-xs uppercase font-bold text-slate-500 block">Depot Reservations</span>
                <strong className="text-[#213d77] font-mono text-lg block mt-1">2 Verified</strong>
              </div>
              <div className="bg-slate-50 p-3.5 rounded border border-slate-200">
                <span className="text-xs uppercase font-bold text-slate-500 block">Active Conflicts</span>
                <strong className="text-amber-700 font-mono text-lg block mt-1">{resourceConflicts.filter(c => c.status === 'OPEN').length} Review Req.</strong>
              </div>
            </div>

            {/* Conflict Items */}
            {resourceConflicts.map(conf => (
              <div
                key={conf.conflictId}
                className="bg-slate-50 border border-amber-300 rounded p-4 sm:p-5 space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono font-bold bg-red-100 border border-red-300 text-red-800 px-2.5 py-1 rounded uppercase">
                      {conf.severity} CONFLICT
                    </span>
                    <strong className="text-slate-900 text-xs sm:text-sm font-bold">{conf.type.replace(/_/g, ' ')}: {conf.resourceName}</strong>
                  </div>
                  <span className="text-xs font-mono text-amber-900 font-bold bg-amber-100 border border-amber-300 px-2.5 py-1 rounded">
                    {conf.status}
                  </span>
                </div>

                <p className="text-xs sm:text-[13.5px] text-slate-700 leading-relaxed">
                  {conf.description}
                </p>

                <div className="bg-white p-3 rounded border border-slate-200 text-xs sm:text-[13px] space-y-1 text-slate-600">
                  <span className="text-xs uppercase font-bold text-[#213d77] block">Recommended Resolution:</span>
                  <p className="text-slate-800 leading-relaxed">{conf.recommendedResolution}</p>
                </div>

                <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-200">
                  {conf.status === 'OPEN' ? (
                    <button
                      onClick={() => {
                        setResourceConflicts(prev =>
                          prev.map(c => (c.conflictId === conf.conflictId ? { ...c, status: 'RESOLVED' } : c))
                        )
                      }}
                      className="btn-irctc-primary min-h-[44px] text-xs sm:text-sm font-bold px-5 py-2.5 rounded cursor-pointer transition-all"
                    >
                      Authorize Alternate Carrier (NER-TRUCK-07) →
                    </button>
                  ) : (
                    <span className="text-xs sm:text-sm text-emerald-700 font-bold flex items-center gap-1.5 py-1">
                      <Check className="w-4 h-4 text-emerald-600" /> Reassignment Authorized by Commander
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Essential Commodity Fleet Tracking */}
          <div className="gov-card p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-2.5">
                <Truck className="w-5 h-5 text-[#fb792b]" />
                <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                  Essential Commodity Fleet Tracking ({fleet.length})
                </h2>
              </div>
              <span className="text-xs bg-amber-50 border border-amber-300 text-amber-900 px-2.5 py-1 rounded font-mono font-bold">
                SIMULATED TELEMETRY
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {fleet.map(v => (
                <div key={v.vehicleId} className={`bg-slate-50 border rounded p-4 space-y-2.5 transition-all ${
                  v.isRerouted ? 'border-amber-300 shadow-xs' : 'border-slate-200'
                }`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#213d77] text-xs sm:text-sm font-mono">{v.vehicleId}</span>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded border uppercase font-mono ${
                        v.priority === 'CRITICAL' ? 'bg-red-100 border-red-300 text-red-800' : 'bg-blue-100 border-blue-300 text-[#213d77]'
                      }`}>
                        {v.priority}
                      </span>
                    </div>
                    <span className={`text-xs font-bold uppercase ${v.isRerouted ? 'text-amber-700' : 'text-emerald-700'}`}>
                      {v.isRerouted ? 'REROUTING' : v.status}
                    </span>
                  </div>

                  <div>
                    <p className="text-xs sm:text-sm font-bold text-slate-800">📦 {v.cargoType}</p>
                    <p className="text-xs text-slate-500 mt-0.5">{v.originHub} → {v.destinationDepot}</p>
                  </div>

                  {/* Phase 11: Vehicle Readiness Safety Gate */}
                  {(() => {
                    const vReadiness = evaluateVehicleReadiness({ vehicleId: v.vehicleId })
                    return (
                      <div className="flex items-center justify-between text-xs bg-white px-2.5 py-1.5 rounded border border-slate-200 font-mono">
                        <span className="text-slate-500 font-bold">SAFETY GATE:</span>
                        <span className={`font-bold ${vReadiness.statusBadge.textClass}`}>
                          {vReadiness.statusBadge.icon} {vReadiness.status.replace(/_/g, ' ')}
                        </span>
                      </div>
                    )
                  })()}

                  <div className="bg-white rounded p-2.5 border border-slate-200 text-xs space-y-1">
                    <div className="flex justify-between text-slate-500">
                      <span>Corridor:</span>
                      <span className="font-semibold text-slate-800 truncate max-w-[180px]">{v.currentRouteName}</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Speed / Bearing:</span>
                      <span className="font-semibold text-slate-800">{v.speedKmh} km/h • {v.headingDeg}°</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Remaining Dist:</span>
                      <span className="font-semibold text-[#213d77] font-mono">{v.distanceRemainingKm} km</span>
                    </div>
                    <div className="flex justify-between text-slate-500">
                      <span>Predicted ETA:</span>
                      <span className="font-bold text-emerald-700 font-mono">~{v.etaClockTime}</span>
                    </div>
                    {v.delayMinutes > 0 && (
                      <div className="flex justify-between text-amber-700 font-bold border-t border-slate-100 pt-1">
                        <span>Calculated Delay:</span>
                        <span className="font-mono">+{v.delayMinutes} min</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* End-to-End Operational Intelligence Chain & Event Timeline */}
          <div className="gov-card p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-2.5">
                <Activity className="w-5 h-5 text-[#fb792b]" />
                <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                  Operational Intelligence Pipeline & Timeline
                </h2>
              </div>
              <span className="text-xs text-slate-500 font-mono">Deterministic State Chain</span>
            </div>

            {/* Visual Pipeline Stages */}
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2.5 text-center text-xs">
              {[
                { stage: 'PREDICT', label: 'AI Early Warning', color: 'bg-amber-50 border-amber-300 text-amber-900' },
                { stage: 'PREPARE', label: 'Bypass Evaluated', color: 'bg-blue-50 border-blue-300 text-[#213d77]' },
                { stage: 'REPORT', label: 'Field Evidence', color: 'bg-orange-50 border-orange-300 text-orange-900' },
                { stage: 'CONFIRM', label: 'Authority Validates', color: 'bg-red-50 border-red-300 text-red-900' },
                { stage: 'RESPOND', label: 'Dijkstra Reroute', color: 'bg-blue-50 border-blue-300 text-[#213d77]' },
                { stage: 'TRACK', label: 'Road Telemetry', color: 'bg-emerald-50 border-emerald-300 text-emerald-800' },
              ].map(({ stage, label, color }) => (
                <div key={stage} className={`border rounded p-2.5 ${color}`}>
                  <p className="font-black text-xs tracking-wide">{stage}</p>
                  <p className="text-[11px] opacity-80 truncate mt-0.5">{label}</p>
                </div>
              ))}
            </div>

            {/* Event Timeline Log */}
            {operationalTimeline.length === 0 ? (
              <div className="bg-slate-50 border border-slate-200 rounded p-4 text-center text-xs sm:text-sm text-slate-500">
                <span>Standing by for live operational events. Trigger demo steps above to trace full lifecycle.</span>
              </div>
            ) : (
              <div className="space-y-2.5 text-xs sm:text-sm">
                {operationalTimeline.map((item, idx) => (
                  <div key={idx} className="bg-slate-50 border border-slate-200 rounded p-3.5 flex items-start gap-3.5">
                    <span className="font-mono text-xs text-slate-500 shrink-0 mt-0.5">{item.time}</span>
                    <div className="space-y-1 flex-1">
                      <div className="flex items-center gap-2.5">
                        <span className="font-bold text-slate-900 text-xs sm:text-sm">{item.event}</span>
                        <span className={`text-xs uppercase font-bold px-2 py-0.5 rounded border font-mono ${
                          item.category === 'predict' ? 'bg-yellow-100 border-yellow-300 text-yellow-800' :
                          item.category === 'report' ? 'bg-orange-100 border-orange-300 text-orange-800' :
                          item.category === 'confirm' ? 'bg-red-100 border-red-300 text-red-800' :
                          item.category === 'resolve' ? 'bg-emerald-100 border-emerald-300 text-emerald-800' :
                          'bg-blue-100 border-blue-300 text-blue-800'
                        }`}>
                          {item.category}
                        </span>
                      </div>
                      <p className="text-xs sm:text-[13px] text-slate-600 leading-relaxed">{item.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Dynamic Route Change Audit Log */}
          {recentRouteChanges.length > 0 && (
            <div className="gov-card p-5 sm:p-6 space-y-4">
              <div className="flex items-center gap-2.5 border-b border-slate-200 pb-3.5">
                <ChevronRight className="w-5 h-5 text-emerald-600" />
                <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                  Recent Dynamic Route Adaptations
                </h2>
              </div>
              <div className="space-y-2.5 text-xs sm:text-sm">
                {recentRouteChanges.map((rc, idx) => (
                  <div key={idx} className="bg-slate-50 border border-slate-200 rounded p-3.5 space-y-1.5">
                    <div className="flex justify-between text-slate-500">
                      <span className="font-bold text-slate-900">{rc.vehicleId}</span>
                      <span className="font-mono text-xs">{rc.timestamp}</span>
                    </div>
                    <p className="text-red-700 text-xs sm:text-[13px] font-bold">Reason: {rc.reason}</p>
                    <div className="text-xs sm:text-[13px] text-slate-700">
                      <span className="text-slate-400 line-through">{rc.oldRoute}</span> → <span className="text-emerald-700 font-bold">{rc.newRoute}</span> (+{rc.delayMinutes} min delay)
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT COLUMN: AI Predictor, Remote District Stock, and Quick Links */}
        <div className="space-y-6 sm:space-y-8">
          {/* AI Disruption Predictor Panel */}
          <PredictiveDisruptionsPanel />

          {/* Remote District Essential Commodity Reserves & Supply Gap Intelligence */}
          <div className="gov-card p-5 sm:p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3.5">
              <div className="flex items-center gap-2.5">
                <FileText className="w-5 h-5 text-[#fb792b]" />
                <h2 className="text-sm sm:text-base font-black uppercase tracking-wide text-[#213d77]">
                  Supply Status & Stock Reserves
                </h2>
              </div>
              <span className="text-xs bg-amber-50 border border-amber-300 text-amber-900 px-2 py-0.5 rounded font-mono font-bold">
                DEMO DATA
              </span>
            </div>

            <div className="space-y-3 text-xs sm:text-sm">
              {NER_DISTRICT_STOCK_RESERVES.slice(0, 4).map(res => (
                <div key={res.district} className="bg-slate-50 border border-slate-200 rounded p-3.5 space-y-2.5">
                  <div className="flex justify-between items-center">
                    <div>
                      <span className="font-bold text-slate-900 text-sm">{res.district}</span>
                      <span className="text-xs text-slate-500 ml-1.5 font-medium">({res.state})</span>
                    </div>
                    <span className={`text-xs font-bold px-2 py-0.5 rounded border uppercase font-mono ${
                      res.vulnerability_level === 'critical' ? 'bg-red-100 border-red-300 text-red-800' :
                      res.vulnerability_level === 'high' ? 'bg-amber-100 border-amber-300 text-amber-800' :
                      'bg-blue-100 border-blue-300 text-[#213d77]'
                    }`}>
                      {res.vulnerability_level}
                    </span>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-center text-xs">
                    <div className="bg-white p-2 rounded border border-slate-200">
                      <p className="text-slate-500 font-semibold">Meds</p>
                      <p className={`font-bold text-sm mt-0.5 ${res.medicine_days_left <= 2.5 ? 'text-red-700 font-black' : 'text-emerald-700'}`}>
                        {res.medicine_days_left}d
                      </p>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-200">
                      <p className="text-slate-500 font-semibold">Food/Grain</p>
                      <p className="font-bold text-sm text-[#213d77] mt-0.5">{res.food_grain_days_left}d</p>
                    </div>
                    <div className="bg-white p-2 rounded border border-slate-200">
                      <p className="text-slate-500 font-semibold">Diesel Fuel</p>
                      <p className={`font-bold text-sm mt-0.5 ${res.fuel_diesel_days_left <= 3.0 ? 'text-amber-700' : 'text-emerald-700'}`}>
                        {res.fuel_diesel_days_left}d
                      </p>
                    </div>
                  </div>

                  <div className="text-xs text-slate-500 flex items-center justify-between border-t border-slate-200 pt-1.5">
                    <span>Corridor: <span className="text-slate-800 font-semibold">{res.primary_supply_corridor}</span></span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Action Quick Bar */}
          <div className="grid grid-cols-2 gap-3.5">
            <Link
              href="/map"
              className="btn-irctc-primary min-h-[44px] flex items-center justify-center gap-2 py-3 px-4 rounded text-xs sm:text-sm font-bold shadow-xs transition-all text-center"
            >
              <MapPin className="w-4 h-4" /> Live GIS Map
            </Link>
            <Link
              href="/report"
              className="btn-irctc-navy min-h-[44px] flex items-center justify-center gap-2 py-3 px-4 rounded text-xs sm:text-sm font-bold shadow-xs transition-all text-center"
            >
              <FileText className="w-4 h-4" /> Field Report
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
