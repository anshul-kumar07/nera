'use client'

import { useState, useRef, useEffect } from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import {
  Home, MapPin, AlertTriangle, Compass, Truck,
  FileText, Bell, ScrollText, Activity, Users,
  Menu, X, Sparkles, ChevronDown, BarChart3, ShieldCheck, User
} from 'lucide-react'
import { useLanguage } from '@/lib/LanguageContext'

interface NavLink {
  href: string
  label: string
  icon: React.ComponentType<{ className?: string }>
  badge?: string
}

const primaryLinks: NavLink[] = [
  { href: '/dashboard', label: 'COMMAND CENTER', icon: Home },
  { href: '/map', label: 'LIVE MAP', icon: MapPin },
  { href: '/incidents', label: 'INCIDENTS', icon: AlertTriangle },
  { href: '/missions', label: 'MISSIONS', icon: Compass },
  { href: '/vehicles', label: 'VEHICLES', icon: Truck },
  { href: '/system', label: 'RESOURCES', icon: Activity },
]

const secondaryLinks: NavLink[] = [
  { href: '/demo', label: 'SIH DEMO WALKTHROUGH', icon: Sparkles },
  { href: '/report', label: 'REPORT FIELD HAZARD', icon: FileText },
  { href: '/notifications', label: 'NOTIFICATION DISPATCH', icon: Bell },
  { href: '/analytics', label: 'LOGISTICS ANALYTICS', icon: BarChart3 },
  { href: '/audit', label: 'STATUTORY AUDIT LOG', icon: ScrollText },
  { href: '/admin/users', label: 'USER ACCESS CONTROL (RBAC)', icon: Users },
]

export default function GovNavbar() {
  const pathname = usePathname()
  const { language } = useLanguage()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false)
  const [commanderDropdownOpen, setCommanderDropdownOpen] = useState(false)
  const dropdownRef = useRef<HTMLDivElement>(null)
  const commanderRef = useRef<HTMLDivElement>(null)

  // Close dropdown on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setMoreDropdownOpen(false)
      }
      if (commanderRef.current && !commanderRef.current.contains(event.target as Node)) {
        setCommanderDropdownOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  const isSecondaryActive = secondaryLinks.some(link => pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href)))

  return (
    <nav className="w-full bg-[#213d77] text-white select-none border-b border-[#1b3162] sticky top-0 z-40 shadow-md">
      <div className="max-w-[1440px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-11">
          {/* Desktop Navigation: Primary Items */}
          <div className="hidden lg:flex items-center space-x-0.5">
            {primaryLinks.map(({ href, label, icon: Icon, badge }) => {
              const isActive = pathname === href || (href !== '/' && href !== '/dashboard' && pathname.startsWith(href)) || (href === '/dashboard' && pathname === '/dashboard')

              return (
                <Link
                  key={href}
                  href={href}
                  className={`flex items-center gap-2 px-3.5 py-2.5 text-xs font-black tracking-wider transition-all relative whitespace-nowrap ${
                    isActive
                      ? 'bg-[#fb792b] text-white shadow-xs font-black'
                      : 'text-slate-100 hover:bg-[#1b3162] hover:text-white'
                  }`}
                >
                  <Icon className="w-4 h-4 text-white" />
                  <span>{label}</span>
                  {badge && (
                    <span className="text-[9px] font-mono bg-white text-[#fb792b] px-1.5 py-0.2 rounded font-black tracking-wide">
                      {badge}
                    </span>
                  )}
                </Link>
              )
            })}

            {/* MORE ▼ Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs font-black tracking-wider transition-all cursor-pointer ${
                  isSecondaryActive || moreDropdownOpen
                    ? 'bg-[#fb792b] text-white'
                    : 'text-slate-100 hover:bg-[#1b3162] hover:text-white'
                }`}
                aria-expanded={moreDropdownOpen}
              >
                <span>{language === 'hi' ? 'अन्य सेवाएं' : 'MORE'}</span>
                <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${moreDropdownOpen ? 'rotate-180 text-white' : 'text-slate-300'}`} />
              </button>

              {moreDropdownOpen && (
                <div className="absolute left-0 top-full mt-0.5 w-64 bg-[#1b3162] border border-[#2c4d8e] rounded-b shadow-2xl py-1.5 z-50 animate-in fade-in duration-150">
                  <div className="px-3.5 py-1 text-[10px] font-mono text-slate-400 uppercase tracking-wider border-b border-slate-700/60 mb-1">
                    GOVERNANCE & SYSTEM PORTALS
                  </div>
                  {secondaryLinks.map(({ href, label, icon: Icon }) => {
                    const isActive = pathname === href || pathname.startsWith(href)

                    return (
                      <Link
                        key={href}
                        href={href}
                        onClick={() => setMoreDropdownOpen(false)}
                        className={`flex items-center gap-2.5 px-3.5 py-2 text-xs font-bold transition-colors ${
                          isActive
                            ? 'bg-[#213d77] text-white border-l-4 border-l-[#fb792b]'
                            : 'text-slate-200 hover:bg-[#213d77] hover:text-white'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isActive ? 'text-[#fb792b]' : 'text-slate-400'}`} />
                        <span>{label}</span>
                      </Link>
                    )
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Desktop Right Side: Alerts & Commander */}
          <div className="hidden lg:flex items-center gap-3">
            {/* ALERTS with Red Badge 5 */}
            <Link
              href="/notifications"
              className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-black tracking-wider text-slate-100 hover:bg-[#1b3162] transition-colors"
            >
              <Bell className="w-4 h-4 text-slate-300" />
              <span>ALERTS</span>
              <span className="bg-red-600 text-white font-mono text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                5
              </span>
            </Link>

            {/* COMMANDER Profile Dropdown */}
            <div className="relative" ref={commanderRef}>
              <button
                onClick={() => setCommanderDropdownOpen(!commanderDropdownOpen)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-black tracking-wider text-slate-100 hover:bg-[#1b3162] transition-colors cursor-pointer border border-[#2c4d8e]"
              >
                <User className="w-4 h-4 text-[#fb792b]" />
                <span>COMMANDER</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-300" />
              </button>

              {commanderDropdownOpen && (
                <div className="absolute right-0 top-full mt-1 w-56 bg-[#1b3162] border border-[#2c4d8e] rounded-b shadow-2xl p-3 z-50 text-xs space-y-2">
                  <div className="border-b border-slate-700/60 pb-2">
                    <strong className="text-white font-bold block">Col. Rajesh Sharma</strong>
                    <span className="text-[10.5px] font-mono text-emerald-400">DISASTER LOGISTICS CMDR</span>
                  </div>
                  <Link
                    href="/admin/users"
                    onClick={() => setCommanderDropdownOpen(false)}
                    className="flex items-center gap-2 text-slate-200 hover:text-white py-1 font-semibold"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-[#fb792b]" /> RBAC Roles & Clearance
                  </Link>
                  <Link
                    href="/audit"
                    onClick={() => setCommanderDropdownOpen(false)}
                    className="flex items-center gap-2 text-slate-200 hover:text-white py-1 font-semibold"
                  >
                    <ScrollText className="w-3.5 h-3.5 text-[#fb792b]" /> Audit Trail & Sign-offs
                  </Link>
                </div>
              )}
            </div>
          </div>

          {/* Mobile Navigation Header */}
          <div className="flex lg:hidden items-center justify-between w-full">
            <span className="text-xs font-bold tracking-wider text-slate-100 flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-[#fb792b] animate-pulse" />
              OPERATIONAL MENU
            </span>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded text-slate-200 hover:bg-[#1b3162] focus:outline-none"
              aria-label="Toggle Mobile Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Dropdown Menu (Full list stacked) */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-[#1b3162] py-3 space-y-1 bg-[#1b3162] max-h-[80vh] overflow-y-auto">
            <div className="px-3 py-1 text-[11px] font-mono text-slate-400 uppercase tracking-wider">
              PRIMARY OPERATIONS
            </div>
            {primaryLinks.map(({ href, label, icon: Icon, badge }) => {
              const isActive = pathname === href || (href !== '/' && href !== '/dashboard' && pathname.startsWith(href))

              return (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center justify-between px-3.5 py-2.5 text-xs sm:text-sm font-bold rounded ${
                    isActive ? 'bg-[#213d77] text-white border-l-4 border-[#fb792b]' : 'text-slate-200 hover:bg-[#213d77]'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-[#fb792b]' : 'text-slate-400'}`} />
                    <span>{label}</span>
                  </div>
                  {badge && (
                    <span className="text-[10px] font-mono bg-[#fb792b] text-white px-2 py-0.5 rounded font-black">
                      {badge}
                    </span>
                  )}
                </Link>
              )
            })}

            <div className="px-3 pt-3 pb-1 text-[11px] font-mono text-slate-400 uppercase tracking-wider border-t border-slate-700/60 mt-2">
              GOVERNANCE & SYSTEM
            </div>
            {secondaryLinks.map(({ href, label, icon: Icon }) => {
              const isActive = pathname === href || pathname.startsWith(href)

              return (
                <Link
                  key={href}
                  href={href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 text-xs sm:text-sm font-bold rounded ${
                    isActive ? 'bg-[#213d77] text-white border-l-4 border-[#fb792b]' : 'text-slate-200 hover:bg-[#213d77]'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#fb792b]' : 'text-slate-400'}`} />
                  <span>{label}</span>
                </Link>
              )
            })}
          </div>
        )}
      </div>
    </nav>
  )
}

