'use client'

import { useEffect, useState, useRef, useMemo } from 'react'
import Link from 'next/link'
import NERMap from '@/components/NERMap'
import { INITIAL_NER_ROUTES, NER_STATES } from '@/lib/data'
import { NER_GRAPH_NODES, ActiveRoute, CargoPayloadItem, MultiModalVehicleTelemetry } from '@/lib/routing-algorithm'
import { useRealtimeIncidents } from '@/hooks/useRealtimeIncidents'
import { deriveOperationalRoutes, resolveIncidentToRoute, RouteChangeDetails } from '@/lib/incident-route-impact'
import { LastMileAccessibility } from '@/lib/last-mile'
import { RouteExplanationCard } from '@/components/RouteExplanationCard'
import {
  AlertTriangle,
  ArrowRight,
  Brain,
  CheckCircle,
  Clock,
  Crosshair,
  Filter,
  Layers,
  Loader2,
  Navigation,
  RefreshCw,
  Route as RouteIcon,
  ShieldAlert,
  Sparkles,
  Truck,
  Zap,
  MapPin,
  X,
  FileText,
  User,
  Edit3,
  CloudRain,
  Plane,
  Gauge,
  Target,
  Package,
  Compass
} from 'lucide-react'
import { useLanguage } from '@/lib/LanguageContext'

// Strategic National & Regional Supply Reserve Hubs across Pan-India
const SUPPLY_ORIGINS = [
  { id: 'Guwahati', name: '🏛️ Guwahati Multi-Modal Apex Hub (Assam Central)' },
  { id: 'Siliguri', name: '🚂 Siliguri Corridor Rail Gateway (North Bengal)' },
  { id: 'Kolkata', name: '⚓ Kolkata Maritime Port & Logistics Terminal' },
  { id: 'Delhi', name: '🏛️ New Delhi National Reserve Hub (NCR)' },
  { id: 'Patna', name: '🌾 Patna FCI Central Grain Silos' },
  { id: 'Haldia', name: '⛽ Haldia Coastal POL Petroleum Terminal' },
  { id: 'Silchar', name: '📦 Silchar Strategic Barak Valley Trans-Shipment Center' },
  { id: 'Dimapur', name: '🚆 Dimapur Freight Railhead & Trans-Shipment Hub' },
]

// Key NER Strategic Destination Depots
const DESTINATION_DEPOTS = [
  { id: 'Agartala', name: 'Agartala Apex Civil Hospital & Relief Depot (Tripura)' },
  { id: 'Imphal', name: 'Imphal RIMS Regional Medical Depot (Manipur)' },
  { id: 'Aizawl', name: 'Aizawl Emergency Fuel & Food Depot (Mizoram)' },
  { id: 'Tawang', name: 'Tawang Strategic Forward Depot (Arunachal)' },
  { id: 'Gangtok', name: 'Gangtok STNM Central Referral Hospital (Sikkim)' },
  { id: 'Dibrugarh', name: 'Dibrugarh Upper Assam Medical Complex' },
  { id: 'Shillong', name: 'NEIGRIHMS Super Specialty Institute (Meghalaya)' },
]

// Meteorological & Aviation Safety Profiles
const WEATHER_PROFILES = [
  { id: 'clear', label: '☀️ Clear Skies (🚁 High-Speed Air Sortie - 240 km/h)' },
  { id: 'monsoon_heavy', label: '🌧️ Torrential Monsoon (🚁 IFR Helicopter Sortie - Weather Delayed)' },
  { id: 'fog_dense', label: '🌫️ Dense Mountain Fog (🚁 IFR Helicopter Sortie - Radar Escort / Delayed)' },
  { id: 'thunderstorm', label: '⚡ Thunderstorm Advisory (🚁 Low-Altitude Tactical Airlift - Delayed)' },
]

export interface RouteSuggestion {
  recommended_route: string
  estimated_delay_hours: number
  reason: string
  risk_level: string
  special_instructions: string
  algorithm_applied?: string
  distance_km?: number
  waypoints?: string[]
  path_coordinates?: [number, number][]
  vehicle_telemetry?: MultiModalVehicleTelemetry
  disrupted_corridor?: string | null
  disruption_profile?: { hazard_class?: string; trigger?: string; impact?: string } | null
  region_name?: string
  origin?: string
  destination?: string
  blockedRoad?: string
  is_real_road_network?: boolean
  last_mile_accessibility?: LastMileAccessibility | null
}

// User Incident Report structure
interface UserIncidentReport {
  routeName: string
  status: 'blocked' | 'at_risk'
  hazardType: string
  description: string
  reportedBy: string
  timestamp: string
}

export default function MapPage() {
  const { t } = useLanguage()
  const {
    activeIncidents,
    connectionStatus,
    lastSync,
    confirmIncident,
    resolveIncident,
    reportIncident,
  } = useRealtimeIncidents()

  const [routes, setRoutes] = useState<ActiveRoute[]>(INITIAL_NER_ROUTES as ActiveRoute[])
  const [selectedRoute, setSelectedRoute] = useState('')
  const [originHub, setOriginHub] = useState('Guwahati')
  const [destinationDepot, setDestinationDepot] = useState('Agartala')
  const [cargoType, setCargoType] = useState('medicine')
  const [weatherCondition, setWeatherCondition] = useState('clear')
  const [customTargetCoords, setCustomTargetCoords] = useState<{ lat: number; lng: number } | null>(null)
  const [loading, setLoading] = useState(false)
  const [statusUpdating, setStatusUpdating] = useState(false)
  const [suggestion, setSuggestion] = useState<RouteSuggestion | null>(null)
  const [error, setError] = useState('')
  const [stateFilter, setStateFilter] = useState<string>('All')
  const [animationEnabled, setAnimationEnabled] = useState(true)

  // ── Left Sidebar Map Layer & Base Map Controls ──
  const [baseMapLayer, setBaseMapLayer] = useState('osm')
  const [showRoadNetwork, setShowRoadNetwork] = useState(true)
  const [showIncidentsLayer, setShowIncidentsLayer] = useState(true)
  const [showRiskLayer, setShowRiskLayer] = useState(true)
  const [showVehiclesLayer, setShowVehiclesLayer] = useState(true)
  const [showVAPLayer, setShowVAPLayer] = useState(true)
  const [showAltRouteLayer, setShowAltRouteLayer] = useState(true)
  const [showInfraLayer, setShowInfraLayer] = useState(false)

  // User-reported incident database
  const [userIncidents, setUserIncidents] = useState<Record<string, UserIncidentReport>>({})
  const [incidentModalOpen, setIncidentModalOpen] = useState(false)
  const [incidentForm, setIncidentForm] = useState({
    routeName: '',
    status: 'blocked' as 'blocked' | 'at_risk',
    hazardType: 'Landslide & Hill Slope Fracture',
    description: '',
    reportedBy: 'Field Patrol / DDMA Response Officer',
  })

  // Quick hazard tag presets for user modal
  const HAZARD_PRESETS = [
    '⛰️ Landslide & Hill Slope Fracture',
    '🌊 Flash Flood & River Submergence',
    '🌉 Bridge Scouring / Structural Defect',
    '🌧️ Severe Mudflow & Debris Silt',
    '💥 Rockfall & Road Subsidence',
    '🚧 Infrastructure Maintenance Closure',
  ]

  // Fetch routes from API
  const fetchRoutes = async () => {
    try {
      const res = await fetch('/api/routes')
      const data = await res.json()
      if (data && Array.isArray(data) && data.length > 0) {
        const merged = INITIAL_NER_ROUTES.map(initial => {
          const match = data.find((d: ActiveRoute) => d.name?.toLowerCase() === initial.name.toLowerCase() || d.id === initial.id)
          return match ? { ...initial, ...match } : initial
        })
        setRoutes(merged as ActiveRoute[])
      } else {
        setRoutes(INITIAL_NER_ROUTES as ActiveRoute[])
      }
    } catch (e) {
      console.warn('Using default routes:', e)
      setRoutes(INITIAL_NER_ROUTES as ActiveRoute[])
    }
  }

  // Auto-calculate bypass route when any road is compromised or user marks custom destination
  const triggerAutoSuggest = async (
    blockedName: string,
    currentRoutes: ActiveRoute[],
    targetDest?: string,
    customCoords?: { lat: number; lng: number } | null,
    targetWeather?: string
  ) => {
    setLoading(true)
    setError('')
    try {
      // Source & Destination NEVER change due to road conditions!
      const dest = targetDest || destinationDepot
      const activeWeather = targetWeather || weatherCondition

      const selectedObj = currentRoutes.find(r => r.name === blockedName)
      const openRouteNames = currentRoutes.filter(r => r.status === 'open').map(r => r.name)

      const res = await fetch('/api/route-suggest', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          blockedRoute: blockedName,
          availableRoutes: openRouteNames.length > 0 ? openRouteNames : INITIAL_NER_ROUTES.filter(r => r.status === 'open').map(r => r.name),
          cargoType,
          origin: originHub,
          destination: dest,
          customTargetCoords: customCoords || customTargetCoords,
          district: selectedObj ? `${selectedObj.district}, ${selectedObj.state}` : dest,
          weatherCondition: activeWeather,
          incidents: activeIncidents,
        }),
      })
      const data = await res.json()
      if (data && !data.error) {
        setSuggestion({
          ...data,
          origin: originHub,
          destination: customCoords ? `Target Pin [${customCoords.lat.toFixed(2)}, ${customCoords.lng.toFixed(2)}]` : dest,
          blockedRoad: blockedName,
        })
      }
    } catch (err) {
      console.warn('Auto route suggest fallback:', err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    let ignore = false
    async function loadInitial() {
      await fetchRoutes()
      if (!ignore) {
        triggerAutoSuggest('', INITIAL_NER_ROUTES as ActiveRoute[], destinationDepot, null, weatherCondition)
      }
    }
    loadInitial()
    return () => {
      ignore = true
    }
  }, [])

  // Handle direct map click to mark any custom target area
  const handleMapTargetSelected = async (coords: { lat: number; lng: number }) => {
    setCustomTargetCoords(coords)
    await triggerAutoSuggest(selectedRoute, routes, undefined, coords)
  }

  // Open the User Incident Reporting Modal
  const handleOpenIncidentModal = (routeName: string, targetStatus: 'blocked' | 'at_risk') => {
    const existing = userIncidents[routeName]
    setIncidentForm({
      routeName,
      status: targetStatus,
      hazardType: existing?.hazardType || '⛰️ Landslide & Hill Slope Fracture',
      description: existing?.description || '',
      reportedBy: existing?.reportedBy || 'Field Patrol / DDMA Response Officer',
    })
    setIncidentModalOpen(true)
  }

  // Submit User Incident Report
  const handleSubmitIncident = async () => {
    const routeName = incidentForm.routeName
    if (!routeName) return

    const nowFormatted = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST (Live Report)'
    const report: UserIncidentReport = {
      routeName,
      status: incidentForm.status,
      hazardType: incidentForm.hazardType || 'Field Road Disruption',
      description: incidentForm.description.trim() || 'Severe obstacle & carriage blockage reported by field personnel.',
      reportedBy: incidentForm.reportedBy.trim() || 'Field Inspector',
      timestamp: nowFormatted,
    }

    setUserIncidents(prev => ({ ...prev, [routeName]: report }))
    setIncidentModalOpen(false)

    // Find coordinates of affected corridor or fallback
    const matchedRoute = routes.find(
      r => r.name.toLowerCase() === routeName.toLowerCase() || r.name.toLowerCase().includes(routeName.toLowerCase())
    )
    const lat = matchedRoute?.coordinates?.[0]?.[0] || (customTargetCoords ? customTargetCoords.lat : 26.1445)
    const lng = matchedRoute?.coordinates?.[0]?.[1] || (customTargetCoords ? customTargetCoords.lng : 91.7362)

    await reportIncident({
      route_id: matchedRoute?.id || null,
      route_name: routeName,
      type: incidentForm.hazardType.toLowerCase().includes('landslide') ? 'landslide' :
            incidentForm.hazardType.toLowerCase().includes('flood') ? 'flood' :
            incidentForm.hazardType.toLowerCase().includes('bridge') ? 'bridge_failure' :
            incidentForm.hazardType.toLowerCase().includes('road') ? 'road_damage' : 'congestion',
      severity: incidentForm.status === 'blocked' ? 'critical' : 'high',
      status: 'reported',
      description: incidentForm.description.trim() || 'Severe obstacle reported by field personnel.',
      reported_by: incidentForm.reportedBy.trim() || 'Field Patrol Inspector',
      lat,
      lng,
    })

    await updateRouteStatus(routeName, incidentForm.status)
  }

  // Handle reporting or updating route status dynamically
  const updateRouteStatus = async (routeName: string, newStatus: string) => {
    if (!routeName) return
    setStatusUpdating(true)
    try {
      // 1. Flexible matching and instant state update
      const updated = routes.map(r => {
        const isMatch =
          r.name.toLowerCase() === routeName.toLowerCase() ||
          r.name.toLowerCase().includes(routeName.toLowerCase()) ||
          routeName.toLowerCase().includes(r.name.toLowerCase()) ||
          (r.highway_number && routeName.toLowerCase().includes(r.highway_number.toLowerCase()))
        return isMatch ? { ...r, status: newStatus } : r
      })
      setRoutes(updated)

      // 2. Persist to API if route exists in backend
      const matched = routes.find(
        r =>
          r.name.toLowerCase() === routeName.toLowerCase() ||
          r.name.toLowerCase().includes(routeName.toLowerCase()) ||
          routeName.toLowerCase().includes(r.name.toLowerCase()) ||
          (r.highway_number && routeName.toLowerCase().includes(r.highway_number.toLowerCase()))
      )
      if (matched && matched.id) {
        fetch(`/api/routes/${matched.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: newStatus }),
        }).catch(e => console.warn('Route persist error:', e))
      }

      // 3. Immediately trigger Dijkstra recalculation with the updated routes state!
      if (newStatus === 'blocked' || newStatus === 'at_risk' || newStatus === 'damaged') {
        await triggerAutoSuggest(routeName, updated)
      } else if (newStatus === 'open') {
        // Clear incident record when re-opened
        setUserIncidents(prev => {
          const next = { ...prev }
          delete next[routeName]
          return next
        })
        await triggerAutoSuggest('', updated)
      }
    } catch (err) {
      console.warn('Status update error:', err)
    } finally {
      setStatusUpdating(false)
    }
  }

  const [routeChangeDetails, setRouteChangeDetails] = useState<RouteChangeDetails | null>(null)

  // Derive operational route statuses: Base routes + Confirmed incidents = Current accessibility
  const { operationalRoutes } = useMemo(() => {
    return deriveOperationalRoutes(routes, activeIncidents)
  }, [routes, activeIncidents])

  const handleSuggest = async () => {
    const targetRoad = selectedRoute || (destinationDepot ? `Corridor to ${destinationDepot}` : 'NH-27')
    await triggerAutoSuggest(targetRoad, operationalRoutes, destinationDepot, customTargetCoords)
  }

  // Filter routes based on selected state if any
  const displayedRoutes = useMemo(() => {
    return stateFilter === 'All'
      ? operationalRoutes
      : operationalRoutes.filter(r => r.state?.toLowerCase().includes(stateFilter.toLowerCase()))
  }, [stateFilter, operationalRoutes])

  // Disrupted vs Open routes
  const disruptedRoutes = useMemo(() => {
    return operationalRoutes.filter(
      r => r.status === 'blocked' || r.status === 'damaged' || r.status === 'at_risk'
    )
  }, [operationalRoutes])

  const handleConfirmAndReroute = async (incidentId: string) => {
    const inc = activeIncidents.find(i => i.id === incidentId)
    await confirmIncident(incidentId)
    if (inc) {
      const { matchedRoute } = resolveIncidentToRoute(inc, operationalRoutes)
      if (matchedRoute) {
        setSelectedRoute(matchedRoute.name)
        const prevDist = suggestion?.distance_km || 140
        const prevDur = suggestion?.estimated_delay_hours || 3.0
        const prevRoute = suggestion?.recommended_route || matchedRoute.name

        await triggerAutoSuggest(matchedRoute.name, operationalRoutes)

        setRouteChangeDetails({
          previousRoute: prevRoute,
          newRoute: 'Safe Operational Alternate Corridor',
          previousDistanceKm: prevDist,
          newDistanceKm: prevDist + 28,
          deltaDistanceKm: 28,
          previousDurationHours: prevDur,
          newDurationHours: prevDur + 0.75,
          deltaMinutes: 45,
          previousRisk: 'CRITICAL',
          newRisk: 'SAFE',
          reason: `Confirmed ${inc.type || 'Hazard'} Disruption: ${inc.description || 'Ground blockage verified'}`,
          incidentId: inc.id,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) + ' IST',
          bridgeSafetyPassed: true,
          bridgeSafetyLabel: 'Bridge Load Rating 24T Passed',
        })
      }
    }
  }

  const handleResolveAndRestore = async (incidentId: string) => {
    await resolveIncident(incidentId)
    setRouteChangeDetails(null)
    await triggerAutoSuggest('', operationalRoutes)
  }

  const legend = [
    { label: t('legend_open'), color: '#16a34a' },
    { label: t('legend_at_risk'), color: '#d97706' },
    { label: t('legend_blocked'), color: '#dc2626' },
    { label: t('legend_damaged'), color: '#7c3aed' },
  ]

  const originNode = NER_GRAPH_NODES[originHub] || { lat: 26.1445, lng: 91.7362, name: originHub }
  const originCoordsObj = {
    lat: originNode.lat,
    lng: originNode.lng,
    name: originNode.name || originHub,
  }

  const destinationNode = NER_GRAPH_NODES[destinationDepot] || { lat: 23.8315, lng: 91.2868, name: destinationDepot }
  const targetCoordsObj = customTargetCoords
    ? {
        lat: customTargetCoords.lat,
        lng: customTargetCoords.lng,
        name: `Pinned Target [${customTargetCoords.lat.toFixed(3)}, ${customTargetCoords.lng.toFixed(3)}]`,
      }
    : {
        lat: destinationNode.lat,
        lng: destinationNode.lng,
        name: destinationNode.name || destinationDepot,
      }

  return (
    <div className="space-y-4 text-slate-800 font-sans select-none" suppressHydrationWarning>

      {/* ── Realtime Route Change Explanation Alert Modal/Card ── */}
      {routeChangeDetails && (
        <RouteExplanationCard
          changeDetails={routeChangeDetails}
          onDismiss={() => setRouteChangeDetails(null)}
        />
      )}

      {/* ── 3-COLUMN MAIN STAGE (MAP CONTROLS | LIVE GIS MAP | MISSION CONTROLS) ── */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-start">

        {/* ── 1. LEFT SIDEBAR: MAP CONTROLS (col-span-2) ── */}
        <div className="xl:col-span-2 space-y-4">
          <div className="gov-card p-4 space-y-4 bg-white border border-slate-200 rounded-lg shadow-xs">
            <h2 className="text-xs font-black text-[#213d77] uppercase tracking-wider border-b border-slate-200 pb-2">
              MAP CONTROLS
            </h2>

            {/* Base Map Select */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-600 block uppercase">
                Base Map
              </label>
              <select
                value={baseMapLayer}
                onChange={e => setBaseMapLayer(e.target.value)}
                className="w-full bg-white border border-slate-300 rounded px-2.5 py-1.5 text-xs text-slate-800 font-semibold focus:outline-none focus:border-[#fb792b] cursor-pointer"
              >
                <option value="osm">OpenStreetMap</option>
                <option value="satellite">Satellite (ESRI)</option>
                <option value="topo">3D Mountain Terrain</option>
                <option value="dark">Dark Tactical</option>
                <option value="voyager">CARTO Voyager</option>
              </select>
            </div>

            {/* Layers Checkboxes */}
            <div className="space-y-2 pt-1 border-t border-slate-200">
              <label className="text-[11px] font-bold text-slate-600 block uppercase">
                Layers
              </label>
              <div className="space-y-1.5 text-xs text-slate-700 font-medium">
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showRoadNetwork}
                    onChange={e => setShowRoadNetwork(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Road Network</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showIncidentsLayer}
                    onChange={e => setShowIncidentsLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Incidents</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showRiskLayer}
                    onChange={e => setShowRiskLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Predicted Risk</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showVehiclesLayer}
                    onChange={e => setShowVehiclesLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Vehicles</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showVAPLayer}
                    onChange={e => setShowVAPLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Vehicle Access Point</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showAltRouteLayer}
                    onChange={e => setShowAltRouteLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span>Alternate Route</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer hover:text-slate-900">
                  <input
                    type="checkbox"
                    checked={showInfraLayer}
                    onChange={e => setShowInfraLayer(e.target.checked)}
                    className="w-3.5 h-3.5 text-[#213d77] rounded border-slate-300 focus:ring-[#fb792b] cursor-pointer"
                  />
                  <span className="text-slate-500">Infrastructure (Optional)</span>
                </label>
              </div>
            </div>

            {/* Map Legend */}
            <div className="space-y-2 pt-1 border-t border-slate-200">
              <label className="text-[11px] font-bold text-slate-600 block uppercase">
                Map Legend
              </label>
              <div className="space-y-1.5 text-[11px] text-slate-700 font-semibold">
                <div className="flex items-center gap-2">
                  <span className="w-4 h-1 bg-[#16a34a] rounded-sm shrink-0" />
                  <span>OPEN ROAD</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-1 bg-[#d97706] rounded-sm shrink-0" />
                  <span>PREDICTED RISK</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-1 bg-[#ea580c] rounded-sm shrink-0" />
                  <span>REPORTED INCIDENT</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-1 bg-[#dc2626] border-b border-dashed border-red-900 rounded-sm shrink-0" />
                  <span>CONFIRMED BLOCKAGE</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-4 h-1 bg-[#7c3aed] rounded-sm shrink-0" />
                  <span>RESOLVED</span>
                </div>
                <div className="flex items-center gap-2 pt-1 border-t border-slate-100">
                  <span className="text-sm">🚛</span>
                  <span>ACTIVE VEHICLE</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">📍</span>
                  <span className="text-red-700">CRISIS LOCATION</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-sm">📍</span>
                  <span className="text-purple-700">VEHICLE ACCESS POINT</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* ── 2. CENTER VIEWPORT: LIVE OPERATIONAL GIS MAP (col-span-7) ── */}
        <div className="xl:col-span-7 min-h-[720px] h-[720px] rounded-lg overflow-hidden border border-slate-300 relative flex flex-col gov-card shadow-xs">
          <NERMap
            routes={displayedRoutes}
            highlightedRouteName={suggestion?.recommended_route}
            blockedRouteName={selectedRoute}
            missionPathCoordinates={suggestion?.path_coordinates}
            originCoords={originCoordsObj}
            targetCoords={targetCoordsObj}
            isCrisisActive={Boolean(
              selectedRoute ||
              routes.some(r => r.status === 'blocked' || r.status === 'at_risk' || r.status === 'damaged') ||
              customTargetCoords ||
              (suggestion && suggestion.blockedRoad)
            )}
            animationEnabled={animationEnabled}
            vehicleTelemetry={suggestion?.vehicle_telemetry}
            activeIncidents={activeIncidents}
            lastMileAccessibility={suggestion?.last_mile_accessibility}
            connectionStatus={connectionStatus}
            lastSync={lastSync}
            baseLayer={baseMapLayer}
            showRoadNetwork={showRoadNetwork}
            showIncidents={showIncidentsLayer}
            showRiskPredictions={showRiskLayer}
            showVehicles={showVehiclesLayer}
            showVehicleAccessPoint={showVAPLayer}
            showAlternateRoute={showAltRouteLayer}
            showInfrastructure={showInfraLayer}
            onSelectRoute={(name) => setSelectedRoute(name)}
            onSelectTargetCoords={handleMapTargetSelected}
            onReportRouteStatus={(name, status) => {
              setSelectedRoute(name)
              if (status === 'open') {
                updateRouteStatus(name, status)
              } else {
                handleOpenIncidentModal(name, status)
              }
            }}
            onConfirmIncident={handleConfirmAndReroute}
            onResolveIncident={handleResolveAndRestore}
          />
        </div>

        {/* ── 3. RIGHT PANEL: MISSION DETAILS & CONTROL (col-span-3) ── */}
        <div className="xl:col-span-3 space-y-3.5">

          {/* A. Active Corridor Card */}
          <div className="gov-card p-4 space-y-2.5 bg-white border border-slate-200 rounded-lg shadow-xs">
            <div className="flex items-center justify-between gap-2">
              <span className="bg-[#213d77] text-white text-[9.5px] font-mono font-black px-2 py-0.5 rounded tracking-wider">
                FASTEST DIRECT ALL-WEATHER CORRIDOR
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded border border-emerald-300">
                ALL-CLEAR
              </span>
            </div>

            <div>
              <h3 className="font-black text-sm text-slate-900 leading-tight">
                {selectedRoute || suggestion?.recommended_route || 'NH-8 Churaibari–Agartala–Sabroom Lifeline Highway'}
              </h3>
              <p className="text-xs text-slate-500 mt-0.5 flex items-center gap-1 font-medium">
                <span>📍</span> Sector: <strong>{destinationDepot || 'Agartala'}</strong>
              </p>
            </div>

            {/* Report Action Buttons */}
            <div className="flex items-center gap-2 pt-1 border-t border-slate-100 text-xs">
              <span className="text-[11px] font-bold text-slate-500">Report:</span>
              <button
                onClick={() => handleOpenIncidentModal(selectedRoute || suggestion?.recommended_route || 'NH-8', 'blocked')}
                className="flex-1 bg-red-50 hover:bg-red-100 border border-red-200 text-red-700 font-bold py-1 px-2 rounded text-[11px] transition-colors cursor-pointer text-center"
              >
                Report Block 🚫
              </button>
              <button
                onClick={() => handleOpenIncidentModal(selectedRoute || suggestion?.recommended_route || 'NH-8', 'at_risk')}
                className="flex-1 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-800 font-bold py-1 px-2 rounded text-[11px] transition-colors cursor-pointer text-center"
              >
                Report Risk ⚠️
              </button>
            </div>
          </div>

          {/* B. Assigned Vehicle & Cargo Manifest Card */}
          <div className="gov-card p-4 space-y-3 bg-white border border-slate-200 rounded-lg shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2">
              <div className="flex items-center gap-1.5 text-xs font-black text-[#213d77]">
                <Truck className="w-4 h-4 text-[#fb792b]" />
                <span>Rapid Cold-Chain Emergency Express Van</span>
              </div>
              <span className="text-[9px] bg-blue-50 text-[#213d77] border border-blue-200 px-1.5 py-0.5 rounded font-mono font-bold">
                RAPID COLD-CHAIN VAN
              </span>
            </div>

            {/* Vehicle Assignment & Arrival ETA Grid */}
            <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded border border-slate-200">
              <div>
                <span className="text-[9.5px] text-slate-500 uppercase font-bold block">ASSIGNED UNIT</span>
                <strong className="text-slate-900 font-black text-xs block">AS-01-MED-1234 (Life-Line)</strong>
                <span className="text-[11px] text-slate-600 block mt-0.5">Rajesh Kumar</span>
                <span className="text-[9.5px] text-slate-400 block leading-tight">Cold-Chain Certified Medical Logistics Specialist</span>
              </div>
              <div className="text-right">
                <span className="text-[9.5px] text-slate-500 uppercase font-bold block">ARRIVAL ETA</span>
                <strong className="text-base font-black text-[#213d77] font-mono block">9h 0m</strong>
                <span className="text-[11px] text-slate-600 block">~01:40 am IST</span>
                <span className="text-[10px] text-slate-400 block">Cruise: 62 km/h</span>
              </div>
            </div>

            {/* Distance & Speed Metres */}
            <div className="flex items-center justify-between text-xs text-slate-700 font-semibold px-1">
              <span>🗺️ Distance: <strong>555 km</strong></span>
              <span>⚡ Speed: <strong>62 km/h</strong></span>
            </div>

            {/* Fuel & Bridge Weight Compliance */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 text-xs">
              <div className="bg-slate-50 p-2 rounded border border-slate-200">
                <span className="text-[9.5px] text-slate-500 uppercase font-bold block">FUEL CONSUMPTION</span>
                <strong className="text-slate-900 font-black text-xs">83 L</strong>
              </div>
              <div className="bg-slate-50 p-2 rounded border border-slate-200">
                <span className="text-[9.5px] text-slate-500 uppercase font-bold block">BRIDGE WEIGHT CHECK</span>
                <strong className="text-emerald-700 font-black text-xs flex items-center gap-1">
                  <span>✅</span> PASSED
                </strong>
              </div>
            </div>

            {/* Essential Cargo Manifest */}
            <div className="space-y-1.5 pt-2 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs">
                <strong className="text-slate-800 text-[11px] flex items-center gap-1">
                  <Package className="w-3.5 h-3.5 text-[#fb792b]" />
                  ESSENTIAL CARGO PAYLOAD MANIFEST
                </strong>
                <span className="text-[9.5px] bg-blue-100 text-[#213d77] px-1.5 py-0.2 rounded font-mono font-bold">
                  84% LOADED
                </span>
              </div>

              <div className="text-xs text-slate-700 flex justify-between">
                <span>Urgent Cold-Chain Vaccines, Blood & Critical Drugs</span>
                <span className="font-bold text-[#213d77] font-mono">1,850 / 2,200 kg</span>
              </div>

              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div className="bg-[#213d77] h-full rounded-full" style={{ width: '84%' }} />
              </div>

              <p className="text-[11px] text-slate-600">
                <strong>Dispatched:</strong> 45,000 Vaccines + 120 Blood Plasma Units
              </p>
            </div>
          </div>

          {/* C. Multi-Modal Logistics Rationale */}
          <div className="gov-card p-3 bg-slate-50 border border-slate-200 rounded-lg text-xs space-y-1">
            <h4 className="text-[10.5px] font-black text-slate-600 uppercase tracking-wider">
              MULTI-MODAL LOGISTICS RATIONALE
            </h4>
            <p className="text-slate-700 leading-relaxed text-[11.5px]">
              {suggestion?.reason || 'Route diverted via high-elevation all-weather corridor avoiding blocked sector on Corridor to Agartala.'}
            </p>
          </div>

          {/* D. Quick Actions (2x2 Big Buttons Grid) */}
          <div className="space-y-2">
            <span className="text-[11px] font-black text-slate-600 uppercase tracking-wider block">
              QUICK ACTIONS
            </span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleOpenIncidentModal(selectedRoute || 'NH-8', 'blocked')}
                className="bg-[#fb792b] hover:bg-[#e06820] text-white font-black text-xs py-3 px-2 rounded shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>🛑</span> CONFIRM INCIDENT
              </button>
              <Link
                href="/missions"
                className="bg-[#fb792b] hover:bg-[#e06820] text-white font-black text-xs py-3 px-2 rounded shadow-xs flex items-center justify-center gap-1.5 transition-colors text-center"
              >
                <span>✅</span> APPROVE MISSION
              </Link>
              <button
                onClick={() => handleOpenIncidentModal(selectedRoute || 'NH-8', 'at_risk')}
                className="bg-[#213d77] hover:bg-[#1b3162] text-white font-black text-xs py-3 px-2 rounded shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>📝</span> REPORT INCIDENT
              </button>
              <button
                onClick={handleSuggest}
                className="bg-[#213d77] hover:bg-[#1b3162] text-white font-black text-xs py-3 px-2 rounded shadow-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <span>🔀</span> AUTHORIZE REROUTE
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ── 4. BOTTOM 2-CARD DECK: ACTIVE MISSIONS & WHAT NEEDS ATTENTION? ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">

        {/* Card 1: ACTIVE MISSIONS (2) */}
        <div className="gov-card p-4 space-y-3 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <Compass className="w-4 h-4 text-[#fb792b]" />
              <h3 className="font-black text-xs text-[#213d77] uppercase tracking-wider">
                ACTIVE MISSIONS (2)
              </h3>
            </div>
            <Link
              href="/missions"
              className="text-[11px] font-bold text-[#213d77] hover:underline"
            >
              VIEW ALL
            </Link>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500 text-[10.5px] uppercase">
                  <th className="pb-1.5 font-bold">MISSION ID</th>
                  <th className="pb-1.5 font-bold">PRIORITY</th>
                  <th className="pb-1.5 font-bold">DESTINATION</th>
                  <th className="pb-1.5 font-bold">VEHICLE</th>
                  <th className="pb-1.5 font-bold">STATUS</th>
                  <th className="pb-1.5 font-bold">ETA</th>
                  <th className="pb-1.5 font-bold">PROGRESS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-[11.5px] font-medium text-slate-800">
                <tr>
                  <td className="py-2 font-mono font-bold text-[#213d77]">MIS-2026-001</td>
                  <td className="py-2">
                    <span className="bg-red-100 text-red-800 text-[9.5px] font-bold px-1.5 py-0.5 rounded">
                      P1 CRITICAL
                    </span>
                  </td>
                  <td className="py-2">Haflong</td>
                  <td className="py-2 font-mono">NER-TRUCK-07</td>
                  <td className="py-2">
                    <span className="bg-blue-100 text-[#213d77] text-[9.5px] font-bold px-1.5 py-0.5 rounded">
                      IN TRANSIT
                    </span>
                  </td>
                  <td className="py-2 font-mono">01:44 AM</td>
                  <td className="py-2">
                    <div className="flex items-center gap-1.5">
                      <div className="w-12 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-[#213d77] h-full rounded-full" style={{ width: '68%' }} />
                      </div>
                      <span className="text-[10px] font-mono font-bold">68%</span>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td className="py-2 font-mono font-bold text-[#213d77]">MIS-2026-002</td>
                  <td className="py-2">
                    <span className="bg-amber-100 text-amber-800 text-[9.5px] font-bold px-1.5 py-0.5 rounded">
                      P2 HIGH
                    </span>
                  </td>
                  <td className="py-2">Silchar</td>
                  <td className="py-2 font-mono">NER-TRUCK-18</td>
                  <td className="py-2">
                    <span className="bg-amber-50 text-amber-800 border border-amber-300 text-[9.5px] font-bold px-1.5 py-0.5 rounded">
                      PENDING APPROVAL
                    </span>
                  </td>
                  <td className="py-2 font-mono text-slate-400">--</td>
                  <td className="py-2">
                    <div className="flex items-center gap-1.5">
                      <div className="w-12 bg-slate-200 h-1.5 rounded-full overflow-hidden">
                        <div className="bg-slate-300 h-full rounded-full" style={{ width: '0%' }} />
                      </div>
                      <span className="text-[10px] font-mono font-bold text-slate-400">0%</span>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Card 2: WHAT NEEDS ATTENTION? */}
        <div className="gov-card p-4 space-y-3 bg-white border border-slate-200 rounded-lg shadow-xs">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-600" />
              <h3 className="font-black text-xs text-[#213d77] uppercase tracking-wider">
                WHAT NEEDS ATTENTION?
              </h3>
            </div>
            <Link
              href="/notifications"
              className="text-[11px] font-bold text-[#213d77] hover:underline"
            >
              VIEW ALL
            </Link>
          </div>

          <div className="space-y-2 text-xs">
            <div className="flex items-center justify-between p-2 rounded bg-red-50/70 border border-red-200">
              <div className="flex items-center gap-2">
                <span className="bg-red-600 text-white text-[9.5px] font-bold px-1.5 py-0.5 rounded uppercase">
                  CRITICAL
                </span>
                <span className="font-semibold text-red-900">Landslide blocking NH-8 sector</span>
              </div>
              <div className="text-right text-[11px] text-slate-500 font-mono">
                <span>Dima Hasao</span> • <span>08:45 IST</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-amber-50/70 border border-amber-200">
              <div className="flex items-center gap-2">
                <span className="bg-amber-600 text-white text-[9.5px] font-bold px-1.5 py-0.5 rounded uppercase">
                  HIGH
                </span>
                <span className="font-semibold text-amber-900">Mission MIS-2026-002 awaiting approval</span>
              </div>
              <div className="text-right text-[11px] text-slate-500 font-mono">
                <span>Silchar</span> • <span>10:32 IST</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-slate-50 border border-slate-200">
              <div className="flex items-center gap-2">
                <span className="bg-slate-500 text-white text-[9.5px] font-bold px-1.5 py-0.5 rounded uppercase">
                  MEDIUM
                </span>
                <span className="font-semibold text-slate-700">Vehicle NER-TRUCK-23 maintenance due</span>
              </div>
              <div className="text-right text-[11px] text-slate-500 font-mono">
                <span>Guwahati Depot</span> • <span>09:15 IST</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── USER INCIDENT REPORTING MODAL ── */}
      {incidentModalOpen && (
        <div className="fixed inset-0 z-[2000] bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-slate-300 rounded-lg p-5 max-w-lg w-full shadow-2xl space-y-4 text-slate-800">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-red-600" />
                <h3 className="font-black text-sm text-[#213d77]">
                  File Road Disruption & Incident Report
                </h3>
              </div>
              <button
                onClick={() => setIncidentModalOpen(false)}
                className="p-1 text-slate-400 hover:text-slate-700 rounded hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Target Corridor */}
            <div className="bg-slate-50 p-2.5 rounded border border-slate-200 text-xs">
              <span className="text-slate-500 text-[10px] uppercase font-bold block">Corridor Sector:</span>
              <p className="font-bold text-[#213d77] mt-0.5">{incidentForm.routeName}</p>
            </div>

            {/* Disruption Severity Status */}
            <div>
              <label className="block text-[10px] text-slate-600 uppercase font-bold mb-1">
                Disruption Severity:
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setIncidentForm(prev => ({ ...prev, status: 'blocked' }))}
                  className={`flex-1 py-2 rounded text-xs font-bold border transition-all cursor-pointer ${
                    incidentForm.status === 'blocked'
                      ? 'bg-red-600 border-red-600 text-white shadow-xs'
                      : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  Blocked 🚫 (Impassable)
                </button>
                <button
                  type="button"
                  onClick={() => setIncidentForm(prev => ({ ...prev, status: 'at_risk' }))}
                  className={`flex-1 py-2 rounded text-xs font-bold border transition-all cursor-pointer ${
                    incidentForm.status === 'at_risk'
                      ? 'bg-amber-600 border-amber-600 text-white shadow-xs'
                      : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  At-Risk ⚠️ (Caution / Slow)
                </button>
              </div>
            </div>

            {/* Hazard Presets */}
            <div>
              <label className="block text-[10px] text-slate-600 uppercase font-bold mb-1">
                Disaster / Incident Category:
              </label>
              <div className="flex flex-wrap gap-1.5 mb-2">
                {HAZARD_PRESETS.map(preset => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setIncidentForm(prev => ({ ...prev, hazardType: preset }))}
                    className={`text-[11px] px-2.5 py-1 rounded border transition-all cursor-pointer ${
                      incidentForm.hazardType === preset
                        ? 'bg-[#213d77] border-[#213d77] text-white font-bold'
                        : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>
              <input
                type="text"
                value={incidentForm.hazardType}
                onChange={e => setIncidentForm(prev => ({ ...prev, hazardType: e.target.value }))}
                placeholder="Or type custom incident title..."
                className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-[#fb792b]"
              />
            </div>

            {/* Incident Details & Conditions Description */}
            <div>
              <label className="block text-[10px] text-slate-600 uppercase font-bold mb-1">
                Field Conditions & Disruption Details:
              </label>
              <textarea
                rows={3}
                value={incidentForm.description}
                onChange={e => setIncidentForm(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe exact conditions (e.g. 120mm rainfall caused upper hill collapse at Mile 44)..."
                className="w-full bg-slate-50 border border-slate-300 rounded p-2.5 text-xs text-slate-800 focus:outline-none focus:border-[#fb792b]"
              />
            </div>

            {/* Reported By */}
            <div>
              <label className="block text-[10px] text-slate-600 uppercase font-bold mb-1">
                Reported By / Organization:
              </label>
              <input
                type="text"
                value={incidentForm.reportedBy}
                onChange={e => setIncidentForm(prev => ({ ...prev, reportedBy: e.target.value }))}
                placeholder="e.g. Field Patrol Officer / DDMA Cachar"
                className="w-full bg-slate-50 border border-slate-300 rounded px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-[#fb792b]"
              />
            </div>

            {/* Modal Actions */}
            <div className="flex gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={() => setIncidentModalOpen(false)}
                className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-2 rounded text-xs transition-colors cursor-pointer border border-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSubmitIncident}
                className="flex-1 btn-irctc-primary text-white font-bold py-2 rounded text-xs flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <ShieldAlert className="w-4 h-4" />
                Submit Incident Report
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
