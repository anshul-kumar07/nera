'use client'

import { useState } from 'react'
import {
  Users,
  Shield,
  CheckCircle,
  Building,
  MapPin,
} from 'lucide-react'
import {
  DEMO_IDENTITIES,
  CURRENT_DEMO_USER,
  UserIdentity,
} from '@/lib/access-control'

export default function AdminUsersPage() {
  const [users] = useState<UserIdentity[]>(Object.values(DEMO_IDENTITIES))

  return (
    <div className="space-y-6 text-slate-800 font-sans">
      {/* ── 1. OFFICIAL HEADER ── */}
      <div className="gov-card p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs bg-blue-100 border border-blue-300 text-[#213d77] font-mono font-bold px-2.5 py-0.5 rounded">
              ROLE-BASED ACCESS CONTROL (RBAC)
            </span>
            <span className="text-xs bg-amber-100 border border-amber-300 text-amber-900 font-mono font-bold px-2.5 py-0.5 rounded">
              SIMULATED IDENTITIES
            </span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-[#213d77] flex items-center gap-2.5">
            <Users className="w-6 h-6 text-[#fb792b]" />
            Official Identity & Access Administration
          </h1>
          <p className="text-xs sm:text-sm text-slate-600">
            Government role assignments, departmental authority scopes, and disaster operational clearance levels
          </p>
        </div>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 text-right">
          <span className="text-xs uppercase font-bold text-slate-500 block">Active Administrator</span>
          <strong className="text-xs sm:text-sm text-[#213d77] font-bold block">{CURRENT_DEMO_USER.name}</strong>
          <span className="text-xs font-mono text-slate-500">{CURRENT_DEMO_USER.role}</span>
        </div>
      </div>

      {/* ── 2. USERS REGISTRY TABLE ── */}
      <div className="gov-card overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <h2 className="text-xs sm:text-sm font-black uppercase tracking-wide text-[#213d77] flex items-center gap-2">
            <Shield className="w-4 h-4 text-[#fb792b]" /> Registered Government Operators ({users.length})
          </h2>
          <span className="text-xs font-mono bg-blue-50 text-[#213d77] border border-blue-200 px-2.5 py-1 rounded font-bold">
            8-ROLE MATRIX ACTIVE
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs sm:text-sm">
            <thead className="bg-[#f8fafc] border-b border-slate-200 text-xs text-[#213d77] uppercase font-mono font-bold tracking-wider">
              <tr>
                <th className="p-4">User ID & Name</th>
                <th className="p-4">Assigned Role</th>
                <th className="p-4">Department & Jurisdiction</th>
                <th className="p-4">Operational Scope</th>
                <th className="p-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {users.map(u => (
                <tr key={u.userId} className="hover:bg-slate-50 transition-colors">
                  <td className="p-4">
                    <strong className="text-slate-900 font-bold block text-sm">{u.name}</strong>
                    <span className="text-xs font-mono text-slate-500">{u.userId}</span>
                  </td>
                  <td className="p-4">
                    <span className="text-xs font-mono font-bold bg-blue-50 border border-blue-200 text-[#213d77] px-2.5 py-1 rounded uppercase">
                      {u.role.replace(/_/g, ' ')}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-1.5 text-slate-900 font-semibold">
                      <Building className="w-4 h-4 text-slate-400" /> {u.department}
                    </div>
                    <span className="text-xs text-slate-500 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400" /> {u.district || 'Regional HQ'}
                    </span>
                  </td>
                  <td className="p-4">
                    <span className="text-xs text-[#213d77] font-mono font-bold block">
                      {u.permissions.length} Explicit Permissions
                    </span>
                    <span className="text-xs text-slate-500 truncate block max-w-xs mt-0.5">
                      {u.permissions.slice(0, 3).join(', ')}...
                    </span>
                  </td>
                  <td className="p-4">
                    <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded inline-flex items-center gap-1.5 font-mono">
                      <CheckCircle className="w-3.5 h-3.5" /> ACTIVE
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
