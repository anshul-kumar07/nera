// lib/data-source-health.ts
// ========================================================================
//    NERA PHASE 22: CENTRAL DATA SOURCE HEALTH & PROVENANCE MODEL
// ========================================================================

export type DataSourceStatus =
  | 'LIVE'
  | 'STALE'
  | 'OFFLINE'
  | 'UNAVAILABLE'
  | 'SIMULATED'
  | 'DATA_INSUFFICIENT'

export type DataSourceCategory =
  | 'WEATHER'
  | 'HAZARD_FEED'
  | 'FLEET_GPS'
  | 'INVENTORY'
  | 'ROUTING_OSRM'
  | 'REALTIME_DB'
  | 'NOTIFICATION_GATEWAY'

export interface DataSourceHealth {
  sourceId: string
  sourceName: string
  category: DataSourceCategory
  status: DataSourceStatus
  lastUpdatedAt: string | null
  receivedAt: string | null
  freshnessSeconds: number | null
  isSimulated: boolean
  provider: string
  coverage: string
  confidence: 'HIGH' | 'MEDIUM' | 'LOW' | 'INSUFFICIENT'
  errorMessage?: string | null
  metadata?: Record<string, unknown>
}

// ── Freshness Evaluation Config ──
export const FRESHNESS_THRESHOLDS_SEC: Record<DataSourceCategory, number> = {
  WEATHER: 1800, // 30 mins
  HAZARD_FEED: 900, // 15 mins
  FLEET_GPS: 60, // 1 min
  INVENTORY: 3600, // 1 hr
  ROUTING_OSRM: 300, // 5 mins
  REALTIME_DB: 30, // 30 sec
  NOTIFICATION_GATEWAY: 300, // 5 mins
}

export function evaluateDataFreshness(
  category: DataSourceCategory,
  lastUpdatedIso: string | null,
  isSimulated: boolean = false
): { status: DataSourceStatus; freshnessSeconds: number | null } {
  if (isSimulated) {
    return { status: 'SIMULATED', freshnessSeconds: 0 }
  }

  if (!lastUpdatedIso) {
    return { status: 'UNAVAILABLE', freshnessSeconds: null }
  }

  const updatedTime = new Date(lastUpdatedIso).getTime()
  if (isNaN(updatedTime)) {
    return { status: 'DATA_INSUFFICIENT', freshnessSeconds: null }
  }

  const now = Date.now()
  const freshnessSeconds = Math.max(0, Math.floor((now - updatedTime) / 1000))
  const threshold = FRESHNESS_THRESHOLDS_SEC[category] || 600

  if (freshnessSeconds <= threshold) {
    return { status: 'LIVE', freshnessSeconds }
  } else {
    return { status: 'STALE', freshnessSeconds }
  }
}

// ── Default System Data Source Registry ──
export const SYSTEM_DATA_SOURCES: DataSourceHealth[] = [
  {
    sourceId: 'SRC-WX-01',
    sourceName: 'Open-Meteo Weather API',
    category: 'WEATHER',
    status: 'LIVE',
    lastUpdatedAt: new Date(Date.now() - 120000).toISOString(), // 2 min ago
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 120,
    isSimulated: false,
    provider: 'Open-Meteo & IMD Regional Radar',
    coverage: 'North Eastern Region (Assam, Meghalaya, Tripura, Mizoram, Manipur, Nagaland, Arunachal, Sikkim)',
    confidence: 'HIGH',
  },
  {
    sourceId: 'SRC-HAZ-01',
    sourceName: 'National Disaster Management Hazard Feed',
    category: 'HAZARD_FEED',
    status: 'UNAVAILABLE',
    lastUpdatedAt: null,
    receivedAt: null,
    freshnessSeconds: null,
    isSimulated: false,
    provider: 'NDMA / CWC Automated RSS/CAP Gateway',
    coverage: 'Unconfigured (Awaiting State NIC API Key)',
    confidence: 'INSUFFICIENT',
    errorMessage: 'Authoritative national hazard API gateway endpoint not configured in production environment',
  },
  {
    sourceId: 'SRC-GPS-01',
    sourceName: 'NER State Fleet Telemetry',
    category: 'FLEET_GPS',
    status: 'SIMULATED',
    lastUpdatedAt: new Date(Date.now() - 15000).toISOString(),
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 15,
    isSimulated: true,
    provider: 'NERA Simulated AIS-140 GPS Emulator',
    coverage: '12 Emergency Transport Vehicles (Lumding-Haflong & Silchar Corridors)',
    confidence: 'HIGH',
  },
  {
    sourceId: 'SRC-INV-01',
    sourceName: 'State Logistics Depot Inventory Ledger',
    category: 'INVENTORY',
    status: 'SIMULATED',
    lastUpdatedAt: new Date(Date.now() - 600000).toISOString(),
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 600,
    isSimulated: true,
    provider: 'NERA Verified Regional Stock Registry (Guwahati, Silchar, Dimapur)',
    coverage: '3 Regional Apex Depots (Medicines, Rations, Water, Rescue Gear)',
    confidence: 'HIGH',
  },
  {
    sourceId: 'SRC-OSRM-01',
    sourceName: 'OSRM Highway Routing Engine',
    category: 'ROUTING_OSRM',
    status: 'LIVE',
    lastUpdatedAt: new Date(Date.now() - 30000).toISOString(),
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 30,
    isSimulated: false,
    provider: 'Project OSRM Demo Server & Local Fallback Multi-Graph',
    coverage: 'All North East National Highways & State Corridors',
    confidence: 'HIGH',
  },
  {
    sourceId: 'SRC-DB-01',
    sourceName: 'Supabase Postgres Realtime Engine',
    category: 'REALTIME_DB',
    status: 'LIVE',
    lastUpdatedAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 5,
    isSimulated: false,
    provider: 'Supabase Cloud (ap-south-1 Mumbai)',
    coverage: 'Cross-Officer Incident & Mission Replication',
    confidence: 'HIGH',
  },
  {
    sourceId: 'SRC-NOTIF-01',
    sourceName: 'Multi-Channel Alert Dispatch Gateway',
    category: 'NOTIFICATION_GATEWAY',
    status: 'SIMULATED',
    lastUpdatedAt: new Date().toISOString(),
    receivedAt: new Date().toISOString(),
    freshnessSeconds: 0,
    isSimulated: true,
    provider: 'NERA In-App Notification Engine (SMS/Push Unconfigured)',
    coverage: 'In-App Dashboard & Officer Notification Center',
    confidence: 'HIGH',
  },
]
